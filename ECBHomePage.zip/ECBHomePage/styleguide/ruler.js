let guides = '<div class="custom-divider">'
				+'<div class="legend-1"></div>'
				+'<div class="legend-2"></div>'
				+'<div class="legend-3"></div>'
				+'<div class="responsive-guides-1"></div>'
				+'<div class="fixed-guides-1"></div>'
				+'<div class="fixed-guides-2"></div>'
				+'<div class="fixed-guides-3"></div>'
			+'</div>';

document.getElementById('myRuler').insertAdjacentHTML('beforeend', guides);

var els = document.getElementsByClassName('component'),
	mainPosition = document.getElementsByTagName("main")[0].offsetTop,
	header = document.getElementById("myRuler"),
	sticky = mainPosition + header.offsetTop;

for (var i = 0; i < els.length; i++) {
	els[i].style.display = "none";
}

header.classList.add("custom-sticky");
//header.style.display = "none";
//window.onscroll = function() {
//	myRuler();
//}
//function myRuler() {
//	window.pageYOffset > sticky ? header.classList.add("custom-sticky") : header.classList.remove("custom-sticky");
//}
function toggleRuler() {
	//header.style.display === "none" ? header.style.display = "block" : header.style.display = "none";
	document.querySelector('.viewer-display').classList.toggle('js_ruler-enabled');
	document.querySelector('.ruler-button').classList.toggle('js_is-open');
}

function toggleDivider() {
	var hLines = document.getElementsByTagName('hr');
	for (var i = 0; i < hLines.length; i++) {
	hLines[i].style.border = "2px solid red;";
}
}

// ******************************* //
// ---------- COMPONENT ---------- //
function myComponent(el) {
	var x = el.nextElementSibling;
	x.style.display === "none" ? x.style.display = "block" : x.style.display = "none";
}

// *************************************** //
// ---------- IMAGE COORDINATES ---------- //
function getImgData() {
	var img = document.getElementById('pointer_div'),
		style = img.currentStyle || window.getComputedStyle(img, false),
		url = style.backgroundImage.slice(4, -1).replace(/"/g, "");

	var el = document.createElement('img');
		el.id = 'imgId';
		el.src = url;
		el.width = 0;
		el.height = 0;
	document.getElementById("dummyImage").appendChild(el);
}
function point_it(event) {
	getImgData();
	var divWidth = document.getElementById("pointer_div").offsetWidth,
		divHeight = document.getElementById("pointer_div").offsetHeight,
		naturalWidth = document.getElementById("imgId").naturalWidth,
		naturalHeight = document.getElementById("imgId").naturalHeight,
		divSizeRatio = divHeight/divWidth,
		naturalSizeRatio = naturalHeight/naturalWidth,
		heightShift = divWidth * naturalSizeRatio - divHeight,
		heightTopShift = (divWidth * naturalSizeRatio - divHeight) / 2,
		widthShift = divHeight * naturalSizeRatio - divWidth,
		widthTopShift = (divHeight * naturalSizeRatio - divWidth) / 2,
		totalWidth = divHeight * naturalSizeRatio,
		totalHeight = divWidth * naturalSizeRatio,
		divCoordinateX = event.offsetX,
		divCoordinateY = event.offsetY,
		divCoordinateXCorrected = divCoordinateX + widthTopShift,
		divCoordinateYCorrected = divCoordinateY + heightTopShift,
		divCoordinateXCorrectedInPercentage = divCoordinateXCorrected / totalWidth,
		divCoordinateYCorrectedInPercentage = divCoordinateYCorrected / totalHeight,
		coordinateXOriginalSize,
		coordinateYOriginalSize;
	if (naturalSizeRatio > divSizeRatio) {
		//console.log('image width is 100%');
			coordinateXOriginalSize = naturalWidth * (divCoordinateX / divWidth);
			coordinateYOriginalSize = naturalHeight * divCoordinateYCorrectedInPercentage;
	} else if (naturalSizeRatio < divSizeRatio) {
		//console.log('image height is 100%');
			coordinateXOriginalSize = naturalWidth * divCoordinateXCorrectedInPercentage;
			coordinateYOriginalSize = naturalHeight * (divCoordinateY / divHeight);
	} else if (naturalSizeRatio == divSizeRatio) {
		//console.log('image width and height are the original');
			coordinateXOriginalSize = naturalWidth;
			coordinateYOriginalSize = naturalHeight;
	}
	//document.pointform.form_x.value = Math.round(coordinateXOriginalSize * 100) / 100;
	//document.pointform.form_y.value = Math.round(coordinateYOriginalSize * 100) / 100;
	document.pointform.form_x.value = Math.round(coordinateXOriginalSize);
	document.pointform.form_y.value = Math.round(coordinateYOriginalSize);
	//console.log('divWidth: ' + divWidth + 'px, divHeight: ' + divHeight + 'px');
	//console.log('naturalWidth: ' + naturalWidth + 'px, naturalHeight: ' + naturalHeight + 'px');
	//console.log('divSizeRatio: ' + divSizeRatio + ', naturalSizeRatio: ' + naturalSizeRatio);
	//console.log('heightShift: ' + heightShift + 'px, heightTopShift: ' + heightTopShift + 'px');
	//console.log('widthShift: ' + widthShift + 'px, widthTopShift: ' + widthTopShift + 'px');
	//console.log('totalWidth: ' + totalWidth + 'px, totalHeight: ' + totalHeight + 'px');
	//console.log('divCoordinateXCorrected: ' + divCoordinateXCorrected + 'px, divCoordinateYCorrected: ' + divCoordinateYCorrected + 'px');
	//console.log('divCoordinateXCorrectedInPercentage: ' + divCoordinateXCorrectedInPercentage + ', divCoordinateYCorrectedInPercentage: ' + divCoordinateYCorrectedInPercentage);
	//console.log('divCoordinateX: ' + divCoordinateX + 'px, divCoordinateY: ' + divCoordinateY + 'px');
	//console.log('divCoordinateXInPercentage: ' + Math.round(divCoordinateXInPercentage * 100) / 100 + ', divCoordinateYInPercentage: ' + Math.round(divCoordinateYInPercentage * 100) / 100);
	//console.log('coordinateXOriginalSize:', Math.round(coordinateXOriginalSize * 100) / 100);
	//console.log('coordinateYOriginalSize:', Math.round(coordinateYOriginalSize * 100) / 100);
}