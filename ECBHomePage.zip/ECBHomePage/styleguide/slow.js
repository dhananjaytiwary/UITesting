/*! ECB - v1.6.24 - European Central Bank */

var ECB = window.ECB || {};

ECB.libraryPaths = {};
ECB.libraryPaths.amcharts3_16js = ["/shared/dist/js/require/amcharts_3.16.js?v="+ECB.version,
                                    "/shared/dist/js/require/serial_3.16.js?v="+ECB.version,
                                    "/shared/dist/js/require/xy_3.16.js?v="+ECB.version,
                                    "/shared/dist/js/require/amstock_3.16.js?v="+ECB.version,
                                    "/shared/dist/js/require/light_3.16.js?v="+ECB.version,
                                    "/shared/dist/js/require/responsive_3.16.min.js?v="+ECB.version];

ECB.libraryPaths.amcharts_graphjs = ["/shared/dist/js/require/amcharts_amc_graph.js?v="+ECB.version,
                                    "/shared/dist/js/require/serial_amc_graph.js?v="+ECB.version,
                                    "/shared/dist/js/require/amstock_amc_graph.js?v="+ECB.version,
                                    "/shared/dist/js/require/light_amc_graph.js?v="+ECB.version,
                                    "/shared/dist/js/require/export_amc_graph.min.js?v="+ECB.version];

ECB.libraryPaths.midSearchJs = ["/shared/dist/js/require/jquery.xml2json.js?v="+ECB.version,
                                "/shared/dist/js/require/jquery.soap.js?v="+ECB.version,
                                "/shared/dist/js/require/pako_inflate.min.js?v="+ECB.version];

ECB.libraryPaths.flickity = "/shared/dist/js/require/flickity.pkgd.min.js?v="+ECB.version;
ECB.libraryPaths.publicationsPlugin = "/shared/dist/plugins/publications/publications.js?v="+ECB.version;
ECB.libraryPaths.markjs = "/shared/dist/js/require/mark.min.js?v="+ECB.version;
ECB.libraryPaths.mapsPlugin = "/shared/dist/plugins/maps/maps.min.js?v="+ECB.version;
ECB.libraryPaths.banknotesPlugin = "/shared/dist/plugins/banknotes/banknotes.min.js?v="+ECB.version;
ECB.libraryPaths.secFeaturesPlugin = "/shared/dist/plugins/secfeatures/secFeatures.min.js?v="+ECB.version;
ECB.libraryPaths.coinsPlugin = "/shared/dist/plugins/coins/coins.min.js?v="+ECB.version;
ECB.libraryPaths.quizesPlugin = "/shared/dist/plugins/quizes/quizes.min.js?v="+ECB.version;
ECB.libraryPaths.mathjax = '/shared/js/MathJax/MathJax.js?config=TeX-MML-AM_CHTML';
ECB.libraryPaths.equationsPlugin = "/shared/dist/plugins/equations/equations.min.js?v="+ECB.version;
ECB.libraryPaths.crisisTimelinePlugin = "/shared/dist/plugins/crisisTimeline/crisisTimeline.min.js?v="+ECB.version;
ECB.libraryPaths.ebTimelinePlugin = "/shared/dist/plugins/ebTimeline/ebTimeline.min.js?v="+ECB.version;
ECB.libraryPaths.annualChartPlugin = "/shared/dist/plugins/annualChart/annualChart.min.js?v="+ECB.version;
ECB.libraryPaths.annualBalanceChartPlugin = "/shared/dist/plugins/annualBalanceChart/annualBalanceChart.min.js?v="+ECB.version;
ECB.libraryPaths.circulationChartPlugin = "/shared/dist/plugins/circulationChart/circulationChart.min.js?v="+ECB.version;
ECB.libraryPaths.mpoChartPlugin = "/shared/dist/plugins/mpoChart/mpoChart.min.js?v="+ECB.version;
ECB.libraryPaths.eerChartPlugin = "/shared/dist/plugins/eerChart/eerChart.min.js?v="+ECB.version;
ECB.libraryPaths.eaycChartPlugin = "/shared/dist/plugins/eaycChart/eaycChart.min.js?v="+ECB.version;
ECB.libraryPaths.electroPaymChartPlugin = "/shared/dist/plugins/electroPaymChart/electroPaymChart.min.js?v="+ECB.version;
ECB.libraryPaths.lazyloadPlugin = '/shared/dist/plugins/lazyload/lazyloader.js?v='+ECB.version;
ECB.libraryPaths.homePageAutoUpdatePlugin = '/shared/dist/plugins/homePageAutoUpdate/homePageAutoUpdate.js?v='+ECB.version;
ECB.libraryPaths.chartsPlugin = '/shared/dist/plugins/charts/charts.js?v='+ECB.version;
ECB.libraryPaths.scrollStoryPlugin = '/shared/dist/plugins/scrollstory/scrollstory-app.min.js?v='+ECB.version;
ECB.libraryPaths.midEASearchPlugin = "/shared/dist/plugins/midEASearch/midEASearch.min.js?v="+ECB.version;
ECB.libraryPaths.midMFISearchPlugin = "/shared/dist/plugins/midMFISearch/midMFISearch.min.js?v="+ECB.version;
ECB.libraryPaths.midMFIDSearchPlugin = "/shared/dist/plugins/midMFIDSearch/midMFIDSearch.min.js?v="+ECB.version;

ECB.stylesheetPaths = {};
ECB.stylesheetPaths.flickity = "/shared/dist/css/require/flickity.min.css?v="+ECB.version;
ECB.stylesheetPaths.mapsPlugin = "/shared/dist/plugins/maps/maps.min.css?v="+ECB.version;
ECB.stylesheetPaths.banknotesPlugin = "/shared/dist/plugins/banknotes/banknotes.min.css?v="+ECB.version;
ECB.stylesheetPaths.secFeaturesPlugin = "/shared/dist/plugins/secfeatures/secFeatures.min.css?v="+ECB.version;
ECB.stylesheetPaths.coinsPlugin = "/shared/dist/plugins/coins/coins.min.css?v="+ECB.version;
ECB.stylesheetPaths.quizesPlugin = "/shared/dist/plugins/quizes/quizes.min.css?v="+ECB.version;
ECB.stylesheetPaths.equationsPlugin = "/shared/dist/plugins/equations/equations.min.css?v="+ECB.version;
ECB.stylesheetPaths.crisisTimelinePlugin = "/shared/dist/plugins/crisisTimeline/crisisTimeline.min.css?v="+ECB.version;
ECB.stylesheetPaths.ebTimelinePlugin = "/shared/dist/plugins/ebTimeline/ebTimeline.min.css?v="+ECB.version;
ECB.stylesheetPaths.annualChartPlugin = "/shared/dist/plugins/annualChart/annualChart.min.css?v="+ECB.version;
ECB.stylesheetPaths.annualBalanceChartPlugin = "/shared/dist/plugins/annualBalanceChart/annualBalanceChart.min.css?v="+ECB.version;
ECB.stylesheetPaths.circulationChartPlugin = "/shared/dist/plugins/circulationChart/circulationChart.min.css?v="+ECB.version;
ECB.stylesheetPaths.mpoChartPlugin = "/shared/dist/plugins/mpoChart/mpoChart.min.css?v="+ECB.version;
ECB.stylesheetPaths.eerChartPlugin = "/shared/dist/plugins/eerChart/eerChart.min.css?v="+ECB.version;
ECB.stylesheetPaths.eaycChartPlugin = "/shared/dist/plugins/eaycChart/eaycChart.min.css?v="+ECB.version;
ECB.stylesheetPaths.lazyloadPlugin = '/shared/dist/plugins/lazyload/lazyloader.css?v='+ECB.version;
ECB.stylesheetPaths.chartsPlugin = '/shared/dist/plugins/charts/charts.css?v='+ECB.version;
ECB.stylesheetPaths.scrollStoryPlugin = '/shared/dist/plugins/scrollstory/scrollstory-app.min.css?v='+ECB.version;

// Addapted from https://davidwalsh.name/javascript-debounce-function
ECB.slow.debounce = function (func, wait, immediate, throttle) {
    var timeout;
    return function () {
        var context = this,
            args = arguments;
        
        var callNow = immediate && !timeout;

        var later = function () {
            timeout = null;
            
            if (!callNow && (!immediate||throttle)) func.apply(context, args);
            callNow = false;
        };
        
        
        if(!throttle){
            clearTimeout(timeout);
        }

        if(!timeout||!throttle){
            timeout = setTimeout(later, wait);
        }
        
        if (callNow) func.apply(context, args);
    };
};
ECB.slow.forEach = function (items, f) {
    for (var i = 0; i < items.length; i++) {
        f(items[i], i);
    }
}


ECB.slow.matchChildren = function (elem, selector) {
    /**
    * @license MIT, GPL, do whatever you want
    * @requires polyfill: Array.prototype.slice fix {@link https://gist.github.com/brettz9/6093105}
    */
    if (!Array.from) {
        Array.from = function (object) {
            'use strict';
            return [].slice.call(object);
        };
    }

    if (!Element.prototype.matches) {
        Element.prototype.matches = Element.prototype.msMatchesSelector ||
            Element.prototype.webkitMatchesSelector;
    }

    if (typeof elem.children != 'undefined') {
        return Array.from(elem.children).filter(function (child) {
            return child.matches(selector);
        });
    }
    return null;
};

ECB.slow.parseUrlParams = function () {

    var params = {},
        parts = window.location.search.substr(1).split('&');

    for (var i = 0; i < parts.length; i++) {

        var keyValuePair = parts[i].split('='),
            key = decodeURIComponent(keyValuePair[0]);

        params[key] = keyValuePair[1] ?
            decodeURIComponent(keyValuePair[1].replace(/\+/g, ' ')) :
            keyValuePair[1];

    }

    return params;
};


ECB.slow.getScript = function (pathToFile, async, type, callback) {
    /*var scripts = Array
        .from(document.querySelectorAll('script'))
        .map(scr => scr.src);

    if (!scripts.includes(pathToFile)) {
        */
        var script = document.createElement('script');
        script.type = type ? type : 'text/javascript';
        script.src = pathToFile;
        script.onload = callback;
        script.async = async;
        script.defer - true;
        var slowScript = document.head.querySelector('script[src$="slow.js"]');
        document.head.insertBefore(script, slowScript);
    }
//}

ECB.slow.getStylesheet = function (pathToFile, async, callback) {
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = pathToFile;
    link.onload = callback;
    link.media = "screen";
    link.async = async;
    link.defer - true;
    var lastLink = document.head.querySelector('link:last-of-type');
    document.head.insertBefore(link, lastLink);
}

//ie11 polyfills

// This is only a partial array from, that works for node lists.
!Array.from && (Array.from = function(nodeListObject){
    return Array.prototype.slice.call(nodeListObject); 
});

if (!String.prototype.includes) {
    String.prototype.includes = function(search, start) {
      'use strict';
      if (typeof start !== 'number') {
        start = 0;
      }
  
      if (start + search.length > this.length) {
        return false;
      } else {
        return this.indexOf(search, start) !== -1;
      }
    };
  }

  if(!Array.prototype.includes){
    Array.prototype.includes = function(search){
      return this.indexOf(search)!=-1;
    }
  }
if (!('remove' in Element.prototype)) {
    Element.prototype.remove = function() {
        if (this.parentNode) {
            this.parentNode.removeChild(this);
        }
    };
}
ECB.slow.isLoaded = function (parentSelector) {
    if(parentSelector) {
        document.querySelector(parentSelector+" .is-busy").remove();
    } else {
        document.querySelector(".-is-loading .is-busy").remove();
    }
}

ECB.slow.accordion = function (rootNode) {
    var root =  rootNode;
    if (!rootNode)
        root = document;

    ECB.slow.forEach(root.querySelectorAll("main > .accordion, dd > .accordion"), function (accordion) {
        
    });
    
    document.addEventListener("filterDirty", function(e){
        var headers = e.target.querySelectorAll(".accordion > .header")
        for (var i = 0; i < headers.length; i++){
            headers[i].classList.add("-opened")
        } 
    })
    
    document.addEventListener("filterClean", function(e){
        var headers = e.target.querySelectorAll(".accordion > .header")
        for (var i = 0; i < headers.length; i++){
            headers[i].classList.remove("-opened")
        }
    })

    ECB.slow.forEach(root.querySelectorAll(".accordion > .header"), function (accordion) {
        accordion.addEventListener('click', function (e) {
            var heading = e.currentTarget;
            heading && heading.classList.toggle("-opened");
        });
    });
};
ECB.slow.addSearchApi = function() {

	var AddsearchApi = {
		
		src: "https://api.addsearch.com/v1/search/61893af990d2673c4a92b492dd7f6631",
		inputSearchId: "searchInput",
		containerSearch: "addSearch-container-full",
		elementResults: "addsearch-api-results",
		client: "",
		idClient: "61893af990d2673c4a92b492dd7f6631",
		qntPageShow: 9,
		sortByTerm: "relevance",
		currentTab: "all",
		term: "",
		total_hits: 0,

		initSearch: function(term) {

			selfApi = this; //prevent overwrite of 'this'
			el = document.getElementById(selfApi.elementResults);
			el.innerHTML = "";

			selfApi.client.setLanguage(document.documentElement.lang);

			if (term == null || term == "") {
				term = document.getElementById(selfApi.inputSearchId).value;
			} else {
				document.getElementById(selfApi.inputSearchId).value = term;
			}
			selfApi.term = term;
						
			if (term != "" && term != null) {
				selfApi.buildHitsCount(term);
				selfApi.client.search(term, selfApi.buildResult);
				selfApi.client.suggestions(term, selfApi.buildSugestions);
			}

		},

		pagination: function(page) {

			selfApi.client.setPaging(page, 10, selfApi.sortByTerm, "desc");
			selfApi.client.search();
		},

		filterDate: function(type) {
			
			var dateTo = new Date().toJSON().slice(0,10);
			var dateF = new Date();

			if(type == "month") {
				dateF.setMonth(dateF.getMonth() -1);
			}
			if(type == "year") {
				dateF.setFullYear(dateF.getFullYear() -1);
			}

			var dateFrom = dateF.toJSON().slice(0,10);
			if(type == "all") {
				dateFrom = null;
			}
			
			this.currentTab = type; //save current tab for references in count hits
		
			selfApi.client.setDateFilter(dateFrom, dateTo);
			selfApi.sortBy("relevance");
		},

		sortBy: function(sortBy) {
			
			selfApi.scrollUp();
			selfApi.sortByTerm = sortBy;
			document.getElementById("sort-by-"+sortBy).checked = true; //force select
			selfApi.pagination(1);
		},

		buildSugestions: function(data) {

			var containerSuggestions = document.getElementById("suggestions-container");
			var containerSuggestionsResults = document.getElementById("result-suggestions").getElementsByTagName("span")[0];
			containerSuggestions.innerHTML = "";
			

			if (data.suggestions.length < 1) {
				containerSuggestionsResults.setAttribute("style", "display: none;");
			} else {
				containerSuggestionsResults.setAttribute("style", "display: block;");
			}

			
			var dropSuggestions = document.getElementById("searchSuggestion");
			dropSuggestions.innerHTML = "<option></option>";

			

			var searchTerm = document.getElementById(selfApi.inputSearchId).value.trim();
			
			data.suggestions.forEach(function (hit) {
				if(searchTerm == hit.value){
					return;
				}
				var suggestion = document.createElement("label");
				suggestion.innerHTML = hit.value;

				
				var opt = document.createElement('option');
				opt.value = hit.value;
				opt.innerHTML = hit.value;
				dropSuggestions.appendChild(opt);
				
				search = function(){
					document.getElementById(selfApi.inputSearchId).value = hit.value; 
					selfApi.initSearch();
					selfApi.cleanPage();
				};

				suggestion.addEventListener("click", search);

				containerSuggestions.appendChild(suggestion);
			});

			//selfApi.ggestions();

		},

		buildResult: function (data) {

			el = document.getElementById(selfApi.elementResults);
			el.innerHTML = "";

			selfApi.buildHits(data.hits);
			selfApi.buildPagination(data.page, data.total_hits);

			selfApi.total_hits = data.total_hits;
			
		},

		buildHitsCount: function(term) {


			var types = ['all', 'year','month'];

			types.forEach(function(val){
				
				/* build new client for periods of search to not overwrite current search */
				clientPeriod = new AddSearchClient(selfApi.idClient);
				clientPeriod.setFuzzyMatch(false); 
				clientPeriod.setLanguage(document.documentElement.lang);
				clientPeriod.setCollectAnalytics(false); //remove from analytics to not to be duplicated
				selfApi.buildHitCount(term, val, clientPeriod);
					
			}, undefined, term);


		},

		buildHitCount: function (term, type, client) {

			var today = new Date().toJSON().slice(0, 10);
			var date = new Date();

			if (type == "month") {
				date.setMonth(date.getMonth() - 1);
			}
			if (type == "year") {
				date.setFullYear(date.getFullYear() - 1);
			}

			var firstDay = date.toJSON().slice(0, 10);

			if (type == "all") {
				client.setDateFilter(null, null);
			} else {
				client.setDateFilter(firstDay, today);
			}

			buildCount = function (data) {

				var countElements = document.querySelectorAll("label.count-hits-" + type + " span");
				ECB.slow.forEach(countElements, function (element) {
					element.innerHTML = " (" + data.total_hits + ")";
				});


			};


			client.search(term, buildCount);

		},

		buildHits: function (data) {

			var containerSortby = document.getElementById("result-sortBy");
			if (data.length <= 1) {
				containerSortby.setAttribute("style", "display: none;");
			} else {
				containerSortby.setAttribute("style", "display: block;");
			}
					
			if(data.length == 0) {
				el.innerHTML = "<div class=\"no-results\">No results found</div>";
			}

			data.forEach(function(hit, i) {
					
				var containerItem = document.createElement("div");
				containerItem.id = "addsearch-api-result-container-item-"+(i+1);					
				containerItem.classList.add("addsearch-api-result-item-container");

				var elementItem = document.createElement("div");
				elementItem.id = "addsearch-api-result-item-"+(i+1);
				elementItem.classList.add("addsearch-api-result-item-sub");
				containerItem.appendChild(elementItem);

				if(hit.ts != null) {
					
					var jsDate = new Date(hit.ts);

					// thanks to JS, getMonth start from 0, yey!
					var formatedDate =  String(jsDate.getDate()).padStart(2, '0') + '/' + String(jsDate.getMonth()+1).padStart(2, '0') + '/' + jsDate.getFullYear();

					var dateItem = document.createElement("span");
					dateItem.classList.add("item-date");
					dateItem.innerHTML = formatedDate;
					elementItem.appendChild(dateItem);

				}

				var titleItem = document.createElement("h2");
				elementItem.appendChild(titleItem);

				var titleLink = document.createElement("a");
				var newUrl = hit.url.replace("https://www.ecb.europa.eu", "");
				titleLink.setAttribute("target", "_blank");
				titleLink.setAttribute("data-id", hit.id);
				titleLink.setAttribute("data-pos", i+1);


				if(hit.title) {
					title = hit.title;
				} else{
					title = newUrl;
					title = title.match(/[-_\.\w]+[.][\w+]{3}/)[0]; //if is filename is the url, get only the filename

				}

				if (title.length > 160) {
					title = title.substring(0, 160) + "...";
                }
				
				titleLink.innerHTML = title;
				titleItem.appendChild(titleLink);

				if(hit.document_type == "doc" || hit.document_type == "pdf") {
					var icon = document.createElement("span");
					if(hit.document_type == "doc") {
						icon.setAttribute("class", "icon -word-file");	
					}
					if(hit.document_type == "pdf") {
						icon.setAttribute("class", "icon -pdf-file");
					}
					
					titleItem.appendChild(icon);
					
				}

				var category = "";
				titleLink.href = newUrl;
				if(hit.type != null && hit.type == "PROMOTED") {
					containerItem.classList.add("promoted-item-container");
				}


				var highlightItem = document.createElement("p");
				highlightItem.innerHTML = hit.highlight;
				elementItem.appendChild(highlightItem);

				var CategoryItem = document.createElement("p");
				CategoryItem.setAttribute("class", "addsearch-category");

				if(typeof hit.categories[1] != "undefined") {
					category = hit.categories[1].replace("1x", "");

					if (category.length == 0) { category = hit.categories[2].replace("2x", ""); }

					var categoryEl = document.getElementById("adcat_"+category);
					
					if(typeof categoryEl != "undefined" && categoryEl != null) {
						categoryName = categoryEl.textContent;
					} else {
						categoryName = category;
					}
					
					CategoryItem.innerHTML = categoryName;
					elementItem.appendChild(CategoryItem);
				} 

				if(hit.type != null && hit.type == "PROMOTED") { 
					var categoryLink = document.createElement("p");
					categoryLink.setAttribute("class", "addsearch-category");
					categoryLink.innerHTML = title;
					elementItem.appendChild(categoryLink);
				}
				

				el.appendChild(containerItem);

				var sidemenuContainer = document.getElementById("addsearch-sidemenu");
				var imageContainer = document.getElementById("addsearch-image");
				
				var previewDiv = document.getElementById("text-image-preview");
				var optionsDiv = document.getElementById("text-search-options");

				showThumb = function() {

					imageContainer.setAttribute("src", hit.images.capture);
					imageContainer.setAttribute("data-id", hit.id);
					imageContainer.setAttribute("data-pos", 1);

					sidemenuContainer.classList.add("hidden");
					imageContainer.classList.remove("hidden");
					previewDiv.classList.remove("hidden");
					optionsDiv.classList.add("hidden");
					imageContainer.parentNode.setAttribute("href", hit.url);

					// Link clicked with mouse / tapped on mobile
					imageContainer.addEventListener('pointerdown', selfApi.eventASclick);

					if(hit.images == null || typeof hit.images == "undefined") {
						closeThumb();
					}
				}

				closeThumb = function() {	
					imageContainer.setAttribute("src", "");
					sidemenuContainer.classList.remove("hidden");
					imageContainer.classList.add("hidden");
					previewDiv.classList.add("hidden");
					optionsDiv.classList.remove("hidden");

				}

				if(hit.images.capture) {
					containerItem.addEventListener("mouseover", showThumb);
					document.getElementsByClassName("white-bg")[0].addEventListener("mouseleave", closeThumb);
				} else {
					containerItem.addEventListener("mouseover", closeThumb);
				}

				// Link clicked with mouse / tapped on mobile
				titleLink.addEventListener('pointerdown', selfApi.eventASclick);
					

			});
		},

		buildPagination: function(current_page, total_hits) {

			
			var containerPagination = document.createElement("div");
			containerPagination.id = "addsearch-api-rp-paging";

			
			var totalPages = Math.ceil(total_hits / 10);
			if (totalPages < 1) totalPages = 1;

			initPage = current_page - Math.floor(this.qntPageShow/2);
			

			breakPage = current_page + Math.floor(this.qntPageShow/2);
			if (breakPage > totalPages) { breakPage = totalPages; initPage = breakPage - this.qntPageShow-1; };
			if (initPage < 1) {initPage = 1; breakPage = initPage + this.qntPageShow-1; };

			if(current_page != 1) {
				jumperPreviousEl = this.buildPageButton("previous", containerPagination);
			}


			if (totalPages > 1) {

				for(i=initPage;i<=totalPages;i++) {

					var itemPagination = document.createElement("a");
					itemPagination.innerHTML = i;

					if(i==current_page) {
						itemPagination.classList.add("currentResultPage");
					}

					containerPagination.appendChild(itemPagination);

					if(i==breakPage) break;

				}

				if(totalPages != current_page) {
					jumperNextEl = this.buildPageButton("next", containerPagination);
				}

				el.appendChild(containerPagination);

			}
			

			var paging = document.getElementById("addsearch-api-rp-paging");

			if (typeof paging != "undefined" && paging != null) {
				pages = paging.getElementsByTagName("a");
			
				var Fpagination = (function(page){this.pagination(page);selfApi.scrollUp()}).bind(this); //must create function to use 'this' inside.

				var pageList = Array.prototype.slice.call(pages);
				pageList.forEach(function(page) {
					if (!isNaN(page.innerHTML)) {
						page.addEventListener("click", Fpagination.bind(null, page.innerHTML));
					}
					
				});
		
				
				if(typeof jumperPreviousEl != "undefined") {
					if (current_page-(Math.floor(this.qntPageShow/2)+1) < 1) {
						jumPrevious = 1
					} else {
						jumPrevious = current_page-(Math.floor(this.qntPageShow/2)+1);
					}
					
					
					jumperPreviousEl.addEventListener("click", Fpagination.bind(null, jumPrevious));
				}
		
				
				if(typeof jumperNextEl != "undefined") {
					if (current_page+(Math.floor(this.qntPageShow/2)+1) > totalPages) {
						jumpNext = totalPages;
					} else {
						jumpNext = current_page+(Math.floor(this.qntPageShow/2)+1);
					}
					
					
					jumperNextEl.addEventListener("click", Fpagination.bind(null, jumpNext));
				}
			}
		},

		buildPageButton: function(type, containerPagination) {
			
				if(type=="previous") button = "«";
				if(type=="next") button = "»";
			
				var containerJumpPage = document.createElement("a");
				containerJumpPage.classList.add(type+"jump");

				var containerJumpPageSpan = document.createElement("span");
				containerJumpPageSpan.innerHTML = button;
				containerJumpPage.appendChild(containerJumpPageSpan);
				
				var containerJumpPageSpan = document.createElement("span");
				containerJumpPageSpan.innerHTML = type;

				containerJumpPageSpan.classList.add("visuallyhidden");
				containerJumpPage.appendChild(containerJumpPageSpan);

				containerPagination.appendChild(containerJumpPage);
			
				return containerJumpPage;
				
				
		},

		eventASclick: function() {

			var id = this.getAttribute("data-id");
			var position = this.getAttribute("data-pos");

			selfApi.client.sendStatsEvent('click', selfApi.term, { documentId: id, position: position });

		},


		cleanPage: function () {
			//this.filterDate("year");
			this.scrollUp();
			selfApi.client.setPaging(1, 10, "relevance", "desc"); // reset page
			selfApi.client.setDateFilter(null, null);
			document.getElementById("searchAll").checked = true;
			document.getElementById("sort-by-relevance").checked = true;
		},

		scrollUp: function(){
			document.documentElement.scrollTop = 0;
		},
		
		ggestions: function() {

			document.getElementById("result-suggestions").setAttribute("style","display:block;");
			//minSize = document.getElementById("addsearch-sidemenu").offsetHeight + 175;
			minSize = "800";

			if(window.innerHeight < minSize) {
				document.getElementById("result-suggestions").setAttribute("style","display:none;");
			}
		},

		adjustHeaderHeight: function () {
			//document.getElementById(selfApi.containerSearch).style.top = (document.getElementById('ecb-doc-header').offsetHeight+ 15) + "px";
			

			// if (window.innerWidth <= 768) {
			// 	innerSize = "205px";
			// } else {
			// 	innerSize = "75px";
            // }

			// document.getElementById(selfApi.containerSearch).style.height = "calc(100vh - (" + innerSize + " + " + document.getElementById('ecb-doc-header').offsetHeight + "px))";
        }, 

		delayPressKey: function (callback, ms) {
			var timer = 0;
			return function() {
			  var context = this, args = arguments;
			  clearTimeout(timer);
			  timer = setTimeout(function () {
				callback.apply(context, args);
			  }, ms || 0);
			};
		  },

		limitInputChar: function() {

			var content = document.getElementById(selfApi.inputSearchId).value //content is now the value of the text box
			var words = content.trim().split(/\s+/); //words is an array of words, split by space
			var num_words = words.length; //num_words is the number of words in the array
			
			if(num_words>20){
				//too many words
				return false;
			}

		},


		executeNewSearch: function(e){
			if (e.which != 17 && e.which != 18 && e.which != 27) {
				selfApi.initSearch();
				selfApi.cleanPage();						
			}
		},

		init: function () {
			selfApi = this; //prevent the parameter 'this' overlay inside functions

			var initSearch = function () {

				selfApi.client = new AddSearchClient(selfApi.idClient);
				selfApi.client.setFuzzyMatch(false);  //prevent similiar results to show
				selfApi.client.setCollectAnalytics(false); //remove from analytics to not to be duplicated

				//window.addEventListener('resize', selfApi.ggestions);
				window.addEventListener('resize', selfApi.adjustHeaderHeight);

				document.getElementById(selfApi.inputSearchId).addEventListener("keyup", selfApi.delayPressKey(function (e) {
					selfApi.limitInputChar();
					selfApi.executeNewSearch(e);
				}, 250));

				document.getElementById(selfApi.inputSearchId).addEventListener("keyup", selfApi.delayPressKey(function (e) {
					if (selfApi.term != "" && selfApi.term != null) {
						selfApi.client.sendStatsEvent('search', selfApi.term, { numberOfResults: selfApi.total_hits });
					}
				}, 2000));

				document.getElementById("searchButton").addEventListener("click", selfApi.executeNewSearch);
				document.getElementById("searchButton").addEventListener('touchstart', selfApi.executeNewSearch);
			};

			//if (ECB.slow.cookies.hasAcceptedCookies()) {
				ECB.slow.getScript("/shared/dist/js/require/addsearch-js-client.min.js", true, 'text/javascript', function () {
					initSearch();
				});
			//}
		}

	};

	return AddsearchApi;

	
}();
ECB.slow.additional = function () {
    if (document.querySelectorAll('main > .ecb-pressCategory').length > 0) {
        var ecbPressCategory = document.querySelectorAll("main > .ecb-pressCategory");
        for (var i = 0; i < ecbPressCategory.length; i++) {
            ecbPressCategory[i].style.display = "none";
        }
    }
    // Adds .section to .orderedlist
    if (document.querySelectorAll('main > .orderedlist').length > 0) {
        var orderedList = document.querySelectorAll("main > .orderedlist");
        for (var i = 0; i < orderedList.length; i++) {
            orderedList[i].classList.add("section");
        }
    }
}

function stringToDate(myString){
	var arr = myString.split('-');
	var res = new Date(arr[2] + "-" + arr[1] + "-" + arr[0]);
	return res;
}
var monthNames = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
ECB.slow.amChart = function () {	
	

function getChartSettings(chartData, chartDataInverse) {
// CHART CONFIG

	if(typeof currencyCode === 'undefined') {
		currencyCode= location.href.substr(location.href.lastIndexOf('-')+1,3);
	}

	return {	
		"type": 			"stock",
		"theme": 		"light",
		"fontFamily":   "Verdana",
		"fontSize":     "11",
		"pathToImages":   "/shared/js/amcharts/images/",
		"dataDateFormat": "dd/mm/yyyy", 				
		amExport:{
			top:         0, 
			exportJPG: true,
			exportPNG: true,
			buttonColor: '#e3e9e3',
			buttonRollOverColor: '#ffffff',
			textRollOverColor: '#000000' 
		}, 		
		
		dataSets: [{
				title: 'EUR vs. '+currencyCode.toUpperCase(),
				dataProvider: chartData,
				fieldMappings: [{
					fromField: "rate",
					toField:   "value"
				}],
				categoryField: "date",
				showInCompare: false,
				color: 		   "#0000dd"
			},
			{
				title: currencyCode.toUpperCase()+' vs. EUR',
				dataProvider: chartDataInverse,
				fieldMappings: [{
					fromField: "rate",
					toField: "value"
				}],
				categoryField: "date",
				showInCompare: false,
				color: "#336600"
			}
		], 
		
		panels: [{
				showCategoryAxis: true,
				title: "Euro foreign exchange reference rate",
				stockGraphs: [{
					id: "graph1",
					valueField: "value",
					type: "line",							
					fillAlphas: 0,
					bullet:"round",					
					hideBulletsCount:30,
					showAllValueLabels:true,
					comparable: false,
					compareField: "value",
					balloonText: "[[category]]: <b>[[value]]</b>",
					balloonColor:"#777"
				}]
		}],
		panelsSettings: {
			startDuration: 1,
			marginLeft:60
		},
		categoryAxesSettings: {
			dashLength: 0,
			maxSeries: 10000,
			color:"#777777"
		},
		valueAxesSettings: {
			dashLength: 0,
			color:"#777777",
			inside:false
		},
		chartScrollbarSettings: {
			graph: "graph1",
			height:60,
			backgroundColor:"#ddd",
			graphType: "line"
		},
		chartCursorSettings: {
			categoryBalloonDateFormats: [{period:"DD", format:"DD MMMM YYYY"}], 
			valueBalloonsEnabled: true,
			bulletsEnabled: true,
			pan:true
		},
		
		periodSelector: {
			position: "top",
			periods: [{
				period: "MM",
				count: 1,
				label: "1m"
			}, {
				period: "MM",
				count: 3,
				label: "3m"
			}, {
				period: "MM",
				count: 6,
				label: "6m"
			}, {
				period: "YYYY",
				selected: true,
				count: 1,
				label: "1y"
			}, {
				period: "YYYY",
				count: 2,
				label: "2y"
			}, {
				period: "YYYY",
				count: 5,
				label: "5y"
			}, {
				period: "YYYY",
				count: 10,
				label: "10y"
			}, {
				period: "MAX",
				label: "all"
			}]
		},
		
		dataSetSelector: {
			position: "top"
		} 		
		
	}	
}

function addDaysToDate(someDate, days) {
	someDate.setDate(someDate.getDate() + days);
	return someDate;
}	


function GetJSONIndex(obj, valToFind, fromToType) {
	var i = 0, key = 0;
	
	for (key in obj) {
		if (obj[key].date.getDate() == valToFind.getDate() && obj[key].date.getMonth() == valToFind.getMonth() && obj[key].date.getFullYear() == valToFind.getFullYear()) {
			return parseInt(key);
		}
		i++;
	}
	
	valToFind = (fromToType === "start") ? addDaysToDate(valToFind, 1) : addDaysToDate(valToFind, -1);
	
	return GetJSONIndex(obj, valToFind, fromToType);
}


function minMaxAvgRate(myChartData, index0, index1){
	var res = [];
	
	res.min 	 = myChartData[index0].rate;
	res.min_date = '';
	
	res.max 	 = myChartData[index1].rate;
	res.max_date = '';
	
	res.avg = 0;
	
	for (i=index0; i<=index1; i++){
		if(myChartData[i].rate <= res.min){
			res.min 	 = myChartData[i].rate;
			res.min_date = myChartData[i].date.getDate() + ' ' + monthNames[myChartData[i].date.getMonth()] + ' ' + myChartData[i].date.getFullYear();
		}
		if(myChartData[i].rate >= res.max){
			res.max 	 = myChartData[i].rate;
			res.max_date = myChartData[i].date.getDate() + ' ' + monthNames[myChartData[i].date.getMonth()] + ' ' + myChartData[i].date.getFullYear();
		}
		res.avg += myChartData[i].rate;
	}
	res.avg = res.avg / (index1 - index0 +1);
	return res;
}


function updateDownloadFname(myChart, dateStart, dateEnd){
	var newImgFname    = "ECBExchangeRate";
	var myChartDataSet = myChart.mainDataSet.id;//ds1 or ds2

	if(myChartDataSet === "ds1"){
		newImgFname += "EURvs" + currencyCode.toUpperCase();
	}else{
		newImgFname += currencyCode.toUpperCase() + "vsEUR";
	}
	
	newImgFname += "_" + dateStart + "_" + dateEnd;
	
	myChart.AmExport.cfg.menuItemOutput.fileName = newImgFname;
	myChart.AmExport.setup();
}

function refreshMinMaxAvg(chart,chartData, chartDataInverse){	
	var myChartData;
	
	var $dt = document.querySelectorAll("input.amChartsInputField");


	updateDownloadFname(chart, $dt[0].value, $dt[1].value);
	
	var currentDataSet = chart.mainDataSet.id;//ds1 or ds2
	diffClass='pos';
	if(currentDataSet == "ds1"){
		if (parseFloat(rateDiff) < 0)diffClass='neg';
		document.querySelector('.-exchange-rates .embed-basic-info').innerHTML = "<div class='embed-rate'><div class='date'>"+dateLatest+"</div><span>EUR 1 = "+currencyCode.toUpperCase()+" "+rateLatest+"<span class='"+diffClass+"'> <span class='diff'>"+rateDiff+"</span>(<span class='percent'>"+ percentage +")</span></span></span></div><div class='table'><div class='table-header'><div class='text'>Change from <span id='map-start-date'></span> to <span id='map-end-date'></span></div></div><div class='table-content' id='map-min-max-avg'></div></div>";
		myChartData = chartData;
		nrDec       = nrDecimals;
	}else{
		if (parseFloat(rateDiffInverse) < 0)diffClass='neg';
		document.querySelector('.-exchange-rates .embed-basic-info').innerHTML = "<div class='embed-rate'><div class='date'>"+dateLatest+"</div><span>"+currencyCode.toUpperCase()+" 1 = EUR "+rateLatestInverse+"<span class='"+diffClass+"'> <span class='diff'>"+rateDiffInverse+"</span>(<span class='percent'>"+ percentage +")</span></span></span></div><div class='table'><div class='table-header'><div class='text'>Change from <span id='map-start-date'></span> to <span id='map-end-date'></span></div></div><div class='table-content' id='map-min-max-avg'></div></div>";
		myChartData = chartDataInverse;
		nrDec       = nrDecimalsInverse;
	}

	var pattern = /(\d{2})\/(\d{2})\/(\d{4})/;

	var startDate = new Date($dt[0].value.replace(pattern,'$3-$2-$1'));
	if(Object.prototype.toString.call(startDate) === "[object Date]" && isNaN(startDate .getTime()) && startDate < myChartData[0].date)
		startDate = myChartData[0].date;
	var endDate = new Date($dt[1].value.replace(pattern,'$3-$2-$1'));
	if(Object.prototype.toString.call(endDate) === "[object Date]" && isNaN(endDate.getTime()) && endDate > myChartData[myChartData.length-1].date)
		endDate = myChartData[myChartData.length-1].date;


	var indexStart = GetJSONIndex(myChartData, startDate, "start");
	var indexEnd   = GetJSONIndex(myChartData, endDate, "end");
	
	
	var resultMinMaxAvg = minMaxAvgRate(myChartData, indexStart, indexEnd);

	if(indexEnd >= indexStart){
		document.getElementById('map-min-max-avg').innerHTML = "<div class='table-content-row'><div class='text'>Min ("+ resultMinMaxAvg.min_date +")</div><div class='number'>"+ resultMinMaxAvg.min.toFixed(nrDec) +"</div></div><div class='table-content-row'><div class='text'>Max ("+ resultMinMaxAvg.max_date +")</div><div class='number'>"+ resultMinMaxAvg.max.toFixed(nrDec) +"</div></div><div class='table-content-row'><div class='text'>Average</div><div class='number'>"+ resultMinMaxAvg.avg.toFixed(nrDec) +"</div></div>";
	}else{
		document.getElementById('map-min-max-avg').innerHTML = ("<strong>ECB did not publish any reference exchange rate for the period selected.</strong>");
	}

	document.getElementById('map-start-date').innerHTML = (startDate.getDate()  + " " + monthNames[startDate.getMonth()] + " " + startDate.getFullYear());
	document.getElementById('map-end-date').innerHTML = (endDate.getDate()  + " " + monthNames[endDate.getMonth()] + " " + endDate.getFullYear());
	
	
	

}


function generateHTML5Chart(refresh) {

	var chartData = generateChartData();
	var chartDataInverse = generateChartDataInverse();

	diffClass='pos';

	if (parseFloat(rateDiff) < 0)diffClass='neg';
	document.querySelector('.-exchange-rates .upper').innerHTML ="<div class='content-box'><h3>ECB euro reference exchange rate</h3></div><div class='embed-basic-info'><div class='embed-rate'><div class='date'>"+dateLatest+"</div><span>EUR 1 = "+currencyCode.toUpperCase()+" "+rateLatest+"<span class='"+diffClass+"'> <span class='diff'>"+rateDiff+"</span>(<span class='percent'>"+ percentage +")</span></span></span></div><div class='table'><div class='table-header'><div class='text'>Change from <span id='map-start-date'></span> to <span id='map-end-date'></span></div></div><div class='table-content' id='map-min-max-avg'></div></div></div>"
	document.getElementById('chart-container').innerHTML = "";
	var embedOptions = "";
	embedOptions += "<div class='embed-options'>";
	embedOptions +=		"<div><label for='dropdownx'>Select</label>";
	embedOptions +=			"<div id='dropdownx' class='dropdown'><span class='icon'></span><select id='datasetdropdown'></select></div>";
	embedOptions +=		"</div>";
	embedOptions += "<div></div>";
	/* embedOptions += 	"<div><label for='dropdowny'>Download</label><div id='dropdowny' class='dropdown'><span class='icon'></span><select><option value='op1'>Select format and download graph</option><option value='op2'>Select format and download table</option><option value='op3'>Option 3</option></select></div></div>"; */
	embedOptions += "<div class='date-range' id='daterange'></div>";
	embedOptions += "<div class='zoom-range' id='zoomrange'></div>";
	embedOptions += "</div>";

	document.querySelector('.-exchange-rates .upper').innerHTML += embedOptions;
	document.getElementById('chart-container').innerHTML +=('<div id="chartdiv"></div>');

	
	document.getElementById('loading-data').style.display = 'none';	

	var chart = AmCharts.makeChart("chartdiv", getChartSettings(chartData, chartDataInverse));
	
	if(chart.chartCreated){
		refreshMinMaxAvg(chart, chartData, chartDataInverse);		
	}
	chart.addListener('drawn', function (event){
		refreshMinMaxAvg(chart, chartData, chartDataInverse);		
	});
	if(refresh === true){
		refreshMinMaxAvg(chart, chartData, chartDataInverse);
	}

}

	(function() {
		//Temporary to fix old layout
		document.getElementById('flexChart').setAttribute('id','chart-container');
		//document.getElementById('chart-container').style.visibility = 'hidden';

		//Always choose html5 chart as default

		AmCharts.themes.light = {

			themeName:"light",
		
			AmChart: {
				color: "#000000", 
				backgroundColor: "#FFFFFF"
			},
		
			AmCoordinateChart: {
				colors: ["#67b7dc", "#fdd400", "#84b761", "#cc4748", "#cd82ad", "#2f4074", "#448e4d", "#b7b83f", "#b9783f", "#b93e3d", "#913167"]
			},
		
			AmStockChart: {
				colors: ["#67b7dc", "#fdd400", "#84b761", "#cc4748", "#cd82ad", "#2f4074", "#448e4d", "#b7b83f", "#b9783f", "#b93e3d", "#913167"]
			},
		
			AmSlicedChart: {
				colors: ["#67b7dc", "#fdd400", "#84b761", "#cc4748", "#cd82ad", "#2f4074", "#448e4d", "#b7b83f", "#b9783f", "#b93e3d", "#913167"],
				outlineAlpha: 1,
				outlineThickness: 2,
				labelTickColor: "#000000",
				labelTickAlpha: 0.3
			},
		
			AmRectangularChart: {
				zoomOutButtonColor: '#000000',
				zoomOutButtonRollOverAlpha: 0.15,
				zoomOutButtonImage: "lens.png"
			},
		
			AxisBase: {
				axisColor: "#000000",
				axisAlpha: 0.3,
				gridAlpha: 0.1,
				gridColor: "#000000"
			},
		
			ChartScrollbar: {
				backgroundColor: "#000000",
				backgroundAlpha: 0.12,
				graphFillAlpha: 0.5,
				graphLineAlpha: 0,
				selectedBackgroundColor: "#FFFFFF",
				selectedBackgroundAlpha: 0.4,
				gridAlpha: 0.15
			},
		
			ChartCursor: {
				cursorColor: "#000000",
				color: "#FFFFFF",
				cursorAlpha: 0.5
			},
		
			AmLegend: {
				color: "#000000"
			},
		
			AmGraph: {
				lineAlpha: 0.9
			},
			GaugeArrow: {
				color: "#000000",
				alpha: 0.8,
				nailAlpha: 0,
				innerRadius: "40%",
				nailRadius: 15,
				startWidth: 15,
				borderAlpha: 0.8,
				nailBorderAlpha: 0
			},
		
			GaugeAxis: {
				tickColor: "#000000",
				tickAlpha: 1,
				tickLength: 15,
				minorTickLength: 8,
				axisThickness: 3,
				axisColor: '#000000',
				axisAlpha: 1,
				bandAlpha: 0.8
			},
		
			TrendLine: {
				lineColor: "#c03246",
				lineAlpha: 0.8
			},
		
			// ammap
			AreasSettings: {
				alpha: 0.8,
				color: "#67b7dc",
				colorSolid: "#003767",
				unlistedAreasAlpha: 0.4,
				unlistedAreasColor: "#000000",
				outlineColor: "#FFFFFF",
				outlineAlpha: 0.5,
				outlineThickness: 0.5,
				rollOverColor: "#3c5bdc",
				rollOverOutlineColor: "#FFFFFF",
				selectedOutlineColor: "#FFFFFF",
				selectedColor: "#f15135",
				unlistedAreasOutlineColor: "#FFFFFF",
				unlistedAreasOutlineAlpha: 0.5
			},
		
			LinesSettings: {
				color: "#000000",
				alpha: 0.8
			},
		
			ImagesSettings: {
				alpha: 0.8,
				labelColor: "#000000",
				color: "#000000",
				labelRollOverColor: "#3c5bdc"
			},
		
			ZoomControl: {
				buttonRollOverColor: "#3c5bdc",
				buttonFillColor: "#3994e2",
				buttonBorderColor: "#3994e2",
				buttonFillAlpha: 0.8,
				gridBackgroundColor: "#FFFFFF",
				buttonBorderAlpha:0,
				buttonCornerRadius:2,
				gridColor:"#FFFFFF",
				gridBackgroundColor:"#000000",
				buttonIconAlpha:0.6,
				gridAlpha: 0.6,
				buttonSize:20
			},
		
			SmallMap: {
				mapColor: "#000000",
				rectangleColor: "#f15135",
				backgroundColor: "#FFFFFF",
				backgroundAlpha: 0.7,
				borderThickness: 1,
				borderAlpha: 0.8
			},
		
			// the defaults below are set using CSS syntax, you can use any existing css property
			// if you don't use Stock chart, you can delete lines below
			PeriodSelector: {
				color: "#000000"
			},
		
			PeriodButton: {
				color: "#000000",
				background: "transparent",
				opacity: 0.7,
				border: "1px solid rgba(0, 0, 0, .3)",
				MozBorderRadius: "5px",
				borderRadius: "5px",
				margin: "1px",
				outline: "none",
				boxSizing: "border-box"
			},
		
			PeriodButtonSelected: {
				color: "#000000",
				backgroundColor: "#b9cdf5",
				border: "1px solid rgba(0, 0, 0, .3)",
				MozBorderRadius: "5px",
				borderRadius: "5px",
				margin: "1px",
				outline: "none",
				opacity: 1,
				boxSizing: "border-box"
			},
		
			PeriodInputField: {
				color: "#000000",
				background: "transparent",
				border: "1px solid rgba(0, 0, 0, .3)",
				outline: "none"
			},
		
			DataSetSelector: {
		
				color: "#000000",
				selectedBackgroundColor: "#b9cdf5",
				rollOverBackgroundColor: "#a8b0e4"
			},
		
			DataSetCompareList: {
				color: "#000000",
				lineHeight: "100%",
				boxSizing: "initial",
				webkitBoxSizing: "initial",
				border: "1px solid rgba(0, 0, 0, .3)"
			},
		
			DataSetSelect: {
				border: "1px solid rgba(0, 0, 0, .3)",
				outline: "none"
			}
		
		};

		// if(!AmCharts.isReady){
		// 	//we are in slow so window did already load
		// 	if(document.readyState == 'complete'){
		// 		console.log("completed loading");
		// 		AmCharts.handleLoad();
		// 		generateHTML5Chart(false);
		// 	}else{
		// 		console.log("delay loading");
		// 		window.addEventListener("load",function(){console.log("loading"); AmCharts.handleLoad(); generateHTML5Chart(false); });
		// 	}
		// 	//
		// }

		generateHTML5Chart(false);

		

	})();
	
	
}

ECB.slow.analytics = function(){
    
	
	var tagManagerID = {
		ecb: 'GTM-NVKFGW',
		ssm: 'GTM-KBQ65B',
		esrb: 'GTM-5TQRD7'
	};

    
    if (ECB.slow.cookies.hasAcceptedCookies()) {
        var id = tagManagerID[ECB.projectName];

        (function(w,d,s,l,i){
            w[l]=w[l]||[];
            w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});
            var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';
            j.async=true;
            j.src='//www.googletagmanager.com/gtm.js?id='+i+dl;
            f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer',id);
        
    }
	

    
}   
var ECB = window.ECB || {};

// var isInitialized = false;
ECB.slow.asyncContent = function (rootNode, selectors, observerConfig) {
    
    document.addEventListener("asyncNodeLoaded", function(e){ 
        console.log("asyncNodeLoaded")
        ECB.fast.loadImages(e.target);
        ECB.slow.accordion(e.target);  
        if (e.target.querySelector(".-filter")){
            ECB.slow.filter(e.target)
        }
        if (e.target.querySelectorAll(".ecb-langSelector").length > 0){
            ECB.slow.languageVersions(e.target);
        }

        ECB.fast.langLinks();
    });

    document.addEventListener("homepageBoxUpdated", function(e){         
        if (e.target.getAttribute("data-image")){
            ECB.fast.loadImages(e.target.parentElement);
        }            
        else{
            ECB.fast.loadImages(e.target);
        }   
        
        ECB.fast.langLinks();

            // ECB.cookies.updateNotWorkingMessages();
        if (e.target.querySelectorAll(".ecb-langSelector").length > 0){
            ECB.slow.languageVersions(e.target);
        }
        ECB.slow.accordion(e.target);  

    });

    /*
    if (isInitialized)
        return; // do not run more than once

    var root = rootNode;
    if (!root)
        root = "body";

    var asyncSelectors = selectors;
    if (!asyncSelectors)
        asyncSelectors = "#lazyload-container";

    asyncSelectors = root + " " + asyncSelectors.replace(/,/g, ","+rootNode+" ");

    var observerConf = observerConfig;
    if (!observerConf)
        observerConf = {childList: true}

    var observers = [];
    var asyncNodes = document.querySelectorAll(asyncSelectors);

    console.log(asyncSelectors, asyncNodes, asyncNodes.length);
    for (i = 0; i < asyncNodes.length; i++) {
        observers[i] = new MutationObserver(function(mutationList, observer){
            console.log("async change detected +i");
        });

        observers[i].observe(asyncNodes[i], observerConf);
    }

    isInitialized = true; */
};

ECB.slow.bahamaDevices = function () {
	var es_search_field = false;
	var input = '';
	var lan = '';
	var tou = '';
	var width_tab = 0;

	$(document).ready (function() {
		var title = $('#ecb-content-col h1:first-child ').html();
		var code = $("a[href^='device_print_pdf']").attr("href");
		code = code+'&title='+title;
		$("a[href^='device_print_pdf']").attr("href",code);
		
		$('#bahamaQuerySearch').on('keydown', function(event) {
			var x = event.which;
			if (x === 13) {
				event.preventDefault();
			}
		});
		
		$('#bahamaQuerySearch').on ('keyup', function(event){
			if($('input#bahamaQuerySearch').val()!=""){
				input = $('input#bahamaQuerySearch').val();
				lan = $('input#bahamaLang').val();
				tou = $('input#typeofuserDEV').val();
				
				if( ((String.fromCharCode(event.which).match(/\w/)) && ($('input#bahamaQuerySearch').val()=="es2")) ||
						((String.fromCharCode(event.which).match(/\w/)) && ($('input#bahamaQuerySearch').val()=="es1"))){
					$('input#bahamaQuerySearch').after('  <input type="text"/ id="es_search_field">');
				
					es_search_field = true;
					notesTypeKeyUp(); //TO CHECK if it's needed or not!!!
				}
				else if ( (es_search_field == true)){
						es_search_field = false;
						$("#es_search_field").remove();
				}
				
				$.ajax({
					async:true,
					type:'POST',
					url: '/euro/cashprof/cashhand/shared/script/dispatcher.php',
					data: {"q" : input, "lan" : lan,"tou" : tou},
					dataType: 'html',
					success: function( response ) {
						$( '#livesearch' ).html(response);
						if($('#livesearch:hidden'))$( '#livesearch' ).slideDown('blind');
						if(width_tab==0){
							width_tab = $('#bahama_table_search_result').width();
						}

						$('tr td:first-child').prepend('<span class="toggleRow"></span>');
						$(".toggleRow").on('click',function(e){
							$(this).closest('tr').find('.showBahDet').click();
						});

						$('.showBahDet').on('click',function(e){
							var idMac = $(this).attr('id');
							title=$(this).text();
							
							if($(this).parent().parent().next().hasClass('toggleOpened')){
								$(this).parent().parent().next().removeClass('toggleOpened').toggle();
								$('tr#tr_'+idMac+" td div").empty();
								$('tr#tr_'+idMac).prev().toggleClass('toggleSelected');
							}
							else{
								$(this).parent().parent().next().toggle();
								$(this).parent().parent().next().addClass('toggleOpened');
								$('tr#tr_'+idMac).prev().toggleClass('toggleSelected');
																										
								$.ajax({
									async:true,
									type:'POST',
									url: '/euro/cashprof/cashhand/shared/script/dispatcher.php',
									data: {"idMac" : idMac, "lan" : lan, "tou" : tou},
									dataType: 'html',
									success: function( response ) {
										$('tr#tr_'+idMac+" td div").append(response);
									}
								});
							}
						});
					}
				});
			}
			else{
				$( '#livesearch' ).hide();
			}
		});		
});//end document ready

	function notesTypeKeyUp(){
		$('input#es_search_field').on("keyup",function(eventBan){
			console.debug(String.fromCharCode(eventBan.keyCode));
			if( (String.fromCharCode(eventBan.keyCode).match(/5{1}|10{2}|e{1}|a{1}|`{1}/))){   //
				bnotes = $('input#es_search_field').val();
				$.ajax({
					async:true,
					type:'POST',
					url: '/euro/cashprof/cashhand/shared/script/dispatcher.php',
					data: {"q" : input, "lan" : lan, "tou" : tou, "bnotes" : bnotes},
					dataType: 'html',
					success: function( response ) {
						$( '#livesearch' ).html(response);
						if($('#livesearch:hidden'))$( '#livesearchMCO' ).slideDown('blind');
						if(width_tab==0){
							width_tab = $('#bahama_table_search_result').width();
						}

						$('tr td:first-child').prepend('<span class="toggleRow"></span>');
						$(".toggleRow").on('click',function(e){
							$(this).closest('tr').find('.showBahDet').click();
						});

						$('.showBahDet').on('click',function(e){
							/*var idMac = $(this).attr('id');
							title=$(this).text();
																									
							$.ajax({
								async:true,
								type:'POST',
								url: '/euro/cashprof/cashhand/shared/script/dispatcher.php',
								data: {"idMac" : idMac, "lan" : lan, "tou" : tou},
								dataType: 'html',
								success: function( response ) {
									$('#'+idMac).closest("tr").after("<tr colspan=5 class='ecb-toggleContainer'>"+response+'</tr>');
									$('#popup').html(response);
									$("#popup").dialog({
										modal:true,
										width:'90%',
										resizable:false,
										
										title:'Details for: '+title										
									});
								}
							});*/
							var idMac = $(this).attr('id');
							title=$(this).text();
							
							if($(this).parent().parent().next().hasClass('toggleOpened')){
								$(this).parent().parent().next().removeClass('toggleOpened').toggle();
								$('tr#tr_'+idMac+" td div").empty();
								$('tr#tr_'+idMac).prev().toggleClass('toggleSelected');
							}
							else{
								$(this).parent().parent().next().toggle();
								$(this).parent().parent().next().addClass('toggleOpened');
								$('tr#tr_'+idMac).prev().toggleClass('toggleSelected');
																										
								$.ajax({
									async:true,
									type:'POST',
									url: '/euro/cashprof/cashhand/shared/script/dispatcher.php',
									data: {"idMac" : idMac, "lan" : lan, "tou" : tou},
									dataType: 'html',
									success: function( response ) {
										$('tr#tr_'+idMac+" td div").append(response);
									}
								});
							}
						});
					}
				});
			}
		});
	}
}
ECB.slow.bahamaRecycling = function () {
	var es_search_field = false;
	var input = null ;
	var lan = null;
	var tou = null;
	var width_tab = 0;

	$(document).ready (function() {
		var title = $('#ecb-content-col h1:first-child ').html();
		if($("a[href^='pdfTableMCO']").length>0){
			var code = $("a[href^='pdfTableMCO']").attr("href");
			code = code+'?title='+title;
			$("a[href^='pdfTableMCO']").attr("href",code);	
		}
		
		if($("a[href^='pdfTableMSO']").length>0){
			var code = $("a[href^='pdfTableMSO']").attr("href");
			code = code+'?title='+title;
			$("a[href^='pdfTableMSO']").attr("href",code);	
		}
		
		$('#bahamaQuerySearchMCO').on('keydown', function(event) {
			var x = event.which;
			if (x === 13) {
				event.preventDefault();
			}
		});
		
		$('#bahamaQuerySearchMCO').on("keyup",function(event){	
			
			
			
			if($('input#bahamaQuerySearchMCO').val()!=""){
				input = $('input#bahamaQuerySearchMCO').val();
				lan = $('input#bahamaLangMCO').val();
				tou = $('input#typeofuserMCO').val();
				if( ((String.fromCharCode(event.which).match(/\w/)) && ($('input#bahamaQuerySearchMCO').val()=="es2")) || 
						((String.fromCharCode(event.which).match(/\w/)) && ($('input#bahamaQuerySearchMCO').val()=="es1"))){
					$('input#bahamaQuerySearchMCO').after('   <input type="text"/ id="es_search_field">');
				
					es_search_field = true;
					notesTypeKeyUp('MCO');
				} else if ( (es_search_field == true)){
					es_search_field = false;
					$("#es_search_field").remove();
				}
				
				$.ajax({
					async:true,
					type:'POST',
					url: '/euro/cashprof/cashhand/shared/script/dispatcher.php',
					data: {"q" : input, "lan" : lan, "tou" : tou},
					dataType: 'html',
					success: function( response ) {
						$( '#livesearchMCO' ).html(response);
						if($('#livesearchMCO:hidden'))$( '#livesearchMCO' ).slideDown('blind');
						if(width_tab==0){
							width_tab = $('#bahama_table_search_result').width();
						}

						$('tr:not(.toggleContainer) td:first-child').prepend('<span class="toggleRow"></span>');
						$(".toggleRow").on('click',function(e){
							$(this).closest('tr').find('.showBahDet').click();
						});

						$('.showBahDet').on('click',function(e) {
							var idMac = $(this).attr('id');
							title=$(this).text();
							
							if ($(this).parent().parent().next().hasClass('toggleOpened')){
								$(this).parent().parent().next().removeClass('toggleOpened').toggle();
								$('tr#tr_'+idMac+" td div").empty();
								$('tr#tr_'+idMac).prev().toggleClass('toggleSelected');
							} else {
								$(this).parent().parent().next().toggle();
								$(this).parent().parent().next().addClass('toggleOpened');
								$('tr#tr_'+idMac).prev().toggleClass('toggleSelected');

								$.ajax({
									async:true,
									type:'POST',
									url: '/euro/cashprof/cashhand/shared/script/dispatcher.php',
									data: {"idMac" : idMac, "lan" : lan, "tou" : tou},
									dataType: 'html',
									success: function( response ) {
										$('tr#tr_'+idMac+" td div").append(response);
									}
								});
							}
						});
					}
				});
			}
			else{
				$( '#livesearchMCO' ).hide();
			}
		});		
		
		$('#bahamaQuerySearchMSO').on('keydown', function(event) {
			var x = event.which;
			if (x === 13) {
				event.preventDefault();
			}
		});

		$('#bahamaQuerySearchMSO').on('keyup',function(event){
			if($('input#bahamaQuerySearchMSO').val()!=""){
				input = $('input#bahamaQuerySearchMSO').val();
				lan = $('input#bahamaLangMSO').val();
				tou = $('input#typeofuserMSO').val();
				if( ((String.fromCharCode(event.which).match(/\w/)) && ($('input#bahamaQuerySearchMSO').val()=="es2")) || 
						((String.fromCharCode(event.which).match(/\w/)) && ($('input#bahamaQuerySearchMSO').val()=="es1"))){
					$('input#bahamaQuerySearchMSO').after('   <input type="text"/ id="es_search_field">');
					es_search_field = true;
					notesTypeKeyUp('MSO');
				} else if ( (es_search_field == true)){
						es_search_field = false;
						$("#es_search_field").remove();
				}

				$.ajax({
					async:true,
					type:'POST',
					url: '/euro/cashprof/cashhand/shared/script/dispatcher.php',
					data: {"q" : input, "lan" : lan, "tou" : tou},
					dataType: 'html',
					success: function( response ) {
						$( '#livesearchMSO' ).html(response);
						if($('#livesearchMSO:hidden'))$( '#livesearchMSO' ).slideDown('blind');
						if(width_tab==0){
							width_tab = $('#bahama_table_search_result').width();
						}

						$('tr:not(.toggleContainer) td:first-child').prepend('<span class="toggleRow"></span>');
						$(".toggleRow").on('click',function(e){
							$(this).closest('tr').find('.showBahDet').click();	
						});

						$('.showBahDet').click(function(e){
							var idMac = $(this).attr('id');
							title=$(this).text();
							
							if($(this).parent().parent().next().hasClass('toggleOpened')){
								$(this).parent().parent().next().removeClass('toggleOpened').toggle();
								$('tr#tr_'+idMac+" td div").empty();
								$('tr#tr_'+idMac).prev().toggleClass('toggleSelected');
							} else {
								$(this).parent().parent().next().toggle();
								$(this).parent().parent().next().addClass('toggleOpened');
								$('tr#tr_'+idMac).prev().toggleClass('toggleSelected');
																										
								$.ajax({
									async:true,
									type:'POST',
									url: '/euro/cashprof/cashhand/shared/script/dispatcher.php',
									data: {"idMac" : idMac, "lan" : lan, "tou" : tou},
									dataType: 'html',
									success: function( response ) {
										$('tr#tr_'+idMac+" td div").append(response);
									}
								});
							}
						});
					}
				});
			} else {
				$( '#livesearchMSO' ).hide();
			}
		});		
	});

	function notesTypeKeyUp(strField){
		$('input#es_search_field').on("keyup",function(eventBan){
			if( (String.fromCharCode(eventBan.keyCode).match(/5{1}|10{1}|e{1}|a{1}|`{1}/))){
				bnotes = $('input#es_search_field').val();

				$.ajax({
					async:true,
					type:'POST',
					url: '/euro/cashprof/cashhand/shared/script/dispatcher.php',
					data: {"q" : input, "lan" : lan, "tou" : tou, "bnotes" : bnotes},
					dataType: 'html',
					success: function( response ) {
						$( '#livesearch'+strField).html(response);
						if($('#livesearch'+strField+':hidden'))$( '#livesearch'+strField ).slideDown('blind');
						if(width_tab==0){
							width_tab = $('#bahama_table_search_result').width();
						}

						$('tr:not(.toggleContainer) td:first-child').prepend('<span class="toggleRow"></span>');
						$(".toggleRow").on('click',function(e){
							$(this).closest('tr').find('.showBahDet').click();
						});

						$('.showBahDet').on('click',function(e){	
							var idMac = $(this).attr('id');
							title=$(this).text();
							
							if ($(this).parent().parent().next().hasClass('toggleOpened')) {
								$(this).parent().parent().next().removeClass('toggleOpened').toggle();
								$('tr#tr_'+idMac+" td div").empty();
								$('tr#tr_'+idMac).prev().toggleClass('toggleSelected');
							} else {
								$(this).parent().parent().next().toggle();
								$(this).parent().parent().next().addClass('toggleOpened');
								$('tr#tr_'+idMac).prev().toggleClass('toggleSelected');
																										
								$.ajax({
									async:true,
									type:'POST',
									url: '/euro/cashprof/cashhand/shared/script/dispatcher.php',
									data: {"idMac" : idMac, "lan" : lan, "tou" : tou},
									dataType: 'html',
									success: function( response ) {
										$('tr#tr_'+idMac+" td div").append(response);
									}
								});
							}
						});
					}
				});
			}
		});
	}
}
ECB.slow.breadcrumbs = function(){

    var init = function(){

        var breadcrumbs = document.getElementById("ecb-breadcrumbwrapper");

        if(typeof(breadcrumbs) != 'undefined' && breadcrumbs != null) {

            var breadcrumbStr = "<a href=\"/\">Home</a>"; // TODO: enable the translation of the Home word
            var pathPartsStr = "";

            for (var i = 0; i < ECB.slow.navigationPath.length; i++) {
                var node = ECB.slow.navigationPath[i];
                pathPartsStr+=node.pathPart+"/";
                breadcrumbStr+="<a href=\"/"+pathPartsStr+"html/index."+ECB.currentLanguage+".html"+"\">"+node.name+"</a>";
            }

            breadcrumbs.innerHTML = breadcrumbStr;   
        }

    }
    
    //load breadcrumbs when menu is available
    ECB.slow.menu.addMenuLoadedHook(init);
}
ECB.slow.breakpoints = function () {
    var updateBreakpoint = function () {
        var breakpoint = window.getComputedStyle(document.body, ':before').getPropertyValue('content');

        if (breakpoint.substr(0, 1) === '"') {
            breakpoint = breakpoint.substr(1, breakpoint.length - 2);
        }

        ECB.slow.currentBreakpoint = breakpoint;
    }

    updateBreakpoint();
    window.addEventListener('resize', ECB.slow.debounce(updateBreakpoint, 100));
};

ECB.slow.isMobile = function () {
    return ECB.slow.currentBreakpoint.substring(0, 10) == "smartphone";
}
var ECB = window.ECB || {};

ECB.slow.componentHandlerFactory = function (functions, oneTimeFunctions) {
	var components = [];
	var waitingFunctionCalls = [];
	var lastIndexCalled = -1;


	var addComponents = function (newComponents) {
		if (Array.isArray(newComponents)) {
			components = components.concat(newComponents);
		} else {
			components.push(newComponents);
		}
		for (var i = 0; i < waitingFunctionCalls.length; i++) {
			var waitingCall = waitingFunctionCalls[i];
			if (window[waitingCall.pluginNameSpace] && window[waitingCall.pluginNameSpace][waitingCall.pluginName]) {
				window[waitingCall.pluginNameSpace][waitingCall.pluginName][waitingCall.functionToCall].apply(null, waitingCall.parameters);
			}
		}

	}

	var mapFunction = function (functionName) {
		return function () {
			for (i = 0; i < components.length; i++) {
				if(!components[i]){
					console.log("Warning undefined plugin found");
					continue;
				}

				
				if (
					components[i].hasOwnProperty(functionName) &&
					typeof (components[i][functionName]) == 'function'
				) {
					if(oneTimeFunctions&&oneTimeFunctions.indexOf(functionName)!=-1){
						if(lastIndexCalled>i){
							continue;
						}
					}
					components[i][functionName]();
				}
			}
			lastIndexCalled = components.length-1;
		};
	}



	var callWhenLoaded = function (pluginNameSpace, pluginName, functionToCall, parameters) {
		//check if plugin is there
		if (window[pluginNameSpace] && window[pluginNameSpace][pluginName]) {
			window[pluginNameSpace][pluginName][functionToCall](parameters);
		} else {
			//wait until the plugin is loaded so cue the call
			waitingFunctionCalls.push({
				"pluginNameSpace": pluginNameSpace,
				"pluginName": pluginName,
				"functionToCall": functionToCall,
				"parameters": parameters
			});
		}
	}

	var createComponentHandler = function () {
		var loader = {
			'addComponents': addComponents,
			'callWhenLoaded': callWhenLoaded
		}
		for (i = 0; i < functions.length; i++) {
			loader[functions[i]] = mapFunction(functions[i]);
		}
		return loader;
	}

	return createComponentHandler();


};
ECB.slow.cookies = (function () {

	var cookie = function (name, value, options) {

		var getCookie = function (name) {
			var nameEQ = name + "=";
			var ca = document.cookie.split(';');
			for (var i = 0; i < ca.length; i++) {
			  var c = ca[i];
			  while (c.charAt(0) == ' ') c = c.substring(1, c.length);
			  if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
			}
			return null;
		}	

		if (isValidChoice()) {
			if(typeof(value)=='undefined'){
				return getCookie(name);
			}
			optionsString = "";
			if(options){
				ECB.slow.forEach(Object.keys(optionsString),function(item){
					optionsString=" "+item+"="+options[item]+";";
				});
			}
			document.cookie = name+"="+value+";"+optionsString;
		} 
	}

	var cookieConsent, template;
	var currentChoice = window.localStorage.cookieChoice;
	var cookieDecisionTime = window.localStorage.cookieDecisionTime;
	var currentValidChoice = currentChoice ? currentChoice.split('_v')[0] : false ;
	var policyVersion = '1';
	// six months
	var expiration = 15552000000;

	var cookieStatusMessage = {
		"en":["Accepted","Not accepted"],
		"bg":["Приемане","Неприемане"],
		"cs":["přijaty","odmítnuty"],
		"da":["accepteret","ikke accepteret"],
		"de":["aktiviert","deaktiviert"],
		"el":["Αποδοχή","Μη αποδοχή"],
		"es":["aceptadas","no aceptadas"],
		"et":["Nõustun","Ei nõustu"],
		"fi":["sallittu","ei sallittu"],
		"fr":["acceptés","non acceptés"],
		"ga":["Glactar leis","Ní ghlactar leis"],
		"hr":["prihvaćeni","nisu prihvaćeni"],
		"hu":["elfogadva","visszautasítva"],
		"it":["accettato","non accettato"],
		"lt":["naudoti leidžiama","naudoti neleidžiama"],
		"lv":["akceptētas","nav akceptētas"],
		"mt":["Aċċettati","Mhux aċċettati"],
		"nl":["geaccepteerd","niet geaccepteerd"],
		"pl":["zaakceptowane","niezaakceptowane"],
		"pt":["aceites","não aceites"],
		"ro":["acceptate","refuzate"],
		"sk":["akceptované","neakceptované"],
		"sl":["sprejeti","niso sprejeti"],
		"sv":["godkända","inte godkända"]
	};

	var setCurrentCookieStatus = function(){

		var cookieMessageLanguage = ECB.language;

		if(!cookieStatusMessage[cookieMessageLanguage]){
			cookieMessageLanguage = 'en';
		}

		var status = cookieStatusMessage[cookieMessageLanguage][+!hasAcceptedCookies()];
		if(document.querySelector('#currentCookieStatus'))
			document.querySelector('#currentCookieStatus').innerHTML = status;
	}
	
	var getCookieVersion= function(){
		var parts = currentChoice.split('_v');
		currentValidChoice = parts[0];
		return parts[parts.length-1];
	}
	
	var hasAcceptedCookies = function(){
		if(isValidChoice()&&currentValidChoice=='accepted'){
			return true;
		}
		return false;
	}


	var initCookie = function () {
		cookieConsent = document.getElementById('cookieConsent');
		template = document.querySelector(".cookieBlockedMessage.template");

		bindActions();

		if(!isValidChoice()){
			showCookieConsent();
			clearCookies();
			attachNotWorkingMessages();
		}else if(!hasAcceptedCookies()){
			clearCookies();
			attachNotWorkingMessages();
		}
		setCurrentCookieStatus();

		if(document.getElementById('cookieButton')){
			document.getElementById('cookieButton').addEventListener("click", function () { switchCookieConsentContent('initial');showCookieConsent() });
		}	

		
	}

	var getCookieVersion = function () {
		var parts = currentChoice.split('_v');
		return parts[parts.length - 1];
	}

	var isValidChoice = function () {
		if (currentChoice) {
			cookieDecisionTime = parseInt(cookieDecisionTime);
			var currentTime = (new Date()).getTime();
			var parts = currentChoice.split('_v');
			if (getCookieVersion() == policyVersion) {
				if (currentTime - cookieDecisionTime > expiration) {
					switchCookieConsentContent('expired');
				} else {
					return true;
				}
			} else {
				switchCookieConsentContent('updated');
			}
		}
		window.localStorage.removeItem('cookieChoice');
		return false;
	}
	var showCookieConsent = function () {
		cookieConsent&&cookieConsent.classList.remove('hidden');		
	}

	var hideCookieConsent = function(){
		cookieConsent&&cookieConsent.classList.add('hidden');
	}

	var switchCookieConsentContent = function (contentClass) {
		if(cookieConsent) {
			var contentElements = cookieConsent.children;
			for (var i = 0; i < contentElements.length; i++) {
				contentElements[i].classList.add('hidden');
			}
			cookieConsent.querySelector('.' + contentClass).classList.remove('hidden');
		} 
	}
	var bindActions = function () {
		bindActionForContent('initial');
		bindActionForContent('updated');
		bindActionForContent('expired');
	}
	var bindActionForContent = function (contentClass) {
		if (cookieConsent){ 
			cookieConsent.querySelector('.consentButtons.' + contentClass + ' .check').onclick = function () { cookieChoice('accepted'); };
			cookieConsent.querySelector('.consentButtons.' + contentClass + ' .cross').onclick = function () { cookieChoice('refused'); };
		}
		
	}
	var cookieChoice = function (choice) {
		switchCookieConsentContent(choice);

		window.localStorage.cookieChoice = choice + '_v' + policyVersion;
		currentChoice = window.localStorage.cookieChoice;

		window.localStorage.cookieDecisionTime = trimDate(new Date()).getTime();
		cookieDecisionTime = window.localStorage.cookieDecisionTime;

		currentValidChoice = choice; 

		currentTimeout = window.setTimeout(hideCookieConsent,1500);

		if (choice == "refused") {
			clearCookies();	
			attachNotWorkingMessages();		
		}else{
			//ECB.slow.addSearchApi.init(); 
			ECB.slow.analytics();
			ECB.slow.feedback();
			ECB.slow.initSoundcloud();
			removeNotWorkingMessages();
		}

		
		
		setCurrentCookieStatus();
	}

	var trimDate=function(date){
		date.setMilliseconds(0);
		date.setSeconds(0);
		date.setMinutes(0);
		date.setHours(0);
		date.setDate(1);
		return date;
	}

	var clearCookies = function () {		
		var cookies = document.cookie.split("; ");
		for (var c = 0; c < cookies.length; c++) {
			var d = window.location.hostname.split(".");
			while (d.length > 0) {
				var cookieBase = encodeURIComponent(cookies[c].split(";")[0].split("=")[0]) + '=; expires=Thu, 01-Jan-1970 00:00:01 GMT; domain=' + d.join('.') + ' ;path=';
				var p = location.pathname.split('/');
				document.cookie = cookieBase + '/';
				while (p.length > 0) {
					document.cookie = cookieBase + p.join('/');
					p.pop();
				};
				d.shift();
			}
		}
	}

	var attachNotWorkingMessages = function(){
		removeNotWorkingMessages();
		addNotWorkingMessage('[data-video], .twitter_embed, [data-soundcloud-id]',true);
		//addNotWorkingMessage('.ecb-quickSearch',false);
	}

	var removeNotWorkingMessages = function(){

		removeNotworkingMessage('[data-video], .twitter_embed, [data-soundcloud-id]');		
	}


	var addNotWorkingMessage = function(selector, isInner){
		//update and set queryselectorAll and foreach if lenght is greater then 1
		
		
        
		ECB.slow.forEach(document.querySelectorAll(selector),function(item){			
			item.classList.add('refusedCookieBlocked');

			item.addEventListener('touchend', showMessageOnTouch(item), false);
			item.addEventListener('mouseover', showMessageOnTouch(item), false);
			
            var input = item.querySelector('input');
            input && input.setAttribute('disabled','true');							

			var blockedDivWrapper = document.createElement('div');

			if (template){
				blockedDivWrapper.innerHTML = template.outerHTML;
				var blockedDiv = blockedDivWrapper.children[0];
				
				if(isInner && blockedDiv){					
					blockedDiv.classList.add("innerCookieBlockedMessage");				
				}				
				item.appendChild(blockedDiv);
			}	
		});        
	}
	
	var removeNotworkingMessage = function(selector){
		ECB.slow.forEach(document.querySelectorAll(selector),function(item){
			item.classList.remove('refusedCookieBlocked');
			item.removeEventListener('touchend',showMessageOnTouch(item),false);
			item.removeEventListener('mouseover', showMessageOnTouch(item), false);			

			var blockMessage = item.querySelector('.cookieBlockedMessage');
			var inputField = item.querySelector('input');

			blockMessage && blockMessage.remove();			
			inputField && inputField.removeAttribute("disabled");

			
		});		
	}


	var showMessageOnTouch = function(item){
		var internalItem = item;
		return function(){
			if(!internalItem.classList.contains('active')){
				
				var cookieRefusedItem = internalItem.querySelector('.refusedCookieBlocked');

				if(cookieRefusedItem){
					cookieRefusedItem.classList.remove("active");									
				}
				internalItem.classList.add("active");
					
				// ECB.slow.utils.blockEventPropagation(item);
				window.setTimeout(function(){internalItem.classList.remove('active');},4000);		
			}	
		}
			
	}

	return {
		'init': initCookie,
		'showCookieConsent': showCookieConsent,
		'isValidChoice': isValidChoice,
		'hasAcceptedCookies': hasAcceptedCookies,
		'cookie': cookie,
		'addNotWorkingMessage': addNotWorkingMessage
	};
})();
function DashboardFlashLoader () {
    this.md5 = md5(Math.floor(new Date().getTime() / 1000) + "");
    $('#fiscalDashboard').flash(
        { 
            src: '/stats/prices/gov/html/GFSDashboard.swf?' + this.md5,
            width:'100%',
            height:'622px',
            allowfullscreen:true,
            wmode:'transparent'
        }
    );
}
ECB.slow.dashboardFlash = function () {
    $(document).ready (function() {
        var dashboardFlashLoader = window.dashboardFlashLoader || {};
        if (Object.keys(dashboardFlashLoader).length == 0) {
      	    window.dashboardFlashLoader = new DashboardFlashLoader();
        }
    });
}
ECB.slow.efxrateSortableTable = function () {
  $(".forextable").tablesorter( {usNumberFormat : true, headers: { 2: { sorter: false } ,1:{sorter:false} } });
}
ECB.slow.eligibleAssets = function () {
	var currentTime = new Date();
	var archiveSelector = function(){
		function efx_easter_date(year)
		{
			var a = year%19;
			var b = year%4;
			var c = year%7;
			var d = (19*a+24)%30;
			var e = ((2*b)+(4*c)+(6*d)+5)%7;
			var day = 22+d+e;
			month = 2;
			if(day>31){
				day = d+e-9;
				month = 3;
			}
			if((day==26)&&(month==3))
			{
				day=19;
			}
			if(day==25&&month==3&&d==28&&e==6&&a>10)
			{
				day=18;
			}
			return new Date(year,month,day);
		}

		function mondayEaster(year)
		{
			return nextDay(efx_easter_date(year));
		}

		function fridayEaster(year)
		{
			return addDays(efx_easter_date(year),-2);
		}

		function ascensionDay(year)
		{
			return addDays(efx_easter_date(year),39);
		}

		function whiteMonday(year)
		{
			return addDays(efx_easter_date(year),50);
		}

		function corpusChristi(year)
		{
			return addDays(efx_easter_date(year),60);
		}

		function isChristmasOrNewYear(date)
		{
			year = date.getFullYear();
			newYear = new Date(year,0,1);
			christmas = new Date(year,11,25);
			secondChristmas = new Date(year,11,26);

			if( sameDate(date,newYear)|| 
				sameDate(date,christmas)||
				sameDate(date,secondChristmas)){
				return true;
			}

			return false;

		}


		function isHoliday(date)
		{
			year = date.getFullYear();

			newYear = new Date(year,0,1);
			labourDay = new Date(year,4,1);
			christmas = new Date(year,11,25);
			secondChristmas = new Date(year,11,26);

			if( sameDate(date,mondayEaster(year))||
				sameDate(date,fridayEaster(year))||
				sameDate(date,newYear)||
				sameDate(date,labourDay)||
				sameDate(date,christmas)||
				sameDate(date,secondChristmas)){
				return true;
			}

			return false;
		}

		function isWeekend(date)
		{
			var day = date.getDay();
			return day==6||day==0;
		}

		function getPreviousWorkingDay(date)
		{
			var r = addDays(date,-1);

			while(isHoliday(r)||isWeekend(r))
			{
				r=addDays(r,-1);
			}
			return r;

		}

		function sameDate(d1, d2)
		{
			var t1 = new Date(d1.getTime());
			var t2 = new Date(d2.getTime());
			if(t1.getHours()>0)
			{
				t1.setHours(0,0,0,0);
			}
			if(t2.getHours()>0)
			{
				t2.setHours(0,0,0,0);
			}

			return t1.getTime()==t2.getTime();
		}

		// Written by Sergey Krivstov - http://stackoverflow.com/questions/20867562/create-a-date-object-with-cet-timezone
		function getCETorCESTDate() {
		    var localDate = new Date();
		    var utcOffset = localDate.getTimezoneOffset();
		    var cetOffset = utcOffset + 60;
		    var cestOffset = utcOffset + 120;
		    var cetOffsetInMilliseconds = cetOffset * 60 * 1000;
		    var cestOffsetInMilliseconds = cestOffset * 60 * 1000;

		    var cestDateStart = new Date();
		    var cestDateFinish = new Date();
		    var localDateTime = localDate.getTime();
		    var cestDateStartTime;
		    var cestDateFinishTime;
		    var result;

		    cestDateStart.setTime(Date.parse('29 March ' + localDate.getFullYear() + ' 02:00:00 GMT+0100'));
		    cestDateFinish.setTime(Date.parse('25 October ' + localDate.getFullYear() + ' 03:00:00 GMT+0200'));

		    cestDateStartTime = cestDateStart.getTime();
		    cestDateFinishTime = cestDateFinish.getTime();

		    if(localDateTime >= cestDateStartTime && localDateTime <= cestDateFinishTime) {
		        result = new Date(localDateTime + cestOffsetInMilliseconds);
		    } else {
		        result = new Date(localDateTime + cetOffsetInMilliseconds);
		    }

		    return result;
		}

		function addDays(date,add)
		{
			var r = new Date(date);
			r.setDate(date.getDate()+add);
			return r;
		}

		function nextDay(current)
		{
			return addDays(current,1);
		}

		var calendarType=$('#download_calendar').data("type");
		var startDate=new Date($('#download_calendar').data("start-date"));
				var maxDate = new Date(currentTime);

				var checkDate = startDate;
				checkDate.setHours(0,0,0,0);			

				var disabledDates = [];
				var currentCalendarValue=null;
				var selectedCalendarValues = [];
				var selectionOrder = [];

				//check time!
				var lastDate = null;
				var t = null;
				maxDate.setHours(0,0,0,0);
				dates = [];
				var i=0;
				while(checkDate<=maxDate)
				{
					if( isChristmasOrNewYear(checkDate))
					{
						disabledDates.push(checkDate);
					}else
					{  
						if(calendarType=="exchange_rates" || calendarType=="eligible_assets") {
						
							if( isWeekend (checkDate) ||  isHoliday (checkDate)  )
							{
								disabledDates.push(checkDate);
							}
						}

						if(calendarType=="cspp" ) 
						{
							if(checkDate.getDay()!=5 )
							{
								disabledDates.push(checkDate);
							}
						}
						if(!sameDate(checkDate,currentTime))
						{
							dates.push(checkDate);
							if(dates.length>40)
							{
								dates.shift();
							}
							lastDate = checkDate;
						}else
						{
							if(currentTime.getHours()>=16)
							{
								dates.push(checkDate);
								lastDate = checkDate;
							}else
							{
								disabledDates.push(checkDate);
							}

						}
					}
					checkDate = nextDay(checkDate);
				}

				var os = function(a){
					lastDateSelected = a;
					var t = $('#download_calendar').multiDatesPicker('getDates');
					if(t.length>0){
						$('#download_calendarButton').addClass('active');
					}else{
						$('#download_calendarButton').removeClass('active');
					}
					
				}

				currentCalendarValue = lastDate;
				selectedCalendarValues.push(currentCalendarValue);

				selectionOrder.push(currentCalendarValue.getTime());

				//remove current date
				dates.pop();


				var today = new Date();
				
				
				$('#download_calendar').multiDatesPicker({
        			inline: false,
        			maxPicks: 1,
        			firstDay: 1,
        			showOtherMonths: true,
        			dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        			dateFormat: 'yy-mm-dd',
        			altField: "#selectedDate",
      				addDisabledDates: disabledDates,
      				maxDate: '0',
      				changeMonth: true,
      				changeYear: true,
      				showAnim: '',
      				zIndex:21,

      				minDate: startDate,
      				onSelect: os
	    			});

    				$('#download_calendarButton').on('click',function(e){e.stopPropagation();$('#download_calendar').focus().click();});


}

var lastDateSelected = "";
function download(){
	var a=lastDateSelected;
	var selectedDate=new Date(a);	
	if(a!==null){	
			
			var parts = a.split('-');
					var y = parts[0];
					var m = parts[1];
					var d = parts[2];
			var do_download = function(){
				$( "#download_calendar" ).multiDatesPicker( "resetDates" );
				$('#download_calendarButton').removeClass('active');

				var calendarType=$('#download_calendar').data("type");
				if(calendarType=="eligible_assets"){
					document.location.href = '/paym/coll/assets/shared/data/EMA/'+y+'/'+m+'/ea_csv_'+y.substr(2)+m+d+'.csv.gz';
				}
				if (calendarType=="cspp"){
					if (selectedDate >= new Date ("2020-04-03")){
						document.location.href = '/mopo/pdf/CSPP_PEPP_corporate_bond_holdings_'+y+m+d+'.csv';
					}
					else{
						document.location.href = '/mopo/pdf/CSPPholdings_'+y+m+d+'.csv';
					}
				}
				if (calendarType=="exchange_rates"){
					document.location.href = '/stats/exchange/eurofxref/shared/pdf/'+y+'/'+m+'/'+y+m+d+'.pdf';
				}

				
            					
					};
					
					if(typeof(ga)!=='undefined')
					{
					ga('send',{
     					   'hitType': 'event',
					   'eventCategory': 'download',
					   'eventAction': 'eurofxref_pdf',
            				   'eventLabel': a,
					   'page': window.location.pathname,
   					   'hitCallback': do_download
					  });
					}
					do_download();
	}
}


window.onpageshow = function(event) {
    if (event.persisted) {

      $( "#download_calendar" ).multiDatesPicker( "resetDates" );
    }
};

	archiveSelector();
	$('#download_calendarButton').click(download);

}
ECB.slow.feedback = function() {
    var feedbackElement = document.getElementById("feedback");        

    if (!!feedbackElement && ECB.slow.cookies.hasAcceptedCookies()) {        
        feedbackElement.classList.remove("hidden");

        var initialScreen = feedbackElement.querySelector(".initial");
        var secondScreen = feedbackElement.querySelector(".second");
        var finalScreen = feedbackElement.querySelector(".final");

        var yesButton = document.getElementById("feedback-yes");
        var noButton = document.getElementById("feedback-no");

        var secondScreenButtons = secondScreen.querySelectorAll(".button");

        yesButton.addEventListener("click",function(){
            initialScreen.classList.add("hidden");
            finalScreen.classList.remove("hidden");
        });

        noButton.addEventListener("click",function(){
            initialScreen.classList.add("hidden");
            secondScreen.classList.remove("hidden");
        });

        for(var i = 0; i < secondScreenButtons.length; i++){
            secondScreenButtons[i].addEventListener("click",function(){
                secondScreen.classList.add("hidden");
                finalScreen.classList.remove("hidden");
            });
        }

    }
}

ECB.slow.fetchTextWrapper = function (url, successFunction, failureFunction) {
    if (!!window.fetch && !!window.Promise) {
        fetch(url).then(function (response) {
            if(!response.ok){
               throw Error();
            }
            return response.text();
        }).then(function (text) {
            successFunction(text);
        }).catch(function(){
            failureFunction && failureFunction();
        });
    } else {
        var request = new XMLHttpRequest();
        request.onreadystatechange = function(){
            if(failureFunction && request.readyState === XMLHttpRequest.DONE && status != 0 && (status < 200 || status > 399 ) ){
                failureFunction();
            }
        }
        request.addEventListener('load', function (e) {
            successFunction(request.responseText);
        });
        request.open("GET", url);
        request.send();
    }
};
ECB.slow.filter = function (rootElement) {
    // hidden attribute is not playing along with flex, so we have to force hide with !important
    document.head.innerHTML = document.head.innerHTML + '<style type="text/css">.texthighlight{background:yellow;}[hidden]{display:none!important;}</style>';

    var root = rootElement;
    if (!rootElement)
        root = document.querySelector("main"); 

    // supported filters
    // you need a new filter - just add it here: parent on the left, node selectors to show and hide to the right
    var filterMap = {
        "TABLE" : "tbody > tr",
        "OL" : ":scope > li",
        "UL" : ":scope > li",
        "DL": ":scope > dt, :scope > dd",
        ".accordion": ".header, .content-box",
        ".cards": ".box",
        ".researchers-listing": ".researcher-box"
    }
 
    // defines element dependencies
    var filterTogether = {
        "DD" : function(item){
            return [item.previousElementSibling]; 
        },
        "DT": function(item){
            return [item.nextElementSibling]; 
        },
        ".content-box" : function(item){
            return [item.previousElementSibling];
        },
        ".header": function(item){
            return [item.nextElementSibling];
        },
    } 

    // (not) used to throttle the filter while typing occurs
    var debounce = function (callback, ms) {
        var timer = 0;
        return function () {
            var context = this, args = arguments;
            clearTimeout(timer);
            timer = setTimeout(function () {
                callback.apply(context, args);
            }, ms || 0); 
        };
    }

    // finds the most suitable filter base nodes, sets the dom selectors for their corresponding filterable children
    // for example if we have a list in a table, we want to filter the table and not the list.
    var getFilterElements = function(componentElement){
        var filterParams = [{
            filterWrapper: componentElement,
            root: componentElement,
            itemsSelector: ""
        }];

        // if the .-filter element is the actual root
        for(var key in filterMap ){
            if (componentElement.matches(key)) {
                filterParams[0].itemsSelector = filterMap[key];
                return filterParams;
            }
        }

        // the root element(s) are children
        var roots = [].slice.call(componentElement.querySelectorAll(Object.keys(filterMap).join(",")));
        if (roots.length > 0){  
            // get rid of invalid root nodes 
            for (var i = 0; i < roots.length; i++)  {
                var current = roots[i];
                while(current.parentElement != componentElement){ // go up in dom until .-filter element
                    current = current.parentElement;
                    if (roots.indexOf(current) !== -1) // there is a more suitable root
                        roots.splice(i, 1) // remove unsuitable root
                }
            }
            filterParams = [];
            // assign root nodes and item selectors
            for (var i = 0; i < roots.length; i++)  {
                for (key in filterMap ){
                    if (roots[i].matches(key)) {
                        filterParams.push({
                            "filterWrapper" : componentElement,
                            "root" : roots[i], 
                            "itemsSelector": filterMap[key]
                        })
                    }
                } 
            }
        } 

        return filterParams;
    }

    var removeHighlight = function (node) {
        var spans = node.querySelectorAll("span.texthighlight")
        for (var i = 0; i < spans.length; i++) {
            var parent = spans[i].parentNode;
            parent.replaceChild(spans[i].firstChild, spans[i]);
            normalize(parent);
        }
    }
    var normalize = function (node) {
		if (!node) { return; }
		if (node.nodeType == 3) {
			while (node.nextSibling && node.nextSibling.nodeType == 3) {
				node.nodeValue += node.nextSibling.nodeValue;
				node.parentNode.removeChild(node.nextSibling);
			}
		} else {
			normalize(node.firstChild);
		}
		normalize(node.nextSibling);
	}
    var innerHighlight = function (node, pat, extraCSSClass) {
        if (!extraCSSClass) {
            extraCSSClass = "";
        }
        var skip = 0;
        if (!pat  || pat.length < 3)
            return;
		if (node.nodeType == 3) {
			var pos = node.data.toUpperCase().indexOf(pat.toUpperCase());
			if (pos >= 0) {  
				if (node.parentNode.className.toLowerCase() !== 'texthighlight') {
					var spannode = document.createElement('span');
                    spannode.classList.add('texthighlight');
                    if (extraCSSClass.length > 0)
                        spannode.classList.add(extraCSSClass);
					var middlebit = node.splitText(pos);
					var endbit = middlebit.splitText(pat.length);
					var middleclone = middlebit.cloneNode(true);
					spannode.appendChild(middleclone);
					middlebit.parentNode.replaceChild(spannode, middlebit);
					skip = 1;
				}
			}
		}
		else if (node.nodeType == 1 && node.childNodes && !/(script|style)/i.test(node.tagName)) {
			for (var i = 0; i < node.childNodes.length; ++i) {
				if (node.tagName !== 'svg' && node.className !== 'ecb-toggle ecb-footnote') {
					i += innerHighlight(node.childNodes[i], pat);
				}
			}
		}
		return skip;
	}

    // the actual hiding and showing of elements. 
    // we can have multiple filters (dropdowns, checkboxes, etc.) that each set a data- parameter
    // here we unify them and hide or show the elements
    var applyFilters = function(items, query){


        // var filtersNodeVisible = document.createEvent('Event');
        // filtersNodeVisible.initEvent('filtersNodeVisible', false, true);
        for (var i = 0; i < items.length; i++){
            removeHighlight(items[i]); 
            if (items[i] && (items[i].hasAttribute("data-filter-text-hidden")  || items[i].getAttribute("data-filter-group-hidden") ) ) {
                items[i].hidden = true;               
            } else {
                if (query){
                    if (items[i].getAttribute("data-filter-match") == "exact")
                        innerHighlight(items[i], query)
                    if (items[i].getAttribute("data-filter-match") == "partial" && items[i].getAttribute("data-filter-partials").length > 0){
                        var partials = JSON.parse(items[i].getAttribute("data-filter-partials"));
                        console.log("partials", partials)
                        for(var j = 0; j < partials.length; j++){
                            innerHighlight(items[i], partials[j], "partial")
                        }
                    }
                        
                }
                items[i].hidden = false;
                // if (query && query.length >= 3)
                //     items[i].dispatchEvent(filtersNodeVisible); 
            }
        }

        var filtersAppliedEvent = document.createEvent('Event');
        filtersAppliedEvent.initEvent('filtersApplied', true, true);
        document.dispatchEvent(filtersAppliedEvent); 
        
        if (items && items.length > 0)  {
            var parent = closestParent(items[0], "-filter");
            var input = parent.querySelector(".filter input");
            input.parentElement.classList.remove("-loading")
        }
    }

    
    var processDependantNodes = function(item){
        for(var j in filterTogether ) { // if there is a node dependency, do the same with the dependent node (eg.: dd, dt)
            if (item.matches(j)) {
                var nodesToFilter = filterTogether[j](item);
                for (var k = 0; k < nodesToFilter.length; k++){
                    if (nodesToFilter[k]){
                        nodesToFilter[k].removeAttribute("data-filter-text-hidden"); 
                        nodesToFilter[k].setAttribute("data-filter-done", true); // mark for skip
                    }
                }
            } 
        } 
    }

    // filter as you type input field handler
    var processTextFilter = function(filterParams, input){
        filterParams.root.setAttribute("in-progress", true)
        input.parentElement.classList.add("-loading");

        var query = input.value;
        var items = filterParams.root.querySelectorAll(filterParams.itemsSelector);
        var exactRegExp = new RegExp(query.trim(), "i"); 
        var searchTerms = query.trim().split(" ");
        var partialsRegExp = {};
        for( var i = 0; i < searchTerms.length; i++){
            partialsRegExp[searchTerms[i]] = (new RegExp(searchTerms[i].trim(), "i")); 
        }
        
        
        // reset attributes
        for (var i = 0; i < items.length; i++) { 
            items[i].removeAttribute("data-filter-done");
            items[i].removeAttribute("data-filter-text-hidden"); 
        }

        for (var i = 0; i < items.length; i++) { 

            // if we need to interrupt, do that
            if (filterParams.root.hasAttribute("interrupt")){
                console.log("interrupting ", query) 
                filterParams.root.removeAttribute("interrupt")
                filterParams.root.removeAttribute("in-progress")
                return;
            }
            var item = items[i];

            // if marked, skip this element
            if (item.hasAttribute("data-filter-done") || item.hasAttribute("noFilter"))
                continue;
            
            items[i].setAttribute("data-filter-text-hidden",true); // hide by default
            items[i].removeAttribute("data-filter-match"); // reset partial/exact match flag
            items[i].removeAttribute("data-filter-partials"); // remove partial matches
            if (item && item.textContent){
                // if exact match
                if ( item.textContent.match(exactRegExp)) { // much faster than .toLower().indexOf()
                    item.removeAttribute("data-filter-text-hidden"); 
                    item.setAttribute("data-filter-match", "exact")
                    processDependantNodes(item);
                } else {
                    // if partial match
                    var partials = [];
                    for (j in partialsRegExp){
                        if (item.textContent.match(partialsRegExp[j])){
                            partials.push(j);
                        }
                    }
                    if (partials.length > 0){
                        item.removeAttribute("data-filter-text-hidden"); 
                        item.setAttribute("data-filter-match", "partial")
                        item.setAttribute("data-filter-partials", JSON.stringify(partials));
                        processDependantNodes(item);
                    }
                }
            }
        } 

        filterParams.root.removeAttribute("in-progress")
        applyFilters(items, query);
        postprocessContainerVisibility(rootElements);
        input.parentElement.classList.remove("-loading")
    }
    // returns the closest parent of node, that has the class parentClass
    var closestParent = function(node, parentClass){
        var parent = node;
        while (parent.parentElement) {  // closest() is not supported in IE11
            parent = parent.parentElement;
            if (parent.classList.contains(parentClass))
                break;
        }
        return parent;
    }

    // show everything
    var resetTextFilter = function(filterParams){
        var items = filterParams.root.querySelectorAll(filterParams.itemsSelector);
        for (var i = 0; i < items.length; i++) { 
            items[i].removeAttribute("data-filter-done");
            items[i].removeAttribute("data-filter-text-hidden"); 
        }
        applyFilters(items)
    }

    // here we find to which .-filter parent the async snippet belongs and use its input value to filter the snippet contents
    var filterAsyncContent = function(node){
        if (!node.querySelector(".-filter")){ // do not search if there is a new filter to be initialized
            var parent = closestParent(node, "-filter");
            if (parent.classList.contains("-filter")){ 
                var input = parent.querySelector("input");
                if (input.value.length >= 3){
                    for (var j = 0; j < rootElements.length; j++) { 
                        if (rootElements[j].filterWrapper.getAttribute("data-filter-id") === parent.getAttribute("data-filter-id")) {
                            if (rootElements[j].root.getAttribute("in-progress"))
                                rootElements[j].root.setAttribute("interrupt", true)
                            var clone = {
                                filterWrapper: rootElements[j].filterWrapper,   
                                root: node, // filter only the async snippet
                                itemsSelector: rootElements[j].itemsSelector
                            }
                            processTextFilter(clone, input)
                            /*setTimeout(function(){
                                
                            }, 400);  */
                        }
                    }
                }
            }
        }
    }

    // returns the value of a querystring variable 
    var gupCopyFromQuicksearch = function (name) {
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regexS = "[\\?&]" + name + "=([^&#]*)";
        var regex = new RegExp(regexS);

        var results = regex.exec(window.location.href);
        if (results == null)
            return "";
        else
            return results[1];
    }

    var elements;
    if (root.classList.contains("-filter"))
        elements = [root];
    else 
        elements = root.querySelectorAll(".-filter");
    

    var rootElements = [];

    var postprocessContainerVisibility = function(rootElements){
        console.log(rootElements)
        // now postprocess and hide containers if all elements are hidden
        for(var j = 0; j < rootElements.length; j++){
            var containers = rootElements[j].root.querySelectorAll(".container, .container .wrapper");
            for (k = 0; k < containers.length; k++){
                if (!containers[k].querySelector(rootElements[j].itemsSelector.trim()+":not(option):not([hidden])")){
                    containers[k].setAttribute("hidden", "true")
                }   else {
                    containers[k].removeAttribute("hidden")
                }
            }
        }
    }

    var processFilterInput = debounce(function(input,rootElements){
        if (input.value.length >= 3 || input.value.length == 0 ) { 
            for (var j = 0; j < rootElements.length; j++) { 
                if (rootElements[j].filterWrapper.getAttribute("data-filter-id") === input.getAttribute("data-filter-id")) {
                    // if there is a filtering happening, interrupt it and start the new filter
                    if (rootElements[j].root.getAttribute("in-progress"))
                        rootElements[j].root.setAttribute("interrupt", true)
                    setTimeout(processTextFilter(rootElements[j], input), 400);  // wait a bit to give the current filter iteration to interrupt
                    var filterDirty = document.createEvent('Event');
                    filterDirty.initEvent('filterDirty', true, true); 
                    closestParent(input, ".-filter").dispatchEvent(filterDirty);
                }
            }
        }  else {
            for (var j = 0; j < rootElements.length; j++) { 
                resetTextFilter(rootElements[j]);
                var filterClean = document.createEvent('Event');
                filterClean.initEvent('filterClean', true, true);
                closestParent(input, ".-filter").dispatchEvent(filterClean);
        
            }                
        }
    }, 500)

    // Select dropdown mutually exclusive group filtering
    var processFilterGroup = function(input, rootElements){
        var groupVal;
        //if (input.tagName.toUpperCase == "SELECT")
        groupVal = input.options[input.selectedIndex].getAttribute("data-filter-group-term").trim();
        if (groupVal.length > 0){ 
            for(var j = 0; j < rootElements.length; j++){
                var allGroupElements = rootElements[j].root.querySelectorAll("[data-filter-group-term]:not(option)");
                allGroupElements.forEach(function(el){
                    if (el){
                        el.setAttribute("data-filter-group-hidden", true);
                        if (el.getAttribute("data-filter-group-term").indexOf(groupVal) > -1) {
                            el.removeAttribute("data-filter-group-hidden");
                        }
                    }
                });
                applyFilters(allGroupElements)
            }
            var filterDirty = document.createEvent('Event');
            filterDirty.initEvent('filterDirty', true, true); 
            closestParent(input, ".-filter").dispatchEvent(filterDirty);
        } else {
            for(var j = 0; j < rootElements.length; j++){
                var allGroupElements = rootElements[j].root.querySelectorAll("[data-filter-group-term]");
                allGroupElements.forEach(function(el){
                    if (el){
                        el.removeAttribute("data-filter-group-hidden");
                    }
                }); 
                applyFilters(allGroupElements)
            }
        }
        postprocessContainerVisibility(rootElements);
    }

    // each .-filter element has it's own input search field. 
    // It may also contain more than type of filterable content (dl, ul, .accordion, etc.) 
    // these are stored in rootElements[]
    // the input field should handle all of those types. 
    if (elements.length > 0 ){
        for (var i = 0; i < elements.length; i++) {
            var element = elements[i];
            var id = "filter-"+Date.now()+"_"+i;

            if (!element.hasAttribute("data-filter-id"))
                element.setAttribute("data-filter-id", id)
            
            // if filter text-field already exists, use it... otherwise add it
            var input = element.querySelector(".filter input[type=text]");
            if (!input) {
                var filter = '<div class="filter"><div class="wrapper"><div class="search-input"><input type="text" placeholder="Enter keyword and filter the list below"></div></div></div>';
                element.insertAdjacentHTML('afterbegin', filter); 
            }
            input = element.querySelector(".filter input[type=text]");
            if (!input.hasAttribute("data-filter-id"))
                input.setAttribute("data-filter-id", element.getAttribute("data-filter-id"));

            rootElements = rootElements.concat(getFilterElements(element)); 
            input.addEventListener("input", function(e){
                this.parentElement.classList.add("-loading");
                var self = this;
                processFilterInput(self,rootElements)
            })

            var groupFilterTrigger = element.querySelector("[data-filter-group]");
            if (groupFilterTrigger){
                groupFilterTrigger.setAttribute("data-filter-group-id", id);
                groupFilterTrigger.addEventListener("change", function(e){
                    var self = this;
                    processFilterGroup(self, rootElements);
                })
            }
        }

        skey = gupCopyFromQuicksearch('skey');
		if (skey.indexOf('+') > 0) skey = skey.replace("+", " ");
		skey = skey.replace(/%20/g, ' '); 
		if (skey.length > 0) { 
            var inp = document.querySelector(".filter input")
            inp.value = skey;
            var e = document.createEvent('HTMLEvents');
            e.initEvent("input", false, true);
            inp.dispatchEvent(e);
		}
    }

    // event triggered yby the lazyload plugin
    document.addEventListener("asyncNodeLoaded", function(e){ 
        filterAsyncContent(e.target)
    })
}
var ECB = window.ECB || {};

ECB.slow.footnotes = function () {

    function wrap(el, wrapper) {
        el.parentNode.insertBefore(wrapper, el);
        wrapper.appendChild(el);
    }

    function toggle(el) {
        if (el.style.display === "none") {
            el.style.display = "block";
        } else {
            el.style.display = "none";
        }
    }

    function insertAfter(referenceNode, newNode) {
        referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
    }

    //do not if is publications - publications has a slightly diferent markup for the footnotes
    if (document.querySelectorAll('.section .footnotes, main .footnotes').length > 0) {
        // old style footnotes
        var manualCounter = 1;
        ECB.slow.forEach(document.querySelectorAll('.footnotes li'), function (footnotes) {
            var oldStyle = footnotes.querySelector('sup a');
            if (oldStyle && oldStyle.length > 0) {
                var footnoteidstring = oldStyle && oldStyle.getAttribute('id');
                var footnotetext = oldStyle.parentNode.parentNode.innerHTML;
                var footnoteidarray = footnoteidstring.split('.');
                var footnoteid = 'fn' + footnoteidarray[1];
            } else {
                var footnoteidstring = footnotes.getAttribute('data-footnote-id');

                //recreate by counting
                if(!footnoteidstring){
                    footnoteidstring = "fn"+manualCounter;
                    manualCounter++;
                }

                var footnotetext = footnotes.innerHTML;
                var footnoteid = footnoteidstring;
 
            }

            if (footnoteidstring) {
                var currentFootnote = document.querySelector('a#' + footnoteid);
                if (currentFootnote) {
                    currentFootnote.classList.add('ecb-footnote-number');
                    
                    var wrapper = document.createElement('span');
                    wrapper.classList.add('ecb-footnote-toggle');                    
                    wrap(currentFootnote.parentNode, wrapper);                    

                    var elem = document.createElement('div');                    
                    elem.classList.add('ecb-footnoteinlinetext');
                    elem.innerHTML = footnotetext;
                    elem.style.display = "none";
                    var sup = elem.querySelector('sup');
                    if(sup){
                        elem.removeChild(sup);
                    }
                    

                    wrapper.appendChild(elem);                    
                }
            }
        });

        //make link clickable
        ECB.slow.forEach(document.querySelectorAll('.ecb-footnote-toggle'), function (footnoteNr) {
            footnoteNr.querySelector("a.ecb-footnote-number").addEventListener('click', function (e) {
                e.preventDefault();
                toggle(footnoteNr.querySelector(".ecb-footnoteinlinetext"));
            });
        })
    }

}

ECB.slow.homepageBadge = function(){
    var localDate = (new Date()).toISOString().substring(0,10);

    ECB.slow.forEach(document.querySelectorAll(".tabs-container.-homepage [name=homepage-tab-group]"),function(tabGroup){
        var label = tabGroup.nextElementSibling;
        var contents = label.nextElementSibling;
        
        var publicationCounter = 0;
        ECB.slow.forEach(contents.querySelectorAll("dt"),function(dateItem){
            if(dateItem.getAttribute("isoDate") == localDate){
                publicationCounter++;
            }
        });

        if(publicationCounter>0){
            var newBadge = document.createElement("span");
            newBadge.classList.add("badge");
            newBadge.innerHTML = publicationCounter;
            label.appendChild(newBadge);
        }
    });
};
// https://stackoverflow.com/questions/19999388/check-if-user-is-using-ie

ECB.slow.iePolyfills = (function() {
    var isIE11 = function(){
        return !!window.document.documentMode
    }

    var init = function (rootElement){
        if (isIE11()) { 
            /* Sidenav on economic bulletin or annual reports has position sticky */
            var menu = document.querySelector('#ecb-sectionNav')
            menu.style.position = 'relative';
            // menu.style.height = 'auto';
            var menuPosition = menu.getBoundingClientRect().top;
            window.addEventListener('scroll', function() {
                if (window.pageYOffset >= menuPosition) {
                    menu.style.position = 'fixed';
                    menu.style.top = '0px'; 
                } else {
                    menu.style.position = 'relative';
                    menu.style.top = '70px';
                }
            });
        }   
    }
 
    return {
        "isIE11": isIE11, 
        "init": init
    }
})()
ECB.slow.imgFilter = function(){
    var filterElements = document.querySelectorAll(".-t-filter");

    if(filterElements){
        document.body.insertAdjacentHTML("beforeend","<svg class=\"defs-only\">\n<filter color-interpolation-filters=\"sRGB\" id=\"t-filter\">\n<feColorMatrix type=\"matrix\" values=\"\n0 0 -1 0 1\n1 0 0 0 0\n0 1 0 0 0\n0 0 0 1 0\" />\n</filter>\n</svg>");
        ECB.slow.forEach(filterElements,function(el){            
            el.classList.add("-filter-ready");
        });


        // // detect inspector: https://stackoverflow.com/questions/7798748/find-out-whether-chrome-console-is-open/48287643#48287643
        // var block;

        // var element = new Image();
        // Object.defineProperty(element, 'id', {
        //     get: function() {
        //         block=true;                            
        //     }
        // });

        // requestAnimationFrame(function check() {
        //     block = false;
            
        //     console.dir(element);
        //     console.clear();
        //     if(block){
        //         ECB.slow.forEach(filterElements,function(el){            
        //             el.remove();
        //         });
        //     }else{
        //         requestAnimationFrame(check);
        //     }
            
        // });
    }
}



ECB.slow.interactiveTable = function() {

	document.head.innerHTML = document.head.innerHTML + '<style type="text/css">'
	+'/* see interactiveTable.js */'
	+'.hasChildren {cursor: pointer;}'
	+'.hasChildren td:first-child:before{'
	+'	content:"";'
	+'	font-family: ECB-icon-set !important;'
	+'	font-style: normal;'
	+'	font-weight: normal !important;'
	+'	vertical-align: middle;'
	+'	width: 20px;'
	+'	height: 20px;'
	+'	position: absolute;'
	+'	transform: translateX(-45px);'
	+'	top: 15px;'
	+'	background-color: transparent;'
	+'	font-size: 20px;'
	+'	line-height: 20px;'
	+'	color: #999; '
	+'} '
	+'.hasChildren.opened td:first-child:before{'
	+'	/*content:"\e90a";*/'  
	+'}  '
	+'#dynamicTable thead th, #dynamicTable thead td {position: sticky; top: 0} '
	+'#dynamicTable tbody th:first-child, #dynamicTable tbody td:first-child {position: sticky; left: 0}'
	+'#dynamicTable tbody tr th[class^=column-] {background: #fbfbfb;}'
	+'#dynamicTable tr td:first-child, #dynamicTable tr th:first-child {position: relative;}'
	+'.level-3 td{background: #eee !important;} '
	+'.level-4 td{background: #e6e6e6 !important;} '
	+'.level-5 td{background: #dedede !important;} '
	+'.level-6 td{background: #d6d6d6 !important;} '
	+'.level-7 td{background: #cecece !important;} ' 
	+'.level-8 td{background: #c6c6c6 !important;} '
	+'</style>'; 
 
	if(!ECB.cookies) {
		ECB.cookies = ECB.slow.cookies;
	}

	//from: https://github.com/jserz/js_piece/blob/master/DOM/ChildNode/after()/after().md
	if (!Element.prototype.after) {
	(function (arr) {
		arr.forEach(function (item) {
		if (item.hasOwnProperty('after')) {
				return;
			}
			Object.defineProperty(item, 'after', {
				configurable: true,
				enumerable: true,
				writable: true,
				value: function after() {
				var argArr = Array.prototype.slice.call(arguments),
					docFrag = document.createDocumentFragment();
		
				argArr.forEach(function (argItem) {
					var isNode = argItem instanceof Node;
					docFrag.appendChild(isNode ? argItem : document.createTextNode(String(argItem)));
				});
		
				this.parentNode.insertBefore(docFrag, this.nextSibling);
				}
			});
			});
		})([Element.prototype, CharacterData.prototype, DocumentType.prototype]);
	}
	/*! https://mths.be/startswith v0.2.0 by @mathias */
	if (!String.prototype.startsWith) {
		(function() {
			'use strict'; // needed to support `apply`/`call` with `undefined`/`null`
			var defineProperty = (function() {
				// IE 8 only supports `Object.defineProperty` on DOM elements
				try {
					var object = {}; 
					var $defineProperty = Object.defineProperty;
					var result = $defineProperty(object, object, object) && $defineProperty;
				} catch(error) {}
				return result;
			}());
			var toString = {}.toString;
			var startsWith = function(search) {
				if (this == null) {
					throw TypeError();
				}
				var string = String(this);
				if (search && toString.call(search) == '[object RegExp]') {
					throw TypeError();
				}
				var stringLength = string.length;
				var searchString = String(search);
				var searchLength = searchString.length;
				var position = arguments.length > 1 ? arguments[1] : undefined;
				// `ToInteger`
				var pos = position ? Number(position) : 0;
				if (pos != pos) { // better `isNaN`
					pos = 0;
				}
				var start = Math.min(Math.max(pos, 0), stringLength);
				// Avoid the `indexOf` call if no match is possible
				if (searchLength + start > stringLength) {
					return false;
				}
				var index = -1;
				while (++index < searchLength) {
					if (string.charCodeAt(start + index) != searchString.charCodeAt(index)) {
						return false;
					}
				}
				return true;
			};
			if (defineProperty) {
				defineProperty(String.prototype, 'startsWith', {
					'value': startsWith,
					'configurable': true,
					'writable': true
				});
			} else {
				String.prototype.startsWith = startsWith;
			}
		}());
	}

	function StickyTableHandler(){

		this.setWidth = function(){
			$('table.sticky-enabled').each(function() {
				var $w	   = $(window),
					$t	   = $(this),
					$thead = $t.find('thead').clone(),
					$col   = $t.find('thead, tbody').clone();
					var $stickyHead  = $(this).siblings('.sticky-thead'),
					$stickyCol   = $(this).siblings('.sticky-col'),
					$stickyInsct = $(this).siblings('.sticky-intersect'),
					$stickyWrap  = $(this).parent('.sticky-wrap');


					$t.find('thead th').each(function (i) {
							$stickyHead.find('th').eq(i).outerWidth($(this).outerWidth());
						})
						.end()
						.find('tr').each(function (i) {
							$stickyCol.find('tr').eq(i).height($(this).outerHeight());
						});

						// Set width of sticky table head
						$stickyHead.outerWidth($t.outerWidth());

						// Set width of sticky table col
						$t.find('tr>th:first-child').each(function (i) {
							$stickyCol.find('tr>th:first-child').eq(i).outerWidth($(this).outerWidth());
						})
						//$stickyCol.find('th').add($stickyInsct.find('th')).outerWidth($t.find('thead th').outerWidth());
						$stickyInsct.find('th').outerHeight($stickyHead.find('th').outerHeight());

			});
		}


		$('table').each(function() {
			if($(this).find('thead').length > 0 && $(this).find('th').length > 0) {
				// Clone <thead>
				var $w	   = $(window),
					$t	   = $(this),
					$thead = $t.find('thead').clone(),
					$col   = $t.find('thead, tbody').clone();

				// Add class, remove margins, reset width and wrap table
				$t
				.addClass('sticky-enabled')
				.css({
					margin: 0,
					width: '100%'
				}).wrap('<div class="sticky-wrap hugeTable interactiveTable" />');

				if($t.hasClass('overflow-y')) $t.removeClass('overflow-y').parent().addClass('overflow-y');

				// Create new sticky table head (basic)
				$t.after('<table class="ecb-contentTable sticky-thead" hidden="true"/>');

				// If <tbody> contains <th>, then we create sticky column and intersect (advanced)
				if($t.find('tbody th').length > 0) {
					$t.after('<table class="ecb-contentTable sticky-col" /><table class="sticky-intersect ecb-contentTable" />');
				}

				// Create shorthand for things
				var $stickyHead  = $(this).siblings('.sticky-thead'),
					$stickyCol   = $(this).siblings('.sticky-col'),
					$stickyInsct = $(this).siblings('.sticky-intersect'),
					$stickyWrap  = $(this).parent('.sticky-wrap');
					
					
					// not compatible with redesign - hide
					$stickyCol.attr("hidden", true)
					$stickyInsct.attr("hidden", true)

				$stickyHead.append($thead);

				$stickyCol
				.append($col)
					.find('thead th:gt(0)').remove()
					.end()
					.find('tbody td').remove();

				$stickyInsct.html('<thead><tr><th>'+$t.find('thead th:first-child').html()+'</th></tr></thead>');

				// Set widths
				var setWidths = function () {
						$t
						.find('thead th').each(function (i) {
							$stickyHead.find('th').eq(i).outerWidth($(this).outerWidth());
						})
						.end()
						.find('tr').each(function (i) {
							$stickyCol.find('tr').eq(i).height($(this).outerHeight());
						});

						// Set width of sticky table head
						$stickyHead.width($t.outerWidth());

						// Set width of sticky table col
						$t.find('tr>th:first-child').each(function (i) {
							$stickyCol.find('tr>th:first-child').eq(i).outerWidth($(this).outerWidth());
						})
						//$stickyCol.find('th').add($stickyInsct.find('th')).outerWidth($t.find('thead th').outerWidth())
					},
					repositionStickyHead = function () {
						// Return value of calculated allowance
						var allowance = calcAllowance();

						// Check if wrapper parent is overflowing along the y-axis
						if($t.height() > $stickyWrap.height()) {
							// If it is overflowing (advanced layout)
							// Position sticky header based on wrapper scrollTop()
							if($stickyWrap.scrollTop() > 0) {
								// When top of wrapping parent is out of view
								$stickyHead.add($stickyInsct).css({
									opacity: 1,
									top: $stickyWrap.scrollTop()
								});
							} else {
								// When top of wrapping parent is in view
								$stickyHead.add($stickyInsct).css({
									opacity: 0,
									top: 0
								});
							}
						} else {
							// If it is not overflowing (basic layout)
							// Position sticky header based on viewport scrollTop
							if($w.scrollTop() > $t.offset().top && $w.scrollTop() < $t.offset().top + $t.outerHeight() - allowance) {
								// When top of viewport is in the table itself
								$stickyHead.add($stickyInsct).css({
									opacity: 1,
									top: $w.scrollTop() - $t.offset().top
								});
							} else {
								// When top of viewport is above or below table
								$stickyHead.add($stickyInsct).css({
									opacity: 0,
									top: 0
								});
							}
						}
					},
					repositionStickyCol = function () {
						if($stickyWrap.scrollLeft() > 0) {
							// When left of wrapping parent is out of view
							$stickyCol.add($stickyInsct).css({
								opacity: 1,
								left: $stickyWrap.scrollLeft()
							});
						} else {
							// When left of wrapping parent is in view
							$stickyCol
							.css({ opacity: 0 })
							.add($stickyInsct).css({ left: 0 });
						}
					},
					calcAllowance = function () {
						var a = 0;
						// Calculate allowance
						$t.find('tbody tr:lt(3)').each(function () {
							a += $(this).height();
						});

						// Set fail safe limit (last three row might be too tall)
						// Set arbitrary limit at 0.25 of viewport height, or you can use an arbitrary pixel value
						if(a > $w.height()*0.25) {
							a = $w.height()*0.25;
						}

						// Add the height of sticky header
						a += $stickyHead.height();
						return a;
					};

				setWidths();

				$t.parent('.sticky-wrap').scroll($.throttle(250, function() {
					repositionStickyHead();
					repositionStickyCol();
				}));

				$w
				.load(setWidths)
				.resize($.debounce(250, function () {
					setWidths();
					repositionStickyHead();
					repositionStickyCol();
				}))
				.scroll($.throttle(250, repositionStickyHead));
			}
		});
	}




	var TableParser = function(data, identifier)
	{

		var parser = this;
		this.tags = ['p','em','th','tr','td','h1','h2','h3','h4','table','thead','tbody','tfoot','ol','ul','li','div'];
		this.o = data['options'];
		this.monthNames=['January','February','March','April','May','June','July','August','September','October','November','December'];
		this.units = {0:'',3: ' thousands', 6: ' millions', 9: ' billions', 12: ' trillions',15: 'quadrillions'};

		//By dave1010 from http://stackoverflow.com/questions/2646385/add-a-thousands-separator-to-a-total-with-javascript-or-jquery
		this.addCommas = function(nStr) {
		    nStr += '';
		    var x = nStr.split('.');
		    var x1 = x[0];
		    var x2 = x.length > 1 ? '.' + x[1] : '';
		    var rgx = /(\d+)(\d{3})/;
		    while (rgx.test(x1)) {
		        x1 = x1.replace(rgx, '$1' + ',' + '$2'); 
		    }
		    return x1 + x2;
		}

		// in order: is_array, is_string, is_undefined_or_null, is_number, format_number, get_child_node, get_length_of_child_node
		this.a = function(o){return Array.isArray(o);}
		this.s = function(o){return typeof(o)==='string';}
		this.u = function(o){return typeof(o)==='undefined'||o===null;}
		this.f = function(o){return parser.u(o)?false:$.isNumeric(o.replace(/,/g,''));}
		this.ff = function(s){if(!parser.f(s)){return s;}  var r = parser.addCommas(s); return r; }
		this.gc = function(s){var d=parser.s(s)?data[s]:data;for(var i=0;!parser.s(s)&&i<s.length;i++){d=d[s[i]];};return d;}
		this.l = function(s){var c = parser.gc(s);return parser.a(c)?c.length:0;}

		this.prettyPrintDate = function(d){da = d.split('-');if(da.length==1){return d;} if(parser.f(da[0])&&parser.f(da[1])){return parser.monthNames[da[1]-1]+' '+da[0];}else{return da[0]+' '+da[1];}}

		// Taken from StackExchange, written by Steve Hansell and iambriansreed (http://stackoverflow.com/questions/1026069/capitalize-the-first-letter-of-string-in-javascript)
		String.prototype.capitalize = function() { return this.charAt(0).toUpperCase() + this.slice(1);}

		// create functions that allow you to add html tags
		this.addFunctions = function()
		{
			var parser = this; var u=this.u;var f = this.f;var ff=this.ff; var a = this.a;
			var n = function(n,s,a,e){e=u(e)?'':e;a=u(a)?f(s)?' class="number"':'':a; return '<'+n+a+'>'+s+e+'</'+n+'>';};
			$.each(this.tags,function(i,e){

				parser[e]=function(s,isColumn,extra){var d=parser.gc(s);var r ='';d=a(d)?d:[d];for(var i=0;a(d)&&i<d.length;i++){if(u(isColumn)||(isColumn&&$.inArray(i, parser.o.defaultColumns)!==-1)){r+=parser['o_'+e](d[i],undefined,extra);}} return r;};
				parser['o_'+e]=function(s,a,extra){s=f(s)?ff(s):parser.s(s)?s.capitalize():s;return n(e,s,a,extra);};
				parser[e+'_em']=function(s,isColumn,extra){var d=parser.gc(s);var r ='';d=a(d)?d:[d];for(var i=0;a(d)&&i<d.length;i++){if(u(isColumn)||(isColumn&&$.inArray(i, parser.o.defaultColumns)!==-1)){if($.inArray(i,data.externalCountryColumns)!==-1){r+=parser['o_'+e](parser.o_em(d[i]),undefined,extra);}else{r+=parser['o_'+e](d[i],undefined,extra);}}} return r;};

			});
		}

		this.addCrossNavElements = function(){
			if(!data.calendarurl||data.calendarurl.length==0)
			{
				$('#calendarUrl').closest('.ecb-crossNavBlock').remove();
			}else{
				$('#calendarUrl').attr('href',data.calendarurl);
			}
			var ul =$('#relatedStatisticsBox ul');

			if(!data.relatedStatistics||data.relatedStatistics.length==0)
			{
				$('#relatedStatisticsBox').remove();
			}else{
				$.each(data.relatedStatistics,function(k,v){
					var strippedTitle = v.replace(/\([a-zA-Z0-9-_;.=,\s]+\)$/,'');
					ul.append('<li><a class="arrow" href="table.en.html?id='+k+'">'+strippedTitle+'</a></li>');
				});
			}
		}

		this.addExtraElements = function(){

			this.addCrossNavElements();


			//add downloads
			const downloadsHTML = '<div class="list -top-arrow"><div class="header"><div class="title">Download area</div></div><ul class="zebraList headerDownloads" id="downloads">'+
				'<li><a class="xml" href="//sdw-wsrest.ecb.europa.eu/service/data/'+identifier+'" data-type="application/vnd.sdmx.structurespecificdata+xml;version=2.1" download="'+identifier+'.xml">SDMX-ML</a></li>'+
				'<li><a class="csv" href="//sdw-wsrest.ecb.europa.eu/service/data/'+identifier+'" data-type="application/vnd.ecb.data+csv;version=1.0.0" download="'+identifier+'.csv">CSV</a></li>'+
				'</ul></div>';

			if(data.contactList&&Object.keys(data.contactList).length>0){
				var contactString = '<div class="definition-list -top-arrow"><div class="header"><div class="title">User support</div></div><dl>';
				$.each(data.contactList,function(k,v){
					var name = v.name;
					var email = v.email;
					var isEmail = email.indexOf('@')!=-1;
					var isLink = email.startsWith('http');
					var link = '<a class="'+(isEmail?'mail':'external')+'" href="'+(isEmail?'mailto:':'')+email+'">'+email+'</a>';

					contactString +='<dt>'+name+'</dt><dd>'+link+'</dd>';
				});
				contactString+='</div>'; 
				$('.interactive-table').after('<div>'+downloadsHTML+contactString+'</div>');
			}
		}

		this.handleOpenClose = function(){
			var el = $('.rowOpener.'+this.classList[0]);

			

			var row = el.closest('tr');
			var rowId = row[0].classList[0];
			
			var allChildren = $('tr[class*=parent-'+rowId+']');
			var children = $('tr.parent-'+rowId);
			if (row.hasClass("opened")) {
				row.removeClass('opened');
				allChildren.addClass("hidden").removeClass("opened")
			} else {
				row.addClass('opened')
				children.removeClass("hidden");
			}

		}



		// build up page
		this.parseData = function()
		{
			if(!include_id){
				this.addExtraElements();
			}

			// Initialize variables
			var t = this;
			var str = ''; var temp = '';var h=['table','[header]','columns']; var b = t.gc('table');
			data.activeColumns = this.o.defaultColumns;
			this.readCookie();
			var cc = this.o.defaultColumns.length+1;

			//Add title and description
			var rawTitle = t.gc('title');
			var unit = rawTitle.match(/\([a-zA-Z0-9-_;.=,\s]+?\)$/);
			var strippedTitle = rawTitle.replace(/\([a-zA-Z0-9-_;.=,\s]+\)$/,'');

			if(include_id){
				str+=t.o_h2(strippedTitle+': '+this.prettyPrintDate(this.o.timePoint));
			}else{
				/* str+=t.o_h1(strippedTitle+': '+this.prettyPrintDate(this.o.timePoint)); */
				$('#ecb-social-sharing').after('<header>'+t.o_h1(strippedTitle+': '+this.prettyPrintDate(this.o.timePoint))+'</header>');
			}



			var subTitle = undefined;

			if(unit&&unit.length>0)
			{
				subTitle = unit[0];

			}else{
				if(t.u(t.o.unit))
				{
					t.o.unit = t.o.unit_measure;
				}


				if(!t.u(t.o.unit_index_base))
				{
					subTitle = t.o.unit_index_base;
				}else if((t.u(t.o.unitMultiplier)||t.o.unitMultiplier==0)&&!t.u(t.o.unit))
				{
					subTitle = t.o.unit;
				} else if(t.o.unit==='Pure number'||t.o.unit=='Unit described in title')
				{
					subTitle = (t.u(t.o.unitMultiplier)?'':t.units[t.o.unitMultiplier]+' - '+t.o.unit);
				}else{
					subTitle = t.units[t.o.unitMultiplier]+' of '+t.o.unit;
				}

			}

			str+=(t.u(subTitle)?'': '<div class="header"><div class="title">'+subTitle.trim()+'</div></div>' ); 



			var selectors = '';
			this.headers = t.gc(h);
			var headers = this.headers;

			var downloads = '';
			var downloadBreak = '';

			var selectionBox = '';
			if('download' in data)
			{
				$.each(data['download'],function(k,v)
				{
					downloads+=downloadBreak+'<a href="'+v+'" class="'+k+'">Download data ('+k+')</a>';
					downloadBreak = '<br>';
				});
			}
			/////////////////////////
			if(downloads.length>0)
			{
				selectionBox += this.o_div(downloads,' class="floatRight"');
			}

			if(headers.length>t.o.defaultColumns.length)
			{
				var extra = headers.length-1==data.activeColumns.length?' checked':'';
				selectionBox+=t.o_div('<ul><li><input class="columnSelectorCheckbox" id="checkAll" type="checkbox"'+extra+' value="-1"><label for="checkAll" class="columnSelector noselect" style="padding-right:13px;">Select all</label></li></ul>', ' class="box -small"');
			}


			$.each(t.gc(h),function(i,e){

				if($.inArray(i,t.o.defaultColumns)==-1)
				{
					var extra = $.inArray(i,data.activeColumns)==-1?'':' checked';
					selectors+=t.o_li('<input class="columnSelectorCheckbox" id="column-selector-'+e.replace(' ','_')+'" type="checkbox"'+extra+' value="'+i+'"><label class="columnSelector noselect" style="padding-right:13px;" for="column-selector-'+e.replace(' ','_')+'">'+e+'</label>');
				}
			});
			var tableControlsUL=t.o_ul(selectors);

			selectionBox+=t.o_div(tableControlsUL, ' class="box -large"')
			var tebleControlsContainer = t.o_div(selectionBox,' class="container"');
			str+=t.o_div(tebleControlsContainer,' class="table-controls tableColumnSelectors"');

			var thead=t.o_thead(t.o_tr(t.o_th('&nbsp')+t.th(h,true)));
			$.each(b['rows'],function(i,e){
					var d = e.columns.length;
					var k = ['table','rows',i,'columns'];
					var n = e.depth.split('.').length;
					var filling = '';

					var parentClass = '';

					if(n>1)
					{
						parentClass = 'parent-'+e.depth.substr(0,e.depth.lastIndexOf('.')).replace(/\./g,'_');
					}
					//if(n>2){
						parentClass += ' tablerow level-'+n; //add level class
					//}
					var nextItem = b['rows'][i+1];

					fillerClass='';
					if(d==0)
					{
						for(var i=0;i<cc-1;i++)
						{
							filling+=t.o_td('',' class="filler"');
						}
					}
					var openButtonHolder = '';
					var isOpener = false;
					var isHidden = '';
					if(n>2){
						isHidden = ' hidden';
					}
					if(n>1&&nextItem&&nextItem.depth.startsWith(e.depth))
					{
						openButtonHolder = '<span class="'+e.depth.replace(/\./g,'_')+' rowOpener fa fa-angle-right"></span>';
						isOpener = true;
						parentClass += ' isParent';
					}

					isOpenerClass = '';
					if(isOpener){
						isOpenerClass = ' hasChildren';
					}

					temp+=t.o_tr(
						t.o_td(
							openButtonHolder+' '+e.depth+'. '+e.name.capitalize(),
							' style="padding-left:'+(20+((n-1)*25))+'px;text-indent: 20px"'
						)+
						filling+
						t.td_em(k,true),
						' class="'+e.depth.replace(/\./g,'_')+' '+parentClass+isHidden+isOpenerClass+'"'
					);
			});

			var tbody = t.o_tbody(temp);

			var temp2 = '';

			if('footer' in data)
			{
				$.each(Object.keys(data['footer']),function(i,e){
					temp2+=t.o_div(t.o_h4(e.capitalize())+t.o_ol(t.li(['footer',e])));
				});
			}


			var tableMarkup = t.o_table(thead+tbody,' id="dynamicTable"');
			str+=t.o_div(tableMarkup, ' class="wrapper"')

			if(!include_id){
				str +=  t.o_div(t.o_div('<h4>Legend</h4><div class="definition-list"><dl><dt>-</dt><dd>related data do not exist or are subject to statistical confidentiality</dd><dt>·</dt><dd>data are not yet available</dd><dt><em>Italics</em></dt><dd> country data are shown in grey and italics for periods prior to a countries entry into the euro area</dd></dl></div>',' class="legend-box"')
								+ t.o_div('<br /><p>'+data['description'].replace(/\n/g,'</p><p>')+'</p>',' id="description"'), 
								' class="footnotes"'
					);
			}


			str+=temp2;


			if(include_id){
				$('#jdf_table_include').html(str);
			}else{
				$('.interactive-table').prepend(str);
				$('<div class="section"><a id="linkToIndex" href="#">All previous periods</a></div>').insertBefore('.interactive-table');
				$("#linkToIndex").on('click', function(e){
					e.preventDefault();
					var indexUrl = window.location.href;
					var lastIndexOfPeriod = indexUrl.lastIndexOf("period=");
					window.location = lastIndexOfPeriod == -1 ? indexUrl + "&period=index" : indexUrl.replace(indexUrl.substr(lastIndexOfPeriod), "period=index"); 
			   });
			}




			var table = $('table#dynamicTable').first();

			$('.columnSelectorCheckbox').change(function(){var i = $(this);if(i[0].checked){parser.addColumnWrapper(parseInt(i.val()));}else{parser.removeColumnWrapper(parseInt(i.val()));}
			ECB.slow.tableResize()
		});



			this.stickyHandler = new StickyTableHandler();

			$('.hasChildren').click(this.handleOpenClose);

		}

		this.removeFromActiveColumns = function(id)
		{
			var i = $.inArray(parseInt(id), data.activeColumns);
			if(i!=-1)
			{
				data.activeColumns.splice( i, 1 );
			}
		}

		this.updateCookie = function()
		{
			data.activeColumns = this.unique(data.activeColumns);
			ECB.cookies.cookie('table_'+identifier,null);
			if(data.activeColumns.length==0)
			{
				ECB.cookies.cookie('table_'+identifier,null);
			}else
			{
				//$.cookie('table_'+identifier,data.activeColumns);
			}
		}

		// From http://www.paulirish.com/2010/duck-punching-with-jquery/
		this.unique = function(arr)
		{
			arr = $.grep(arr, function(v, k){
			    return $.inArray(v ,arr) === k;
			});
			return arr;
		}

		this.readCookie = function()
		{
			var cookie = ECB.cookies.cookie('table_'+identifier);
			if(cookie != null)
			{
				var t = cookie.split(',');
				data.activeColumns = t.map(function(i){return parseInt(i);})
			}
		}

		this.addColumnWrapper = function(id)
		{
			var table = $('table#dynamicTable').first();
			var head = this.getStickyTHead();

			if(id==-1)
			{
				this.removeColumnWrapper(-1);

				//enable all columns
				$.each(this.headers,function(i,e)
				{
					if($.inArray(i,parser.o.defaultColumns)==-1)
					{
						parser.addColumn(i,table);
						parser.addColumn(i,head);
						data.activeColumns.push(i);
					}
				});
				$('.tableColumnSelectors input').prop('checked',true);

			}else
			{
				data.activeColumns.push(id);
				this.addColumn(id,table);
				this.addColumn(id,head);

			}

			this.stickyHandler.setWidth();
			this.updateCookie();
		}

		this.removeColumnWrapper = function(id)
		{

			var table = $('table#dynamicTable').first();
			var head = this.getStickyTHead();

			if(id==-1)
			{
				$.each(data.activeColumns,function(i,e)
				{
					parser.removeColumn(e,table);
					parser.removeColumn(e,head);
				});
				$('.tableColumnSelectors input').prop('checked',false);
				data.activeColumns = [];
			}
			else
			{
				this.removeFromActiveColumns(id);
				this.removeColumn(id,table);
				this.removeColumn(id,head);

			}

			this.stickyHandler.setWidth();
			this.updateCookie();
		}

		this.addColumn = function(id, table)
		{

			var columnName = this.gc(['table','[header]','columns'])[id];
			table.find('> thead > tr').append('<th class="column-'+id+'">'+columnName+'</th>');
			var rows = this.gc(['table','rows']);
			var counter = 0;
			$.each(rows, function(i,e){
					var value = '';
					var cell = parser.o_th(value,' class="column-'+id+(parser.f(value)?' number':'')+'"');

					if(e['columns'].length>id)
					{
						value = e['columns'][id];
						if($.inArray(id,data.externalCountryColumns)!==-1){
							cell=parser.o_td(parser.o_em(value),' class="column-'+id+(parser.f(value)?' number':'')+'"')
						}else
						{
							cell=parser.o_td(value,' class="column-'+id+(parser.f(value)?' number':'')+'"')
						}
					}

					table.find('> tbody > tr:eq('+counter+')').append(cell);

					counter++;
			});

			this.stickyHandler.setWidth();


		}

		this.removeColumn = function(id, table)
		{

			//if($.inArray(id,this.o.defaultColumns)==-1)
			{

				//remove header
				table.find('> thead > tr > th.column-'+id).remove();

				//remove body
				table.find('> tbody > tr > .column-'+id).remove();
			}

		}

		this.getStickyTHead = function()
		{
			return $('table#dynamicTable').closest('.sticky-wrap').find('table.sticky-thead');
		}



		this.addNormalPage = function(){
			this.addFunctions();
			this.parseData();
		}

		this.addIndex = function(){
			this.addCrossNavElements();
		}

	}

	var parser=null;


	var loadTable = function(identifier,period, failFunction) {

	  if(period==='index'){
		var monthNames=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
		$.getJSON('/stats/services/escb/shared/data/'+identifier+'/'+identifier+'_periods.json',function(data){
			try{
				var prevPeriod = null;
				var str = '<div class="definition-list"><dl>';
				var t='';
				for(var i = data.index.length;i>0;i--)
				{

					var timePoint = data.index[i-1].toString();
					var parts = timePoint.split('-');
					if(parts.length==1&&prevPeriod!==null){prevPeriod=parts[0]}
					if(parts[0]!==prevPeriod)
					{
						if(prevPeriod!==null)
						{
							str+=t;
							t='';
							str+='</dd>';
						}
						yearTitle = parts[0];
						if(parts.length==1){yearTitle='';}

						str+='<dt>'+yearTitle+'</dt><dd>';
						prevPeriod = parts[0];
					}
					var v = parts[1]+'';
					if(v.substr(0,1)!=='Q')
					{
						v = monthNames[parseInt(v)-1];
					}
					if(parts.length==1){v=parts[0];}
					t='<a href="?id='+identifier+'&period='+timePoint+'">'+v+'</a> '+t;
				}
				str+=t+'</dd></dl></div>';

				var tag = include_id?'h2':'h1';
				var dataTitle = '<header><'+tag+'>'+data.title+'</'+tag+'></header>';
				if(include_id){
					$('#jdf_table_include').html(str);
					$(dataTitle).insertBefore('#jdf_table_include');
				}else{
					$('.interactive-table').html(str);
					$(dataTitle).insertBefore('.interactive-table');
				}

				url = '/stats/services/escb/shared/data/'+identifier+'.json';

				$.getJSON(url,function(data){
					parser = new TableParser(data, identifier);
					parser.addIndex();
				});

			}catch(e){
				failFunction();
				throw(e);
			}

		  }).fail(failFunction);

	  }else
	  {
		if(period==='')
		{
			var url = '/stats/services/escb/shared/data/'+identifier+'.json';
		}else
		{
			url = '/stats/services/escb/shared/data/'+identifier+'/'+identifier+'_'+period+'.json';
		}
		  $.getJSON(url,function(data){
			try{
				parser = new TableParser(data, identifier);
				parser.addNormalPage();
			}catch(e){
				failFunction();
				throw(e);
			}

		  }).fail(failFunction);
	  }
	}



	if(typeof include_id === 'undefined') {
		include_id = false;
	}

	(function() {

		var search = location.search.substr(1).split('#')[0];
		var vars = search.split('&');
		var id = vars[0].split('=')[1];
		var period = vars.length>1?vars[1].split('=')[1]:'';



		if(include_id){
			id = include_id;
		}

		loadTable(id,period,function(msg){
			$('.interactive-table').prepend('<div class="error"><p>Data not found.</p></div>');
		});
		$('.interactive-table').addClass('table');

	})();





};

ECB.slow.languageSelect = function () {
    // var languageSelector = document.getElementById("language-selector");
    // languageSelector.addEventListener("change", function () {
    //     document.location.href = document.location.href.replace(/\.[a-z]{2,}\.([a-z]{1,})$/, "." + languageSelector.value + ".$1");
    // });


    var selectLanguage = document.getElementById("language-selected");
    var languageMenu = document.getElementById('language-values');

    if(document.querySelector("#language-values>a.selected")){
        selectLanguage.querySelector("span").innerText
        = document.querySelector("#language-values>a.selected").lang.toUpperCase();
    }else{
        languageMenu.insertAdjacentHTML( 'beforeend', "<a href=\"#\" class=\"selected\" lang=\""+ECB.currentLanguage+"\" specialLang>"+ECB.isoLocalLanguageName+"</a>" );        
    }

    if (selectLanguage) {
        selectLanguage.addEventListener("click", function () {
            languageMenu.classList.toggle("open");
        });

        document.addEventListener("click",function(e){
            if(e==null||!selectLanguage.contains(e.target) && !languageMenu.contains(e.target)){
                languageMenu.classList.remove("open");
            }
        });
    } 

    var languageValues = languageMenu.querySelectorAll("#language-values>a");
    ECB.slow.forEach(languageValues, function (value) {
        value.addEventListener('click', function () {
            window.localStorage.setItem("lastLanguage",value.lang);
            document.location.href = document.location.href.replace(/\.[a-z]{2,}\.([a-z]{1,}(#.*?)?(\?.*?)?(#.*?)?)$/, "." + value.lang + ".$1");
        })
    });
}
var ECB = window.ECB || {};
ECB.slow.languageVersions = function(rootElement) {

	// Selector names
	var _opener = '.moreLanguages';
	var _closeBtn = '.ecb-closeBtn';
	var popup = ".ecb-langPopup";

	//wrapper to calculate expired days for cookie	
	var setCookie = function (name, value, days) {
		var options = {"path":"/"};
		if (days) {
		  var date = new Date();
		  date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
		  options.expires = date.toUTCString();
		}
		ECB.slow.cookies.cookie(name,value||"",options);		
	}

	// for lazy loaded section, only apply to newly loaded section
	var root = rootElement;
    if (!rootElement){
		root = document.querySelector("main"); 
	}

	// attempt to load preferred language from cookie or browser settings
	var preferredLanguage = ECB.slow.cookies.cookie('preferredLanguage');
	if(preferredLanguage==null) {
		preferredLanguage = navigator.language||navigator.userLanguage;
		preferredLanguage=preferredLanguage.substr(0,2); 
		setCookie('preferredLanguage',preferredLanguage,365);
	}
 
	langVersionInstances = root.querySelectorAll(".ecb-langSelector");
	
	for(var j = 0; j < langVersionInstances.length; j++){
		var langSelector = langVersionInstances[j];
		
		var langpopup = langSelector.querySelector('.ecb-langPopup');
		if (langpopup){
			var otherlangs = langpopup.querySelectorAll('.otherlang a');
			for (var i = 0; i < otherlangs.length; i++){
				otherlangs[i].addEventListener("click", function(e){
					lng = this.getAttribute('lang'); 
					setCookie('preferredLanguage',lng,365);
				});
			}
		}	

		var showlangPopup = function(e) {									
			var langpopup = this.parentNode.querySelector(popup);
			if (langSelector.getBoundingClientRect().left + langpopup.getBoundingClientRect().width > window.innerWidth) {
				langpopup.style.left = 'auto';
				langpopup.style.right = '0';
			} else {//taken
				langpopup.style.left = '';
				langpopup.style.right = ''; 
			}
			langpopup.style.display = "block";

			if(e){
				e.stopPropagation();				
			}

		};

		var hidelangPopup = function() {			
			this.parentNode.style.display = "none";
		};

		var closeButton = langSelector.querySelector(_closeBtn);
		var openerDiv = langSelector.querySelector(_opener);
		closeButton && closeButton.addEventListener("click",hidelangPopup);
		openerDiv && openerDiv.addEventListener("click", showlangPopup);

		//check if after removing preferred lang from popup - popup is epmty and remove plus icon to open it
		//adding ()
		var langCounter = langSelector.querySelector(".lang-counter");
		if(langCounter){
			var langCounterVal = parseInt(langCounter.innerText.replace("(","").replace(")","").trim());

			//check if preferedlang is in popup and remove it - also decrease the number by one then....
			var prefLangA = langSelector.querySelector(".ecb-langPopup .otherlang a[lang="+preferredLanguage+']');

			if ( prefLangA ) {				

				//add actual number and add ()
				langCounterVal--;

				//to lowercase + add markup								
				var markup = '<a lang="'+preferredLanguage+'" href="'+prefLangA.getAttribute('href')+'">'+
					prefLangA.querySelector('span.ecb-full').innerText.toUpperCase()+
					'</a>';

				// add clone with new markup outside list
				langSelector.querySelector('.offeredLanguage').innerHTML += markup;
				
				//remove original item from list
				prefLangA.parentNode.removeChild(prefLangA);
				
			}

			if ( langCounterVal == 0 ) {
				moreLangsNode = langSelector.querySelector(".moreLanguages");
				moreLangsNode.parentNode.removeChild(moreLangsNode);
			}else{
				langSelector.querySelector(".lang-counter").innerText = "("+langCounterVal+")";
			}
		}
	}

	var hideAllPopups = function(e){
		ECB.slow.forEach(document.querySelectorAll(popup),function(popupItem){
			if (e == null || !e.target || !popupItem.contains(e.target)) {
				popupItem.style.display = "none";
			}
		});
	}

	document.addEventListener("click", hideAllPopups);
	//window.addEventListener("scroll", hideAllPopups);

};
//first see if has cookie
//else check browserlang


ECB.componentList = ECB.componentList || [];

ECB.slow.manageComponents = function (rootElement) {	
		

	if(!ECB.componentHandler){		
		ECB.componentHandler = ECB.slow.componentHandlerFactory(			
			['init', 'resize', 'scroll','orientationchange'], // functions that you can batch call on all plugins
			['init'] // Functions that should only be called once per components
		);

		// plugins should be robust to these functions firing before their init function fires
		window.addEventListener('resize', ECB.componentHandler.resize);
		document.addEventListener('orientationchange', ECB.componentHandler.orientationchange);
		document.addEventListener('scroll', ECB.componentHandler.scroll);
	}

	// add new components that have been added to the componentList
	ECB.componentHandler.addComponents(ECB.componentList);

	// clear the public componentlist
	ECB.componentList = [];

	// initialize new components
	ECB.componentHandler.init(rootElement);
};
ECB.slow.menu = (function () {

    
    var menuStructure = false;
    var menuSelected = [];
    var menuSelectedNode = null;
    var menuLoadedHook = [];
    var previousLevelIndex = 0;
    var isVerticalMouseMovement = false;
    var previousX, previousY, previousMouseTime;

    var openMenuWhenReady = false;
    var isHomepage = false;

    var hamburgerMenuNode, levelNodes, pagesInSectionHolder;


    var hamburgerButton, doc_header, additionalLinkItem,
    htmlElement, bodyElement, additionalLinkHtml;
    

    var initVars = function(){
        hamburgerButton = document.getElementById('hamburger');
        doc_header = document.getElementById('ecb-doc-header');
        additionalLinkItem = document.getElementById('hamburger') ? document.getElementById('hamburger').querySelector('.menu-additional-links') : false;
        pagesInSectionHolder = document.getElementById('pages-in-section-holder');
        htmlElement = document.documentElement;
        bodyElement = document.body;
        additionalLinkHtml = additionalLinkItem ? additionalLinkItem.outerHTML : '';
        isHomepage = document.location.pathname.startsWith("/home/html/index.");

        addEventListeners();

        addMenuLoadedHook(attachMenu);
    }

    var toggleMenu = function (e) {
        //check actual state of menu        
        if(!hamburgerMenuNode){
            openMenuWhenReady = true;
            return;
        }

        var currentState = hamburgerMenuNode.classList.contains('active');

        if (currentState) {
            // menu is opened
            cleanMenu();

        } else {
            // menu is closed            
            buildMenu();

        }

        e.preventDefault();
        return false;
    }

    var safelyOpenMenu = function(){
        if(hamburgerMenuNode && !hamburgerMenuNode.classList.contains('active'))   {
            buildMenu();
        }
    }

    var calculateMouseMovementAngle = function () {
        
        hamburgerMenuNode.addEventListener('mousemove', ECB.slow.debounce(function (mouseEvent) {
            var currentMouseTime = (new Date()).getTime();
            if (previousX) {
                var diffX = Math.abs(mouseEvent.pageX - previousX);
                var diffY = mouseEvent.pageY - previousY;

                if(Math.abs(diffX)<4 && Math.abs(diffY)<4){
                    return;
                }

                var angle = Math.abs(Math.atan2(diffY, diffX) / Math.PI * 180)
                
                isVerticalMouseMovement = (angle > 70);
            }

            previousX = mouseEvent.pageX;
            previousY = mouseEvent.pageY;
            previousMouseTime = (new Date()).getTime();
        },10,true,true));
    }

    var resetPreviousMouseCoordinates = function () {
        previousX = previousY = undefined;
        isVerticalMouseMovement = false;
    }

    var buildMenu = function () {
        hamburgerButton.classList.add('open');
        updateLevel(null, 0, menuStructure);
        hamburgerMenuNode.classList.add('active');
        htmlElement.classList.add("no-scroll");
        bodyElement.classList.add("no-scroll");        
        showInNavigation(0,true);
    }

    var cleanMenu = function () {
        menuSelected = [];
        hamburgerButton.classList.remove('open');
        hamburgerMenuNode.removeAttribute('class');
        hamburgerMenuNode.classList.add("anim");        
        htmlElement.classList.remove("no-scroll");
        bodyElement.classList.remove("no-scroll");
        for (var i = 0; i < 4; i++) {
            levelNodes[i].classList.remove('hide');
            levelNodes[i].classList.remove('active');
            levelNodes[i].classList.remove('activeAnim');
        }
        resetPreviousMouseCoordinates();
    }

    var unSelectAllMenuItems = function(){
        updateLevel(null, 0, menuStructure);
        switchLevelClass(-1);        
        menuSelected = [];
        menuSelectedNode = null;
    }

    var fixLevelHeights = function () {
        //get talles level
        var tallestLevel = 0;

        hamburgerMenuNode.style.height = "auto";
        for (var i = 0; i < levelNodes.length; i++) {
            levelNodes[i].style.height = "auto";
            if (tallestLevel < levelNodes[i].offsetHeight) {
                tallestLevel = levelNodes[i].offsetHeight;
            }
        }

        // add height of additional button
        hamburgerMenuNode.style.height = (tallestLevel + (additionalLinkItem ? 62 : 0)) + "px";
        for (var i = 0; i < levelNodes.length; i++) {
            levelNodes[i].style.height = tallestLevel + "px";
        }
    }

    var li_elementActivated = function (li_element,initialOpening) {
        var levelIndex = getLeveLFromLevelElement(li_element.parentElement.parentElement);
        var nodeIndex = getIndexFromLiElement(li_element);

        swapShowClasses(li_element);

        switchShowing(li_element, levelIndex, nodeIndex,initialOpening);

        fixLevelHeights();
    }

    var swapShowClasses = function (li_element) {
        //remove 
        var li_elements = li_element.parentElement.querySelectorAll('li');
        for (var i = 0; i < li_elements.length; i++) {
            li_elements[i].classList.remove('show');
        }

        // Only add the show class if the item has children
        if (!!li_element.querySelector('.next')) {
            li_element.classList.add('show');
        }
    }

    var getLeveLFromLevelElement = function (level) {
        return parseInt(level.id.substr(level.id.lastIndexOf('-') + 1));
    }

    var getIndexFromLiElement = function (li_element) {
        return parseInt(li_element.attributes['data-index'].value);
    }

    var switchLevelClass = function (levelIndex) {
        hamburgerMenuNode.classList.remove("level-0");
        hamburgerMenuNode.classList.remove("level-1");
        hamburgerMenuNode.classList.remove("level-2");
        hamburgerMenuNode.classList.remove("level-3");

        hamburgerMenuNode.classList.add("level-" + levelIndex);
        previousLevelIndex = levelIndex+1;
    }

    var switchShowing = function (li_element, levelIndex, nodeIndex,initialOpening) {
        menuSelected[levelIndex] = nodeIndex;

        menuSelected.splice(levelIndex + 1);
        menuSelectedNode = getNodeFromMenuSelected();
        

        if (menuSelectedNode && menuSelectedNode.children.length > 0) {
            updateLevel(li_element, levelIndex + 1, menuSelectedNode);
            switchLevelClass(levelIndex);

            if(initialOpening){
                showInNavigation(levelIndex + 1, initialOpening);
            }            
        } else {
            removeAllUpperLevels(levelIndex + 1, true);
            switchLevelClass(levelIndex - 1);
            
        }
    }

    var showInNavigation = function (levelIndex, initialOpening) {
        var activeItem = levelNodes[levelIndex].querySelector('li.active');

        if (!!activeItem && !!activeItem.querySelector('a.next')) {
            li_elementActivated(activeItem,initialOpening);            
        }
    }

    var getNodeFromMenuSelected = function () {
        var result = null;

        var searchNode = menuStructure;
        for (var i = 0; i < menuSelected.length; i++) {
            result = searchNode.children[menuSelected[i]];
            searchNode = result;
        }

        return result;
    }

    var addEvents = function (levelIndex) {
        var levelDiv = levelNodes[levelIndex];
        var li_elements = levelDiv.querySelectorAll('li');

        for (var i = 0; i < li_elements.length; i++) {
            var li_element = li_elements[i];
            var li_element_menu_link = li_element.firstElementChild.firstElementChild;

            li_elements[i].addEventListener('click', function (e) {
                //if current item is already open close menu!
                if(e.currentTarget.classList.contains("show")){
                   
                    var parentLi = e.currentTarget.parentElement.parentElement.parentElement;

                    if(parentLi.tagName == "LI"){
                        li_elementActivated(e.currentTarget.parentElement.parentElement.parentElement);    
                    }else{
                        unSelectAllMenuItems();
                    }                    
                }else{
                    //open the clicked item                    
                    li_elementActivated(e.currentTarget);
                }
                e.stopPropagation();
            });

            li_element_menu_link.addEventListener('mouseover', function (e) {
                if (ECB.slow.isMobile()) {
                    return;
                }
                var localElement = e.currentTarget;
                var liElement = localElement.parentElement.parentElement;

                var levelIndex = getLeveLFromLevelElement(liElement.parentElement.parentElement);
                var nodeIndex = getIndexFromLiElement(liElement);

                //if this item is already selected do not select again 
                if (menuSelected.length > levelIndex && menuSelected[levelIndex] == nodeIndex) {
                    return;
                }

                
                
                var extra = 0;
                if( !menuSelectedNode || menuSelectedNode.children.length==0){
                    //current node has no children so we can safely open siblings
                    extra = 1;
                }

                
                //if (menuSelected.length <= (levelIndex+extra) || isVerticalMouseMovement) {                    
                  //  li_elementActivated(e.currentTarget);
                //} else {
                    {
                    
                    // //wait 500ms, if not left, open menu anway                    
                    var timer = window.setTimeout(function () {
                        var localTarget = e.currentTarget;
                        return function () {                            
                            li_elementActivated(localTarget.parentElement.parentElement);
                        };
                    }(), 250);

                    var onMouseOut = function () {
                        //remove timeout
                        var localTimer = timer;
                        var localLocalElement = localElement;

                        var f = function () {
                            window.clearTimeout(localTimer);
                            localLocalElement.removeEventListener('mouseout', f);                            
                        };
                        return f;
                    };

                    localElement.addEventListener('mouseout', onMouseOut());
                }
            });

        }

        if(previousLevelIndex>=levelIndex){
            levelDiv.classList.add('active');
        }else{
            levelDiv.classList.add('activeAnim');
        }
        
        levelDiv.classList.remove('hide');
        
    }

    var removeAllUpperLevels = function (levelIndex, hideAnim) {
        for (var i = levelIndex; i < 4; i++) {
            if (hideAnim && 
                (levelNodes[i].classList.contains('active') || 
                levelNodes[i].classList.contains('activeAnim'))
                ) {
                levelNodes[i].classList.add('hide'); 
            }
            if(!hideAnim){
                levelNodes[i].classList.remove('active');
                levelNodes[i].classList.remove('activeAnim');
            }
            
            levelNodes[i].innerHTML = ''
        }
    }

    var updateLevel = function (li_element, levelIndex, menuNode) {        
        
        removeAllUpperLevels(levelIndex);
        levelNodes[levelIndex].innerHTML = generateMenuDomFromStructure(menuNode);
        //hamburgerMenuNode.classList.add("anim");

        //move into position
        if (li_element) {
            li_element.appendChild(levelNodes[levelIndex]);
        }

        addEvents(levelIndex);
    }
    
    var getCurrentNavigationLevels = function () {
        var pathParts = window.location.pathname.split('/').splice(1);
        var node = menuStructure;
        var result = [];
        for (var j = 0; j < pathParts.length - 2; j++) {
            for (var i = 0; i < node.children.length; i++) {
                if (node.children[i].pathPart.toLowerCase() == pathParts[j].toLowerCase()) {
                    if(!isHomepage){
                        node.children[i].inNavigationPath = true;
                    }
                    node = node.children[i];
                    result.push(node);
                    break;
                }
            }
        }
        return result;
    }

    var generateMenuDomFromStructure = function (node) {
        var children = node.children;

        var result = "<ul>";

        for (var i = 0; i < children.length; i++) {
            var classAttribute = '';
            if (children[i].inNavigationPath) {
                classAttribute = ' class="active"';
            }
            result += '<li data-index="' + i + '"' + classAttribute + '> ';
            result +=
                '<div><a href="' + children[i].fullPath + '/html/' + (children[i].filename || "index." + (ECB.fast.isEuLanguage?ECB.currentLanguage:"en") + ".html") + '"' +
                '>' +
                children[i].name +
                '</a>';
            if (children[i].children.length > 0) {
                result += "<a class=\"next\">Child pages</a>";
            }
            result += '</div></li>';
        }
        result += "</ul>";
        return result;
    }

    var generateLevel = function (levelIndex) {
        return ECB.slow.textToHtml('<div class="level" id="menu-level-' + levelIndex + '"></div>');
    }

    var parseMenuJson = function(response){
        
        menuStructure = JSON.parse(response);

        ECB.slow.navigationStructure = menuStructure;
        ECB.slow.navigationPath = getCurrentNavigationLevels();
        
        if(menuLoadedHook.length>0){
            for(var i = 0 ; i< menuLoadedHook.length; i++){
                menuLoadedHook[i]();
            }
        }
    }

    //load full menu
    ECB.slow.fetchTextWrapper((ECB.distRoot||"")+'/shared/nav/navigation.min.' + ECB.currentLanguage + '.json', parseMenuJson, function(){
        // menu not found, fall back to English
        ECB.slow.fetchTextWrapper((ECB.distRoot||"")+'/shared/nav/navigation.min.en.json', parseMenuJson);
    });

    var attachMenu = function(){
        //clean any old menus first
        var oldMenu = document.getElementById("hamburger-menu");
        oldMenu && oldMenu.remove();
        
        hamburgerMenuNode = ECB.slow.textToHtml(
            '<div id="hamburger-menu" class="anim">' + additionalLinkHtml +
            '</div>');

        levelNodes = [];
        for (var i = 0; i < 4; i++) {
            levelNodes[i] = generateLevel(i);
            hamburgerMenuNode.appendChild(levelNodes[i]);
        }     

        doc_header.appendChild(hamburgerMenuNode); 

        if(openMenuWhenReady){
            safelyOpenMenu();
        }

        fillPagesInSection();
        
    }

    var fillPagesInSection = function(){
        if(pagesInSectionHolder){
            var currentNode = getCurrentNavigationLevels();
            if(currentNode.length){

                var visitingNode = currentNode[currentNode.length-1];
                if(visitingNode.children.length){

                    //check if we have lazy loaded element on page, if so go above:
                    var lazyloadContainer = document.getElementById("lazyload-container");
                    if(lazyloadContainer){
                        var lazyloadContainerParent = lazyloadContainer.parentElement;
                        lazyloadContainerParent.parentElement.insertBefore(pagesInSectionHolder,lazyloadContainerParent);
                    }

                    pagesInSectionHolder.classList.add("-active");
                    if(visitingNode.children.length<4){
                        pagesInSectionHolder.classList.add("-small");
                    }else if(visitingNode.children.length<7){
                        pagesInSectionHolder.classList.add("-medium");
                    }else if(visitingNode.children.length<10){
                        pagesInSectionHolder.classList.add("-large");
                    }
                    var contentBox = pagesInSectionHolder.querySelector(".content-box");
                    var listString ="<ul>";
                    ECB.slow.forEach(visitingNode.children,function(child){
                        listString+="<li><a href=\""+child.fullPath+"/html/index."+(ECB.fast.isEuLanguage?ECB.currentLanguage:"en")+".html\">"+child.name+"</a></li>";
                    });
        
                    listString += "</ul>";
        
                    contentBox.innerHTML = listString;
                }else{
                    pagesInSectionHolder.parentElement.removeChild(pagesInSectionHolder);
                }
           }
        }
        
    }



    var closeMenu = function (e) {
        var hamburgerMenu = document.getElementById('hamburger-menu');        
        
        if (!!hamburgerMenu && (e == null || !hamburgerMenu.contains(e.target) && !hamburgerButton.contains(e.target) && (!doc_header.contains(e.target)||!ECB.slow.currentBreakpoint.startsWith("smart")) )) {            
            cleanMenu();
        }
    }

    var addEventListeners = function () {
        // toggle menu when clicking on hamburger
        if(!hamburgerButton){
            hamburgerButton = document.getElementById('hamburger');
            additionalLinkItem = document.getElementById('hamburger') ? document.getElementById('hamburger').querySelector('.menu-additional-links') : false;
            additionalLinkHtml = additionalLinkItem ? additionalLinkItem.outerHTML : '';
            addEventListeners();
        }
        hamburgerButton.addEventListener('click', toggleMenu);

        // close menu when clicking anywhere else
        document.addEventListener('click', closeMenu);
        document.addEventListener('touchstart', closeMenu);


        var activeNavBarButton = document.querySelector("#ecb-mainnavwrapper a.active");
        
        var isHubPage = document.location.pathname.split("/").filter(function(part){return part.length>0;}).length==3;
        if(!!activeNavBarButton && isHubPage){
            activeNavBarButton.addEventListener("click",function(e){
                e.preventDefault();
                e.stopPropagation();

                if(hamburgerButton.classList.contains("-highlight")){
                    toggleMenu(e);
                }else{
                    hamburgerButton.classList.add("-highlight");
                }
                
                
                return false;
            });
        }

    }

    var getNavigationTree = function(){
        return menuStructure;
    }

    var getMenuSelected = function(){
        return menuSelected;
    }

    var addMenuLoadedHook = function(hook){
        if(typeof(hook)!='function'){
            return;
        }
        
        if(menuStructure){
            hook();
        }else{
            menuLoadedHook.push(hook);
        }
    }

    var getSectionLabels = function(){
        return ECB.slow.navigationStructure && ECB.slow.navigationStructure.children.map(function(section){return section.name;});
    }

    return {
        init: initVars,
        addMenuLoadedHook: addMenuLoadedHook,
        closeMenu: closeMenu,
        getSectionLabels: getSectionLabels
    }

})();
ECB.slow.omoSortableTable = function () {
    $("table").tablesorter({
        headers: { 
            0: { 
                sorter:"text" 
            }, 
            1: { 
                sorter:"text" 
            }, 
            2: { 
                sorter:"text" 
            }, 
            3: { 
                sorter:"EUshortdate" 
            }, 
            4: { 
                sorter:"EUshortdate" 
            }, 
            5: { 
                sorter:false 
            }, 
            6: { 
                sorter:false 
            } 
        }
    });
}
ECB.slow.preferredLanguageCheck = function(){
    var showLangBar = function(langIsoCode){
        //get html for top header
        var docHeader = document.getElementById("ecb-doc-header");
        ECB.slow.fetchTextWrapper('/shared/nav/lang-top-notice.'+langIsoCode+".html", function(noticeContents){
            docHeader.insertAdjacentHTML("afterBegin",noticeContents);
            document.body.classList.add("-top-notice");

            docHeader.querySelector(".top-notice .lang-message").addEventListener("click",function(){
               //find language selector language and click it
               document.querySelector("#language-values a[lang="+langIsoCode+"]").click();
               window.localStorage.removeItem("hasSeenLanguageCheck");
            });

            window.localStorage.setItem("hasSeenLanguageCheck","true");
        });
    }

    ECB.slow.preferredLanguage = navigator.language.substr(0,2);

    if(ECB.slow.preferredLanguage != ECB.currentLanguage){
        var preferredLanguageIsEU = !!(document.querySelector("#language-values a[lang="+ECB.slow.preferredLanguage+"]:not([specialLang])"));

        if(preferredLanguageIsEU && window.localStorage.getItem("hasSeenLanguageCheck")!="true"){
            showLangBar(ECB.slow.preferredLanguage);
            return;            
        }
    }

    var lastLanguage = localStorage.getItem('lastLanguage'); 
    if(lastLanguage && (lastLanguage != ECB.currentLanguage)){
        showLangBar(lastLanguage);
        localStorage.removeItem("lastLanguage"); 
    }
   
}


ECB.slow.hideCookieMessage = function(){    
    if (navigator.userAgent.indexOf('AddSearchBot') !== -1) {
        var cookieConsent = document.getElementById("cookieConsent");
        if (cookieConsent) {
            cookieConsent.style.display = "none";
        }
    }
}
ECB.slow.scroll = function () {
    var docHeader = document.getElementById('ecb-doc-header');
    var prevScrollpos = 0;

    var scrollHandler = function (e) {
        // get sticky Class of hamburger button
        var newScrollPos = window.pageYOffset;
        var isSticky = docHeader.classList.contains('sticky');
        var isActive = docHeader.classList.contains('active');

        var showNav = (newScrollPos - prevScrollpos) < 0;

        var scrollPosition = newScrollPos > 500;

        // if (isActive != showNav) {
        //     //ECB.slow.menu.closeMenu();
        //     docHeader.classList.toggle('active');
        // }

        //if (isSticky != scrollPosition && (isSticky || showNav || ECB.slow.currentBreakpoint.substr(0, 10) == "smartphone")) {
        if (isSticky != scrollPosition) {
            docHeader.classList.toggle('sticky');
            docHeader.classList.toggle('active');
        }

        prevScrollpos = newScrollPos;
    }

    window.addEventListener('scroll', ECB.slow.debounce(scrollHandler, 100));
};

ECB.slow.searchButton = function () {
    var searchContainer = document.getElementById('addSearch-container-full');
    var searchButton = document.getElementById('searchButton');
    var searchInput = document.getElementById('searchInput');
    var navigation = document.getElementById('ecb-mainnavwrapper');
    var headerContainer = document.getElementById('ecb-doc-header');
    var mainContainer = document.getElementsByTagName('main');

    if(!searchContainer){
        return;
    }

    var fixNavigationState = function () {
        //check for out of sync state and resolve:
        if (searchButton.classList.contains("active") && !navigation.classList.contains("hidden")) {
            navigation.classList.add("hidden");
        }

        if (!searchButton.classList.contains("active") && navigation.classList.contains("hidden")) {
            navigation.classList.remove("hidden");
            navigation.classList.add('-animate');
        }
    }


    var toggleSearch = function (e) {

        fixNavigationState();


        searchInput.value = "";

        //if (ECB.slow.cookies.hasAcceptedCookies()) {
            searchButton.classList.toggle('active');
            searchInput.classList.toggle('active');

            if (navigation.classList.contains("hidden")) {
                //with a delay
                window.setTimeout(function () {
                    navigation.classList.remove('hidden');
                    navigation.classList.add('-animate');


                    fixNavigationState();
                }, 325);
            } else {
                navigation.classList.add('hidden');
                navigation.classList.remove('-animate');
            }


            if (searchInput.classList.contains('active')) {
                searchInput.focus();
                searchButton.classList.add('closeButton');
                openSearchContainer(e);
            } else {
                searchButton.classList.remove('closeButton');
                closeSearchContainer(e);
            }

        //}

        e.preventDefault();
        return false;
    }


    var openSearchContainer = function (e) {

        if (searchInput.value != null && searchInput.value != "") {
            ECB.slow.menu.closeMenu();
            document.body.classList.add("fixed");
            headerContainer.classList.add('fixed');
            searchContainer.classList.add('active');
            searchContainer.classList.add("overflow");


            if (document.body.classList.contains("section-home")) {
                searchContainer.classList.add("home-type");
            }

            if (headerContainer.classList.contains("sticky")) {
                searchContainer.classList.add("smallHeaderType");
                searchContainer.classList.remove("bigHeaderType");
            } else {
                searchContainer.classList.add("bigHeaderType");
                searchContainer.classList.remove("smallHeaderType");
            }
        } else {
            closeSearchContainer(e);
        }

    }

    var closeSearchContainer = function (e) {
        document.body.classList.remove("fixed");
        searchContainer.classList.remove('active', "overflow");
        headerContainer.classList.remove('fixed');

    }


    var addEvents = function () {
        // close menu when clicking anywhere else in header

        searchButton.addEventListener('click', toggleSearch);
        searchContainer.addEventListener('click', function (e) {
            if ((e.target.classList.contains('blue-bg') || e.target.classList.contains('white-bg'))) {
                toggleSearch(e);
            }
        });
        headerContainer.addEventListener('click', function (e) {
            var header = document.getElementById('page-actions');
            if ((searchInput.classList.contains('active') && !header.contains(e.target))) {
                toggleSearch(e);
            }
        });
        headerContainer.addEventListener('touchstart', function (e) {
            var header = document.getElementById('page-actions');
            if ((searchInput.classList.contains('active') && !header.contains(e.target))) {
                toggleSearch(e);
            }
        });

        searchInput.addEventListener('keyup', openSearchContainer);


    }

    addEvents();
};

ECB.slow.settings = function(){
    var setProjectName = function() {

		var bodyClassList = document.body.classList; 

		if (bodyClassList.contains('project-ecb')) {
			ECB.projectName = 'ecb';
		} else if (bodyClassList.contains('project-ssm')) {
			ECB.projectName = 'ssm';
		} else if (bodyClassList.contains('project-esrb')) {
			ECB.projectName = 'esrb';
		}else{
            ECB.projectName = false;
        }
    };
    
    var isIe = function () {
        return navigator.appVersion.indexOf('MSIE') != -1;                
    }

    setProjectName();

    //to do check if IE is used and show message
}
ECB.slow.sharing = function () {
    var socialSharingElement = document.getElementById("ecb-social-sharing");
    var fwComp = null;


    var closeMenu = function (e) {
        if (!socialSharingElement.contains(e.target)) {
            socialSharingElement.classList.remove("-active");
        }

    }

    var updateSharingElement = function () {
        // var fwComps = document.querySelectorAll(".-fullwidth-js");
        if(ECB.slow.currentBreakpoint!=="desktop"){
            socialSharingElement.classList.remove("-overlapping");  
            return;
        }
        var ssRect =socialSharingElement.getBoundingClientRect();
        
        for (var j = 0; j < fwComps.length; j++) {
            var fwRect =fwComps[j].getBoundingClientRect();                

            if (fwRect.top <= ssRect.top + ssRect.height && fwRect.top + fwRect.height > ssRect.top) {                
                // needs to be changed to a class
                if(!socialSharingElement.classList.contains("-overlapping")){
                    socialSharingElement.classList.remove("-active");                            
                }
                socialSharingElement.classList.add("-overlapping");

                return;
            } 
        }

        //this line is only reached if no object overlaps
        socialSharingElement.classList.remove("-overlapping");  
        socialSharingElement.classList.remove("-active");                  
    };


    var addFullWidthScrollCheck = function(){
        // add fullwidthclass to full width components
        fwComps = document.querySelectorAll("main>:not(#ecb-social-sharing):not(.title):not(header):not(.section):not(.toBeUpdated):not(.page-notice)");

        // hide social sharing when overlaps full width element
        window.addEventListener('scroll', ECB.slow.debounce(updateSharingElement,100));
        window.addEventListener('resize', ECB.slow.debounce(updateSharingElement,100));
    }

    // check that social sharing buttons exist
    if (!!socialSharingElement) {
        socialSharingElement.addEventListener("click", function () {
            socialSharingElement.classList.toggle("-active");
        });

        // close menu when clicking anywhere else
        document.addEventListener('click', closeMenu);
        document.addEventListener('touchstart', closeMenu);

        if(!document.body.classList.contains("publication-viewer")){
            addFullWidthScrollCheck();
        }
        
    }


    
    
        
    // for (var i = 0; i < fwComps.length; i++) {
    //     fwComps[i].classList.add('-fullwidth-js');
    // }
    // var fwComps = [];
    

    
    
};
ECB.slow.sitedir = function () {
    var sitedir = document.getElementById("sitedir");

    //load the sitedir bit only if the element exists
    if (typeof(sitedir) != 'undefined' && sitedir != null) {
        function print_children(navigationItems) {
            var result = '<ol>';
            navigationItems.forEach(function(navigationItem) {
                if(navigationItem.children.length) {
                    result += "<li><a href='"+navigationItem.fullPath+"' class='no-icon'>"+navigationItem.name+"</a>";
                    result += print_children(navigationItem.children);
                    result += '</li>'
                } else {
                    result += "<li><a href='"+navigationItem.fullPath+"' class='no-icon'>"+navigationItem.name+"</a></li>";
                }
            });
            result += '</ol>';
            return result;
        }
        const lang =  ECB.currentLanguage ?  ECB.currentLanguage : 'en';
        ECB.slow.fetchTextWrapper('/shared/nav/navigation.min.' +lang + '.json', function (response) {
            var html = '<div class="list -top-arrow -index"><ol>';
            menuStructure = JSON.parse(response).children;
            menuStructure.forEach(function(root) {
                html += "<li><a href='"+root.fullPath+"' class='no-icon'>"+root.name+"</a>";
                html += print_children(root.children);
                html += "</li>";
            });
            html += "</ol></div>";
            sitedir.innerHTML = html;
        })
    }

};
ECB.slow.slider = function () {

    ECB.slow.forEach(document.querySelectorAll(".carousel, .article-slider, .banknotes-slider"), function (slider) {

        var elem = slider.querySelector('.items');
        var isBN = slider.classList.contains('banknotes-slider');
        var isCN = slider.classList.contains('coins');
        if (isCN) {elem = slider;}
        var buttonPrev = slider.querySelector('.slider.-left, .arrow-left');
        var buttonNext = slider.querySelector('.slider.-right, .arrow-right');
        var arrowsDisabled = false;
        var flick = new Flickity(elem, {
            contain: true,
            groupCells: true,
            draggable: true,
            prevNextButtons: true, // disable previous & next buttons and dots (isBN)
            pageDots: isCN,
            adaptiveHeight: true,
            cellAlign: (isBN) ? 'center' : 'center',
            on: {
                ready: function () {
                    if (!isBN && !isCN && this.slides.length <= 1) {
                        buttonPrev.style.visibility = 'hidden';
                        buttonNext.style.visibility = 'hidden';
                        elem.style.margin = 'auto';
                        arrowsDisabled = true;
                    }
                }
            }
        });

        if (isBN) {
            ECB.slow.forEach(document.querySelectorAll('.banknotes-slider .item a, .bn-centered-tabs a'), function (elem) {
                elem.addEventListener('click', function () { flick.resize(); });
            });
        } else if (!isCN) {
            buttonPrev.addEventListener('click', function (e) {
                flick.previous(); //isWrapped:true > the first slide will be selected if at the last slide
            });
            buttonNext.addEventListener('click', function (e) {
                flick.next(); //isWrapped:true > the first slide will be selected if at the last slide
            });

            flick.on('select', function () {
                if (flick.slides.length > 1 && arrowsDisabled) {
                    buttonPrev.style.visibility = 'visible';
                    buttonNext.style.visibility = 'visible';
                    elem.style.margin = '0';
                    arrowsDisabled = false;
                } else if (flick.slides.length <= 1 && !arrowsDisabled) {
                    buttonPrev.style.visibility = 'hidden';
                    buttonNext.style.visibility = 'hidden';
                    elem.style.margin = 'auto';
                    arrowsDisabled = true;
                }
            });
        }
    });
}
ECB.slow.sortableTable = function () {
    $(function(){$.tablesorter.addParser({
        // set a unique id
        id: 'textDate',
        is: function(s, table, cell, $cell) {
          // return false so this parser is not auto detected
          return false;
        },
        format: function(s, table, cell, cellIndex) {
          // format your data for normalization
          var s2= s.replace(/Jan/,0)
            .replace(/Feb/,1)
            .replace(/Mar/,2)
            .replace(/Apr/,3)
            .replace(/May/,4)
            .replace(/Jun/,5)
            .replace(/Jul/,6)
            .replace(/Aug/,7)
            .replace(/Sep/,8)
            .replace(/Okt/,9)
            .replace(/Nov/,10)
            .replace(/Dec/,11);
          s2=s2.split(' ');
          var r= -1*(parseInt(s2[2])+parseInt(s2[1])/12+(parseInt(s2[0])-1)/365);
          return r;
        },
        // set type, either numeric or text
        type: 'numeric'
      });
      $("#sortable_table").tablesorter({headers: { 0: { sorter: 'textDate' } },sortList: [[0,1,2]]});
  });
}
ECB.slow.initSoundcloud = function (rootElement) {
    rootElement = rootElement || document;
    var soundcloudSelector = '[data-soundcloud-id]';
    if (rootElement.querySelectorAll(soundcloudSelector).length > 0){
        if(ECB.slow.cookies.hasAcceptedCookies()){
            // add api js
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = 'https://w.soundcloud.com/player/api.js';    
            document.head.appendChild(script);

            var videonodes = rootElement.querySelectorAll(soundcloudSelector);
            for (var i = 0; i < videonodes.length; i++) {
                videonodes[i].innerHTML = '<iframe id="soundcloud-player" width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/'+videonodes[i].getAttribute("data-soundcloud-id")+'&amp;color=%23003299&amp;auto_play=false&amp;hide_related=true&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;show_teaser=true"></iframe>'
            } 
        } 
    }
};  
ECB.slow.table = function(){
    var tables = document.querySelectorAll("table");
    var tableComponents = document.querySelectorAll("main .table");
    var waitingForFrame = false;
    var visibleTables = [];
    var arrowHeight = 27;

    ECB.slow.forEach(tables,function(table){

        //check for collapsible tables (used on the Short Term European Paper page)
        if(table.querySelector("tr.subrow")){
            
            ECB.slow.forEach(table.querySelectorAll("tr"),function(row){
                //check if row has an expandable button
                var expandImage = row.querySelector("td:first-child>img[id]");
                if(expandImage){
                    expandImage.parentElement.style.cursor="pointer";
                    expandImage.parentElement.addEventListener("click",function(){
                        var imageSrc = expandImage.attributes.src.value;
                    
                        if(imageSrc.indexOf("plus")!=-1){
                            imageSrc = imageSrc.replace("plus","minus");
                        }else{
                            imageSrc = imageSrc.replace("minus","plus");
                        }

                        expandImage.attributes.src.value = imageSrc;
                        
                        
                        var rowSelector = "tr[id^="+expandImage.id+"]";

                        if(expandImage.id == "rall"){
                            rowSelector = "tr.subrow";
                        }

                        ECB.slow.forEach(table.querySelectorAll(rowSelector),function(subRow){
                            subRow.classList.toggle("hidden");
                        });
                    });
                }
            });
        }
    });
    
    // All code below centers the overflow arrows for large tables into the visible area of the table
    if(window.IntersectionObserver) {
        var observer = new IntersectionObserver(function(entries) {
            visibleTables = [];
            ECB.slow.forEach(entries,function(entry){
                if(entry.isIntersecting === true){
                    visibleTables.push(entry.target);
                }
            });	
            updatePositionOfArrow();	
        }, { threshold: [0] });
    }
    
    ECB.slow.forEach(tableComponents, function(table){
        observer.observe(table);
    });

    var updatePositionOfArrow = function(){
        //only update if a table is visible
        if(visibleTables.length > 0){            
            var screenHeight = window.innerHeight;
            var slidesPerTable = [];
            ECB.slow.forEach(visibleTables, function(table){
                var slides = Array.from(table.querySelectorAll(".slide span"));

                if(slides.length>0){
                    
                    //helpers vars
                    var top = table.getBoundingClientRect().top;                    
                    var height = table.offsetHeight;

                    //start of visible area in table coordinate
                    var start = top>0?0:-1*top;
                    //end of visible area in table coordinate
                    var end = Math.min(height,screenHeight - top);                    

                    //top position of arrow
                    var position = (end - start)/2 + start - arrowHeight/2;

                    //save for use in move later
                    slidesPerTable.push({"position":position+"px","slides":slides});
                }

            });

            // do not request new frame if already waiting for a frame
            if(!waitingForFrame){
                requestAnimationFrame(function(){
                  // update position
                  ECB.slow.forEach(slidesPerTable, function(tableSlides){
                      ECB.slow.forEach(tableSlides.slides, function(slide){
                            slide.style.top = tableSlides.position;
                      });
                  });
                  waitingForFrame = false;
              });
            }
          waitingForFrame = true;
        }
    }
    

	window.addEventListener('scroll', function(e) {
        updatePositionOfArrow();
	});
}
ECB.slow.tableResize = function (rootElement) {
    rootElement = rootElement || document;

    const contentWidth = 1280;

    var checkSliders = function(tableWrapper){
        if(!hasArrow(tableWrapper)) return;

            var arrowLeft = tableWrapper.querySelector(".slide.-left");
            var arrowRight = tableWrapper.querySelector(".slide.-right");

            if (tableWrapper.scrollLeft > 0) {
                arrowLeft.style.visibility = 'visible';
            } else {
                arrowLeft.style.visibility = 'hidden';
            }

            if ((tableWrapper.scrollLeft + 1) >= (tableWrapper.scrollWidth - tableWrapper.clientWidth)) {
                arrowRight.style.visibility = 'hidden';
            } else {
                arrowRight.style.visibility = 'visible';
            }
    };

    var addEventListeners = function(tableWrapper, tableElement){

        var isDown = false;        
        var startX = 0;
        var scrollLeft = 0;

        tableWrapper.addEventListener('mousedown', function (e) {            
            if(!hasArrow(tableWrapper)) return;            
            isDown = true;
            tableWrapper.style.cursor = 'grabbing';
            startX = e.pageX;
            scrollLeft = tableWrapper.scrollLeft;
        });
        tableWrapper.addEventListener('mouseleave', function () {            
            isDown = false;
        });
        tableWrapper.addEventListener('mouseup', function () {            
            isDown = false;

            if(!hasArrow(tableWrapper)) return;

            tableWrapper.style.cursor = 'grab';
        });
        tableWrapper.addEventListener('mousemove', function (e) {
            if(!hasArrow(tableWrapper)||!isDown) return;            

            e.preventDefault();

            tableWrapper.style.cursor = 'grabbing';
            var x = e.pageX;
            var walk = (x - startX); //scroll-fast
            tableWrapper.scrollLeft = scrollLeft - walk;
        });

        tableWrapper.addEventListener('scroll', function (e) {
            checkSliders(tableWrapper);
            e.preventDefault();
        });

    }

    var hasArrow = function(tableWrapper){
        return !!tableWrapper.querySelector('.slide');
    }

    var isBigTable = function(tableWrapper, tableElement){
        var tableWidth = (tableElement) ? tableElement.clientWidth : 0;
        console.log("testing big: "+tableElement.clientWidth+", "+tableWrapper.clientWidth);
        return (tableWidth > tableWrapper.clientWidth);        
    }

    var checkIfResizing = function(component, tableWrapper, tableElement){

        var delta = 100;

        if(isBigTable(tableWrapper,tableElement)){            
            if(!hasArrow(tableWrapper)){                
                
                component.classList.add('-full-width');
                tableWrapper.style.cursor = 'grab';

                if (!tableWrapper.querySelector(".slide")) {
                    tableWrapper.insertAdjacentHTML('beforeend', "<div class='slide -left'><span></span></div><div class='slide -right'><span></span></div>");
                }

                arrowLeft = tableWrapper.querySelector(".slide.-left");
                arrowRight = tableWrapper.querySelector(".slide.-right");

                arrowLeft.addEventListener('click', function (e) {
                    e.preventDefault();
                    tableWrapper.scrollBy({
                        left: Math.E * 2 * (-delta),
                        behavior: 'smooth'
                    });
                });

                arrowRight.addEventListener('click', function (e) {
                    e.preventDefault();
                    tableWrapper.scrollBy({
                        left: Math.E * 2 * delta,
                        behavior: 'smooth'
                    });
                });

                
            }

            checkSliders(tableWrapper);

        }else if(hasArrow(tableWrapper)){ 
                       
            component.classList.remove('-full-width');
            tableWrapper.style.cursor = 'auto';

            if (tableWrapper.querySelector(".slide")) {                
                tableWrapper.removeChild(tableWrapper.querySelector(".slide.-left"));
                tableWrapper.removeChild(tableWrapper.querySelector(".slide.-right"));
            }

            //do another test to see if you should be big
            checkIfResizing(component, tableWrapper, tableElement);
        }
    }
    
    var resizeHandler = function () {
        window.addEventListener('resize',ECB.slow.debounce(function(){
            loopOverAllTables();
        },500));
    }

    var loopOverAllTables = function(init){
        ECB.slow.forEach(rootElement.querySelectorAll(".table"), function (component) {            

            var tableWrapper = component.querySelector(".wrapper");            
            var tableElement = tableWrapper && tableWrapper.querySelector("table");

            if(tableWrapper && tableElement){
                if(init){
                    addEventListeners(tableWrapper, tableElement);
                }
                
                checkIfResizing(component, tableWrapper, tableElement);                
                
            }            
        });
    }   

    var init = function () {
        loopOverAllTables(true);

        resizeHandler();        
    }

    init();

}

ECB.slow.tabs = function (rootElement) {

    rootElement = rootElement || document;
    // only implement a jump when 
    ECB.slow.forEach(rootElement.querySelectorAll(".tabs-container > label"), function (label) {
        label.addEventListener('click', function (e) {
            var relatedInput = rootElement.getElementById(e.currentTarget.getAttribute("for"));
            if (ECB.slow.currentBreakpoint.substr(0, 10) == "smartphone") {
                document.documentElement.scrollTop += e.currentTarget.parentNode.getBoundingClientRect().top;
                
                if(relatedInput.checked){
                    label.classList.toggle("-closed");
                }else{
                    ECB.slow.forEach(rootElement.querySelectorAll(".tabs-container > label"), function (label) {
                        label.classList.remove("-closed");
                    });
                }
            }
            
            
        });
    });
};
ECB.slow.teaserLinks = function(rootElement){

    rootElement = rootElement || document;

    var teaserComponents = [
        ".slider-large",
        ".box",                
        ".combo-box .upper",
        ".combo-box .lower",
        ".explainer-box",
        ".large-box",
        ".see-also-boxes .content-box"
    ];    
    var linkSelector = "[data-image]:not(.flickity-enabled):not([data-video]),.slider-large:not(.-video)";
    ECB.slow.forEach(rootElement.querySelectorAll(teaserComponents.join(",")),function(component){
        var isCoin = !!component.querySelector("[data-image].coins");
        // only do anything if the component contains a link
        var firstLink = component.querySelector("a");        
        if(!isCoin && firstLink && firstLink.getAttribute("href")){
        
            //convert to array so we can add component itself
            var linkItems = [].slice.call(component.querySelectorAll(linkSelector));
            if(component.matches(linkSelector)){
                linkItems.push(component);
            }
            
            // add click handler to all linkSelectors (images & titles)
            ECB.slow.forEach(linkItems,function(linkItem){  
                linkItem.style.cursor = "pointer";                                      
                
                linkItem.addEventListener("click",function(e){
                    var linkItemAttribution = linkItem.querySelector("[data-attribution]");
                    if( e==null || linkItemAttribution==null || !linkItemAttribution.contains(e.target))
                    {
                        var target = (firstLink.getAttribute("target")||"_self");
                        window.open(firstLink.getAttribute("href"),target);
                        e.preventDefault();
                    }
                });
            });

            // add zoom effect for image
            var imageSelector = "[data-image]:not(.video):not(.coins):not(.coin-cropper):not(.flickity-enabled):not([data-video])";

            var image = null;
            if(component.matches(imageSelector)){
                image = component;
            }else{
                image = component.querySelector(imageSelector);
            }

            if(image){          
                
                // add inner zoom image
                var inner = document.createElement("div");
                inner.classList.add("-inner");                
                inner.setAttribute("data-image",image.getAttribute("data-image")); 

                image.getAttribute("data-image-webp")&&inner.setAttribute("data-image-webp",image.getAttribute("data-image-webp")); 
                
                var outer = document.createElement("div");
                outer.classList.add("-outer");
                outer.appendChild(inner);
                
                //prepend                
                var hasChildren = !!image.childElementCount;
                (!hasChildren)?image.appendChild(outer):image.insertBefore(outer,image.firstChild);

                //load inner image
                ECB.fast.loadImages(image);
                
                // add classes                
                if(component.classList.contains("slider-large")){
                    component.classList.add("-hover-image");
                }else{
                    image.classList.add("-hover-image");
                }
                
            }
        }

    });
}
ECB.slow.textToHtml = function (text) {
    var parentDiv = document.createElement('div');
    parentDiv.innerHTML = text;
    if (parentDiv.children.length == 1) {
        return parentDiv.children[0];
    } else {
        return parentDiv;
    }
};
ECB.slow.utils = (function () {

    var addClass = function (el, className) {
		if (el.classList) {
			el.classList.add(className);
		  } else {
			var current = el.className, found = false;
			var all = current.split(' ');
			for(var i=0; i<all.length, !found; i++) found = all[i] === className;
			if(!found) {
			  if(current === '') el.className = className;
			  else el.className += ' ' + className;
			}
		  }
	}

	var removeEventListener = function (el, eventName, handler) {
		if (el.removeEventListener)
		  el.removeEventListener(eventName, handler);
		else
		  el.detachEvent('on' + eventName, handler);
	  }

	var removeClass = function (el, className) {
		if (el.classList)
			el.classList.remove(className);
		else
			el.className = el.className.replace(new RegExp('(^|\\b)' + className.split(' ').join('|') + '(\\b|$)', 'gi'), ' ');
	}

	var blockEventPropagation = function(e){
		e.preventDefault(); 
		return false;
	}

	var hasClass = function (el, className) {
		if (el.classList)
				return el.classList.contains(className);
			else
				return new RegExp('(^| )' + className + '( |$)', 'gi').test(el.className);
	}

	return {
		'addClass': addClass,
		'removeEventListener': removeEventListener,
		'removeClass': removeClass,
		'blockEventPropagation': blockEventPropagation,
		'hasClass': hasClass
	};
})();
ECB.youtubePlayers = {};
ECB.waitingYouTubePlayers = [];
ECB.youtubeNodes = [];

ECB.loadYouTubeAPI = function (el, id, width, height, start, subtitlesLanguage, playlistId, end, mute, autoplay, autostop) {
    //console.log(ECB.slow.cookies.hasAcceptedCookies())
    if (ECB.slow.cookies.hasAcceptedCookies()) { //check cookies    
        height = (typeof height === 'undefined' || height === false || height === '') ? 'auto' : height;
        width = (typeof width === 'undefined' || width === false || width === '') ? '100%' : width;
        subtitlesLanguage = (typeof subtitlesLanguage === 'undefined' || subtitlesLanguage === false) ? false : ECB.slow.currentLanguage;
        playlistId = (typeof playlistId === 'undefined') ? false : playlistId;
        start = (typeof start === 'undefined' || typeof start !== 'number') ? false : start;
        end = (typeof end === 'undefined' || typeof end !== 'number') ? false : end;

        if (el.parentNode.hasAttribute("data-playlist"))  
            playlistId = el.parentNode.getAttribute("data-playlist");

        if (el != null) {
            var closestVideo = el.closest(".video");
            
            closestVideo.classList.add('hasYouTubePlayer');
            el.style.display = 'none';
            var closestVideoParent = el.parentNode.closest(".-video");

            //check if closestVideoParent is the slider
            var isSlider = closestVideoParent && closestVideoParent.classList.contains("slider-large");

            if(isSlider){
                var closeButton = closestVideo.querySelector(".close");
                if(!closeButton){
                    closestVideo.insertAdjacentHTML("afterbegin","<div class=\"close\"></div>");
                    closeButton = closestVideo.querySelector(".close");
                }

                var iframe = closestVideo.querySelector("iframe");
                    iframe && (iframe.style.display = "block");

                closeButton.addEventListener("click",function(){
                    ECB.youtubePlayers[closestVideo.id].pauseVideo();
                    closestVideo.classList.remove('hasYouTubePlayer');
                    el.style.display = 'block';
                    
                    if(closestVideoParent){
                        closestVideoParent.classList.remove("-hasYouTubePlayer"); 
                    }
    
                    var iframe = closestVideo.querySelector("iframe");
                    iframe && (iframe.style.display = "none");
                });
            }
            
            
            if(closestVideoParent){
                closestVideoParent.classList.add("-hasYouTubePlayer"); 
                var image = closestVideoParent.querySelector("[data-image]");
                if(image&&closestVideoParent.classList.contains("slider-large")){
                    
                    var inner = document.createElement("div");                                    
                    inner.setAttribute("data-image",image.getAttribute("data-image")); 
                    image.getAttribute("data-image-webp")&&inner.setAttribute("data-image-webp",image.getAttribute("data-image-webp")); 
                    
                    image.appendChild(inner);    

                    ECB.fast.loadImages(image);
                }
                
            }
            
        }

        if (id in ECB.youtubePlayers) {
            //delete ECB.youtubePlayers[id]; 
            ECB.youtubePlayers[id].playVideo();
        }else{
            ECB.waitingYouTubePlayers.push(id);
        

        function onPlayerReady() {
            if (ECB.youtubePlayers[id]) {
                //ECB.youtubePlayers[id].playVideo();
                if (mute) ECB.youtubePlayers[id].mute();
            }
        }

        function generateYoutubePlayer(id) {
            var videoId = id;
            if (videoId.indexOf("---") > 0)
                videoId = videoId.split("---")[0];
            ECB.waitingYouTubePlayers.splice(ECB.waitingYouTubePlayers.indexOf(id),1);
            var vars = {
                rel: 0,
                autoplay: +autoplay,
                modestbranding: 1,
                origin: 'ecb.europa.eu',
                widget_referrer: 'ecb.europa.eu'
            };

            if (el.parentNode.hasAttribute("data-subtitles")){
                vars["cc_load_policy"] = 1,
                vars["cc_lang_pref"] = el.parentNode.getAttribute("data-subtitles").length > 0 ? el.parentNode.getAttribute("data-subtitles") : "asd"
            }

            if (start) { vars.start = start; }

            if (end) { vars.end = end; }

            if (subtitlesLanguage) {
                vars.cc_load_policy = 1;
                vars.cc_lang_pref = subtitlesLanguage;
            }

            if (playlistId) {
                vars.list = playlistId;
            }

            if (!ECB.youtubePlayers[id]) {
                var videoSettings = {
                    width: width,
                    height: height,
                    videoId: videoId,
                    playerVars: vars,
                    events: {
                        'onReady': onPlayerReady,
                        'onStateChange': onPlayerStateChange
                    }
                };

                ECB.youtubePlayers[id] = new YT.Player('containerId-' + id, videoSettings);
            }

            return ECB.youtubePlayers[id];
        }

        if(!window.onYouTubePlayerAPIReady){
            var waitingYouTubePlayersCopy = ECB.waitingYouTubePlayers.slice();
            window.onYouTubePlayerAPIReady = function () {            
                for(var i = 0; i < waitingYouTubePlayersCopy.length; i++){
                    generateYoutubePlayer(waitingYouTubePlayersCopy[i]);
                }
            };
        }

        function stopVideo() {
            if (ECB.youtubePlayers[id]) ECB.youtubePlayers[id].stopVideo();
        }

        var done = false;
        window.onPlayerStateChange = function (event) {
            if (event.data == YT.PlayerState.PLAYING && !done && autostop) {
                setTimeout(stopVideo, 6000);
                done = true;
            }
        };

        if (typeof (YT) != 'undefined' && YT.Player) {
            
            generateYoutubePlayer(id);
        } else {
            
            var tag = document.createElement('script');
            tag.src = "https://www.youtube.com/player_api";
            var firstScriptTag = document.getElementsByTagName('script')[0]; 
            firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
        }
        }

        

    } else {
        ECB.slow.cookies.addNotWorkingMessage('.video',true);
    }

};


ECB.slow.initYoutubeDivs = function(rootElement){

    rootElement = rootElement || document;

    var videonodes = rootElement.querySelectorAll("[data-video]");

    for(var i = 0; i < videonodes.length; i++){
        var vid = videonodes[i];
        var separator = "---";
        if (i < 10)
            separator += "0";
        separator += i;
        var ytId = vid.getAttribute("data-video");
        if (!vid.classList.contains("loaded")){
            vid.setAttribute("id", ytId+separator);
            vid.classList.add("video") 
            if (!vid.getAttribute("data-image")){
                vid.setAttribute("data-image", "//i.ytimg.com/vi/"+ytId+"/maxresdefault.jpg");
                ECB.fast.loadImages(vid.parentElement);
            }
            if (!vid.querySelector(".icon")) {
                var icon = document.createElement("a");
                icon.setAttribute("class", "overlay play icon -video")
                vid.appendChild(icon);
                icon.addEventListener("click", function(e){
                    e.preventDefault();
                    ECB.loadYouTubeAPI(this, this.parentElement.getAttribute("id"))
                });
            }
            if (!vid.querySelector(".video-container")){
                var videoDiv = document.createElement("div")
                videoDiv.id = "containerId-"+ytId+separator;
                var videoDivWrap = document.createElement("div");
                videoDivWrap.setAttribute("class", "video-container");
                vid.appendChild(videoDivWrap);
                videoDivWrap.appendChild(videoDiv)
            }

            
        } 
    }
}


ECB.slow.alreadyLoaded = [];

ECB.slow.loadLibrariesInChain = function (paths, async, done) {

    

    var chainCall = function (i) {
        if (i == paths.length) {
            if (done && done instanceof Function) {
                done();
            }
        } else {
            if ((paths[i]).endsWith('.css')) {
                ECB.slow.getStylesheet(paths[i], async, function () {
                    chainCall(i + 1)
                });
            } else {
                ECB.slow.getScript(paths[i], async, 'text/javascript', function () {
                    chainCall(i + 1)
                });
            }
        }
    }


    chainCall(0);
}


ECB.slow.loadIfElementExists = function (pattern, loadFunction, rootElement, bypassFunction) {

    rootElement = rootElement || document;
    bypassFunction = bypassFunction || ECB.slow.manageComponents;

    if(ECB.slow.alreadyLoaded.includes(pattern)){
        //add component to list
        bypassFunction(rootElement);
    }

    ECB.slow.alreadyLoaded.push(pattern);
    
    if (rootElement.querySelector(pattern)) {
        loadFunction();
    }

};


ECB.slow.loadScripts = function (rootElement) {

    // ECB.slow.getScript("/shared/dist/js/require/js.cookie-2.2.1.min.js", true, 'text/javascript', function () {
    //     ECB.slow.cookies.init(); 
    // })

    ECB.slow.loadIfElementExists("body.publication-viewer", function () {
        ECB.slow.getScript(ECB.libraryPaths.publicationsPlugin, true, 'text/javascript', ECB.slow.manageComponents);
    },rootElement,ECB.slow.manageComponents);
    
    ECB.slow.loadIfElementExists(".ecb-langSelector", function () {
        ECB.slow.languageVersions();
    },rootElement,ECB.slow.languageVersions);

    ECB.slow.loadIfElementExists('.article-slider, .carousel, .banknotes-slider, .coins', function () {
        // first load CSS and only then js
        ECB.slow.getStylesheet(ECB.stylesheetPaths.flickity, true, function(){
            ECB.slow.getScript(ECB.libraryPaths.flickity, true, 'text/javascript', function () {
                ECB.slow.slider();
            });
        });
        
        
    },rootElement,ECB.slow.slider); //async=false */
    
    ECB.slow.loadIfElementExists('.ecb-map', function () {
        ECB.slow.getScript(ECB.libraryPaths.mapsPlugin, true, 'text/javascript', function () {
            ECB.slow.manageComponents();
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.mapsPlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.bn-denominations-container', function () {
        ECB.slow.getScript(ECB.libraryPaths.banknotesPlugin, true, 'text/javascript', function () {
            ECB.slow.manageComponents();
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.banknotesPlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.bn-security-features', function () {
        ECB.slow.getScript(ECB.libraryPaths.secFeaturesPlugin, true, 'text/javascript', function () {
            ECB.slow.manageComponents();
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.secFeaturesPlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.boxes .coins', function () {
        ECB.slow.getScript(ECB.libraryPaths.coinsPlugin, true, 'text/javascript', function () {
            ECB.slow.manageComponents();
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.coinsPlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.ecb-quiz-wrapper', function () {
        ECB.slow.getScript(ECB.libraryPaths.quizesPlugin, true, 'text/javascript', function () {
            ECB.slow.manageComponents();
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.quizesPlugin, true);
    },rootElement); //async=false */

    var loaded = false;
    ECB.slow.loadIfElementExists('math', function () {
        if (!loaded) {
            ECB.slow.getScript(ECB.libraryPaths.mathjax, true, 'text/javascript', function () {
                ECB.slow.getScript(ECB.libraryPaths.equationsPlugin, true, 'text/javascript', function () {
                    ECB.slow.manageComponents();
                    loaded = true;
                });
            });
            ECB.slow.getStylesheet(ECB.stylesheetPaths.equationsPlugin, true);
        }
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('body.section-home', function () {
        ECB.slow.getScript(ECB.libraryPaths.homePageAutoUpdatePlugin, true, 'text/javascript', function () {
            ECB.slow.manageComponents();
        }); 
    },rootElement);

    ECB.slow.loadIfElementExists('.ecb-lazyload', function () {
        ECB.slow.getScript(ECB.libraryPaths.lazyloadPlugin, true, 'text/javascript', function () {
            ECB.slow.manageComponents();
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.lazyloadPlugin, true);
    },rootElement);

    ECB.slow.loadIfElementExists('.crisis-timeline', function () {
        ECB.slow.getScript(ECB.libraryPaths.crisisTimelinePlugin, true, 'text/javascript', function () {
            ECB.slow.manageComponents();
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.crisisTimelinePlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.timeline-boardmembers', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-1.9.1.min.js", true, 'text/javascript', function () {
            ECB.slow.getScript("/shared/dist/js/require/timeline-board.min.js", true, 'text/javascript', function () {
                ECB.slow.getScript(ECB.libraryPaths.ebTimelinePlugin, true, 'text/javascript', function () {
                    ECB.slow.manageComponents();
                });
            });
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.ebTimelinePlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.ecb-chart', function () {
        ECB.slow.getScript(ECB.libraryPaths.chartsPlugin, true, 'text/javascript', function () {
            ECB.slow.manageComponents();
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.chartsPlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.annual-chart', function () {
        ECB.slow.loadLibrariesInChain(["/shared/dist/js/require/jquery-1.9.1.min.js", "/shared/dist/js/require/xlsx.core.min.js"], true, function () {
            ECB.slow.loadLibrariesInChain(ECB.libraryPaths.amcharts3_16js, true, function () {
                ECB.slow.getScript(ECB.libraryPaths.annualChartPlugin, true, 'text/javascript', function () {
                    ECB.slow.manageComponents();
                    ECB.slow.getScript("/shared/dist/js/require/export_3.16.min.js", true, 'text/javascript', function () {});
                });
            });
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.annualChartPlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.midEASearch', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-3.5.1.min.js", true, 'text/javascript', function () {
            ECB.slow.loadLibrariesInChain(ECB.libraryPaths.midSearchJs, true, function() {
                ECB.slow.getScript(ECB.libraryPaths.midEASearchPlugin, true, 'text/javascript', function () {
                    ECB.slow.manageComponents();
                });
            });
        });
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.midMFISearch', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-3.5.1.min.js", true, 'text/javascript', function () {
            ECB.slow.loadLibrariesInChain(ECB.libraryPaths.midSearchJs, true, function() {
                ECB.slow.getScript(ECB.libraryPaths.midMFISearchPlugin, true, 'text/javascript', function () {
                    ECB.slow.manageComponents();
                });
            });
        });
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.midMFIDSearch', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-3.5.1.min.js", true, 'text/javascript', function () {
            ECB.slow.loadLibrariesInChain(ECB.libraryPaths.midSearchJs, true, function() {
                ECB.slow.getScript(ECB.libraryPaths.midMFIDSearchPlugin, true, 'text/javascript', function () {
                    ECB.slow.manageComponents();
                });
            });
        });
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.annual-balance-chart', function () {
        ECB.slow.loadLibrariesInChain(["/shared/dist/js/require/jquery-1.9.1.min.js"], true, function () {
            ECB.slow.loadLibrariesInChain(ECB.libraryPaths.amcharts3_16js, true, function () {
                ECB.slow.getScript(ECB.libraryPaths.annualBalanceChartPlugin, true, 'text/javascript', function () {
                    ECB.slow.manageComponents();
                    ECB.slow.getScript("/shared/dist/js/require/export_3.16.min.js", true, 'text/javascript', function () {});
                });
            });
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.annualBalanceChartPlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.circulation-chart', function () {
        ECB.slow.loadLibrariesInChain(["/shared/dist/js/require/jquery-1.9.1.min.js"], true, function () {
            ECB.slow.loadLibrariesInChain(ECB.libraryPaths.amcharts_graphjs, true, function () {
                ECB.slow.getScript(ECB.libraryPaths.circulationChartPlugin, true, 'text/javascript', function () {
                    ECB.slow.manageComponents();
                });
            });
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.circulationChartPlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.mpo-chart', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-1.9.1.min.js", true, 'text/javascript', function () {
            ECB.slow.loadLibrariesInChain(ECB.libraryPaths.amcharts3_16js, true, function () {
                ECB.slow.getScript(ECB.libraryPaths.mpoChartPlugin, true, 'text/javascript', function () {
                    ECB.slow.manageComponents();
                    ECB.slow.getScript("/shared/dist/js/require/export_3.16.min.js", true, 'text/javascript', function () {});
                });
            });
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.mpoChartPlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.eer-chart', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-1.9.1.min.js", true, 'text/javascript', function () {
            ECB.slow.loadLibrariesInChain(ECB.libraryPaths.amcharts3_16js, true, function () {
                ECB.slow.getScript(ECB.libraryPaths.eerChartPlugin, true, 'text/javascript', function () {
                    ECB.slow.manageComponents();
                });
            });
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.eerChartPlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.eayc-chart', function () {
        ECB.slow.loadLibrariesInChain(["/shared/dist/js/require/jquery-1.9.1.min.js", "/shared/dist/js/require/jquery.ui.js", "/shared/dist/js/require/jquery-ui.multidatespicker.js"], true, function () {
            ECB.slow.loadLibrariesInChain(ECB.libraryPaths.amcharts3_16js, true, function () {
                ECB.slow.getScript(ECB.libraryPaths.eaycChartPlugin, true, 'text/javascript', function () {
                    ECB.slow.manageComponents();
                });
            });
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.eaycChartPlugin, true);
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('#electro-paym-chart', function () {
        ECB.slow.loadLibrariesInChain( ["/shared/dist/js/require/jquery-3.5.1.min.js", "/shared/dist/js/require/amcharts_amc_graph.js", "/shared/dist/js/require/serial_amc_graph.js", "/shared/dist/js/require/export_amc_graph.min.js"], true, function () {
            ECB.slow.getScript(ECB.libraryPaths.electroPaymChartPlugin, true, 'text/javascript', function () {
                ECB.slow.manageComponents();
            });
        });
    },rootElement); //async=false */

    ECB.slow.loadIfElementExists('.fxrates-chart', function () {
        ECB.slow.getScript("/shared/dist/js/require/amcharts.min.js", true, 'text/javascript', function () {
            ECB.slow.getScript("/shared/dist/js/require/serial.js", true, 'text/javascript', function () {
            ECB.slow.getScript("/shared/dist/js/require/amstock.min.js", true, 'text/javascript', function () {                
                    ECB.slow.getScript("/shared/dist/js/require/amexport.min.js", true, 'text/javascript', ECB.slow.amChart);
                });
            });
        });
        ECB.slow.getStylesheet("/shared/dist/css/require/chart.css", true);
    },rootElement,ECB.slow.amChart); //async=false */

    ECB.slow.loadIfElementExists('.interactive-table', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-1.9.1.min.js", true, 'text/javascript', function () {
            ECB.slow.getScript("/shared/dist/js/require/jquery.ba-throttle-debounce.min.js", true, 'text/javascript', function () {
                ECB.slow.cookies.init();
                ECB.slow.interactiveTable();
            });
        });
    },rootElement,ECB.slow.interactiveTable);

    ECB.slow.loadIfElementExists('.cashhand-devices-search', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-1.9.1.min.js", true, 'text/javascript', ECB.slow.bahamaDevices);
    },rootElement,ECB.slow.bahamaDevices);

    ECB.slow.loadIfElementExists('.cashhand-recycling-search', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-1.9.1.min.js", true, 'text/javascript', ECB.slow.bahamaRecycling);
    },rootElement,ECB.slow.bahamaRecycling);

    ECB.slow.loadIfElementExists('.sst-wrapper', function () {
        ECB.slow.getScript(ECB.libraryPaths.scrollStoryPlugin, true, 'text/javascript', function () {
            ECB.slow.manageComponents();
        });
        ECB.slow.getStylesheet(ECB.stylesheetPaths.scrollStoryPlugin, true);
    },rootElement);

    ECB.slow.loadIfElementExists('#fiscalDashboard', function () {
        ECB.slow.loadLibrariesInChain(["/shared/dist/js/require/jquery-1.9.1.min.js", "/shared/dist/js/require/jquery.flash.js", "/shared/dist/js/require/md5.js"], true, ECB.slow.dashboardFlash);
    },rootElement, ECB.slow.dashboardFlash);

    ECB.slow.loadIfElementExists('#sortable_table', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-1.9.1.min.js", true, 'text/javascript', function () {
            ECB.slow.getScript("/shared/dist/js/require/jquery.tablesorter.js", true, 'text/javascript', ECB.slow.sortableTable);
        });
    },rootElement,ECB.slow.sortableTable);

    ECB.slow.loadIfElementExists('.date_picker_holder', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-1.9.1.min.js", true, 'text/javascript', function () {
            ECB.slow.getScript("/shared/dist/js/require/jquery.ui.js", true, 'text/javascript', function () {
                ECB.slow.getScript("/shared/dist/js/require/jquery-ui.multidatespicker.js", true, 'text/javascript', function () {
                    ECB.slow.getScript("/shared/dist/js/require/jsZip.min.js", true, 'text/javascript', ECB.slow.eligibleAssets);
                });
            });
        });
        ECB.slow.getStylesheet("/shared/dist/css/require/datepicker.css", true);
    },rootElement,ECB.slow.eligibleAssets);
    
    ECB.slow.loadIfElementExists('.forextable', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-1.9.1.min.js", true, 'text/javascript', function () {
            ECB.slow.getScript("/shared/dist/js/require/jquery.tablesorter.js", true, 'text/javascript', ECB.slow.efxrateSortableTable);
        });
    },rootElement,ECB.slow.efxrateSortableTable)

    ECB.slow.loadIfElementExists('.omosorttable', function () {
        ECB.slow.getScript("/shared/dist/js/require/jquery-1.9.1.min.js", true, 'text/javascript', function () {
            ECB.slow.getScript("/shared/dist/js/require/jquery.tablesorter.js", true, 'text/javascript', ECB.slow.omoSortableTable);
        });
    },rootElement,ECB.slow.omoSortableTable)
};
//helper functions
(function () {
    var allFunctions = function () {
        ECB.slow.breakpoints();
        ECB.slow.settings();

        ECB.slow.cookies.init();        
        ECB.slow.menu.init();
        ECB.slow.feedback();

        ECB.slow.searchButton();
        ECB.slow.breadcrumbs();
        ECB.slow.scroll();
        ECB.slow.tabs();
        ECB.slow.accordion();
        ECB.slow.sharing();
        ECB.slow.tableResize(); 
        ECB.slow.languageSelect(); // cookie plugin dependency
        ECB.slow.sitedir();
        ECB.slow.footnotes();
        ECB.slow.asyncContent();
        ECB.slow.table();
        ECB.slow.homepageBadge();
        ECB.slow.filter();
        ECB.slow.teaserLinks();
        ECB.slow.initYoutubeDivs();
        ECB.slow.initSoundcloud(); 

        ECB.slow.loadScripts();

        ECB.slow.addSearchApi.init();
        ECB.slow.analytics(); 


        ECB.slow.additional();

        ECB.slow.preferredLanguageCheck();
        ECB.slow.imgFilter();
        
        ECB.slow.hideCookieMessage();

    }
    
    if(ECB.slow.blockExecution){
        return;
    }

    if (document.readyState === "loading") {
        window.addEventListener('DOMContentLoaded', allFunctions);
    } else {
        
        allFunctions();
    }

})();
