package utilities;

import java.io.FileInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {

	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFCell Cell;
	private static XSSFRow Row;

	//This method is to set the File path and to open the Excel file, Pass Excel Path and Sheetname as Arguments to this method
	
	public ExcelUtils(String Path,String SheetName)   
	{	
	   try 
	   {	
		   //System.out.println("hi constructort");
			// Open the Excel file	
			FileInputStream ExcelFile = new FileInputStream(Path);	
			
			// Access the required test data sheet	
			ExcelWBook = new XSSFWorkbook(ExcelFile);	
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			XSSFRow row = ExcelWSheet.getRow(0);

		}catch (Exception e)
	   	{	
				
		}
	}
	
	
	public static void setExcelFile(String Path,String SheetName) throws Exception 
	{	
	   try 
	   {	
			// Open the Excel file	
			FileInputStream ExcelFile = new FileInputStream(Path);	
			
			// Access the required test data sheet	
			ExcelWBook = new XSSFWorkbook(ExcelFile);	
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			XSSFRow row = ExcelWSheet.getRow(0);

		}catch (Exception e)
	   	{	
			throw (e);	
		}
	}
	
	public static Object[][] getTableArray(String FilePath, String SheetName) throws Exception	
	{		
	   String[][] tabArray = null;	
	   try
	   {	
		   FileInputStream ExcelFile = new FileInputStream(FilePath);
	
		   // Access the required test data sheet	
		   ExcelWBook = new XSSFWorkbook(ExcelFile);	
		   ExcelWSheet = ExcelWBook.getSheet(SheetName);
	
		   int totalRows = ExcelWSheet.getLastRowNum();	
		   int totalCols = ExcelWSheet.getRow(0).getLastCellNum();
		   
	
		   
		   
		   tabArray=new String[totalRows][totalCols];	
		   for (int i=1;i<=totalRows;i++)
		   {
			   for (int j=0;j<totalCols;j++)
			   {
				  tabArray[i-1][j]=getCellData(i,j);
				 // System.out.print(getCellData(i,j) + " ---");
			   }	
		   }

		}
	   
	
		catch (FileNotFoundException e)	
		{	
			System.out.println("Could not read the Excel sheet");	
			e.printStackTrace();	
		}
	
		catch (IOException e)	
		{	
			System.out.println("Could not read the Excel sheet");	
			e.printStackTrace();	
		}
		return(tabArray);	

	
	}
	
	//This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num	
	public static String getCellData(int RowNum, int ColNum) throws Exception{	
	   try{	
		  Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);	
		  String CellData = Cell.toString();	
		  return CellData;	
		  }catch (Exception e){	
			return"";	
		  }	
	}	
	


}
