package managers;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

import enums.DriverType;

public class WebDriverManager {
	private  WebDriver driver;
	//private WebDriverWait wait;
	private DriverType driverType;
	
	 public WebDriverManager() {

			driverType = FileReaderManager.getInstance().getConfigReader().getBrowser();
	 }
	 
	 public WebDriver getDriver() {
		 if(driver == null) driver = createLocalDriver();
		 return driver;
	 }
	
	 /*
	 public WebDriverWait getDriverWait() {
		 return wait;
	 }*/
	 
	 // when the tests would run using only one browser this methods from public should be private
	private WebDriver createLocalDriver(){
		
		System.out.println(" ------ CreateLocalDriver = " + driverType );
	 	switch (driverType) {     
	        	case FIREFOX : 
	        	
	        		try {
	        			
	        			System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+"\\Drivers\\geckodriver.exe");
	        			FirefoxOptions options = new FirefoxOptions();
	        			options.setProfile(FirefoxDriverProfile());
	        			driver = new FirefoxDriver(options);
	        		} catch (Exception e) {				
	        			e.printStackTrace();
	        		} 	        	
	        	
	        		break;
	        		
	        	case CHROME : 
	        		
	        		System.out.println("---------------------------- Chrome Driver ......");

	        		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\Drivers\\chromedriver.exe");
	        		
	        		String downloadFilepath = System.getProperty("user.dir") + "\\DownloadFolder";
	        		//String downloadFilepath =  System.getProperty("user.dir")+"\\DownloadFolder";
	        		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
	        		chromePrefs.put("profile.default_content_settings.popups", 2);
	        	
	        		chromePrefs.put("download.default_directory", downloadFilepath);
	        		chromePrefs.put("plugins.always_open_pdf_externally", true);
	        		ChromeOptions options = new ChromeOptions();
	        	//	options.addArguments("-incognito");
	        	//    options.addArguments("--disable-popup-blocking");
	        		options.setExperimentalOption("prefs", chromePrefs);
	        	//	options.addArguments("--headless");  // run in headless mode chrome
	        		//DesiredCapabilities cap = DesiredCapabilities.chrome();
	        		//cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	        		//cap.setCapability(ChromeOptions.CAPABILITY, options);
	        		driver = new ChromeDriver(options);
	         	      		
	        		break;
	        	
	        	case INTERNETEXPLORER : 
	        		
	        		System.out.println("---------------------------- INTERNET EXPLORER ......");
	        		System.setProperty("webdriver.ie.driver",System.getProperty("user.dir")+"\\Drivers\\IEDriverServer.exe");

	        	/*DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
	        	capabilities.setCapability(InternetExplorerDriver.FORCE_CREATE_PROCESS, true);
	        	capabilities.setCapability(InternetExplorerDriver.IE_SWITCHES, "-private");
	        	WebDriver driver = new InternetExplorerDriver(capabilities);*/
	        		 driver = new InternetExplorerDriver();
                			
        				
	        		break;
	        }
	 
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(FileReaderManager.getInstance().getConfigReader().getImplicitlyWait(), TimeUnit.SECONDS);
	      //  wait = new WebDriverWait(driver,15);

	        return driver;
	 } 
 
	 
	 
	 public void closeDriver() {
		 driver.close();
		 driver.quit();
	 }
	 
	 
	// function to set up the user firefox profile
			 private static FirefoxProfile FirefoxDriverProfile() throws Exception {
			        FirefoxProfile profile = new FirefoxProfile();
			        profile.setPreference("browser.download.folderList", 2);
			        profile.setPreference("browser.download.manager.showWhenStarting", false);
			        profile.setPreference("browser.download.dir", System.getProperty("user.dir")+"\\DownloadFolder");
			        profile.setPreference("browser.helperApps.neverAsk.openFile",
			                    "text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml,text/xml");
			        profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
			"text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml,text/xml");
			        profile.setPreference("browser.helperApps.alwaysAsk.force", false);
			        profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
			        profile.setPreference("browser.download.manager.focusWhenStarting", false);
			        profile.setPreference("browser.download.manager.useWindow", false);
			        profile.setPreference("browser.download.manager.showAlertOnComplete", false);
			        profile.setPreference("browser.download.manager.closeWhenDone", false);	     
			        return profile;
			  }
			
			
	 
}