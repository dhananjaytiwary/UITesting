package context;

import org.aeonbits.owner.ConfigFactory;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Protocol;
import com.aventstack.extentreports.reporter.configuration.Theme;

import providers.Environment;
import utilities.PropertyReader;


/*
 * This BaseTest Class is used in order as a basis
 * for the extend report.
 * Each test case should extend this class
 * */

public class BaseTest {
	
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest test;


	@BeforeSuite
	public void setUp()
	{
		htmlReporter = new ExtentHtmlReporter("Regression_TestReport.html");
	
	//	htmlReporter.config().setAutoCreateRelativePathMedia(true);
	//	htmlReporter.config().setCSS("css-string");
		htmlReporter.config().setDocumentTitle("XXX Regression Test"); //page title
		
	//	htmlReporter.config().setEncoding("utf-8");
	//	htmlReporter.config().setJS("js-string");
	//	htmlReporter.config().setProtocol(Protocol.HTTPS);
		htmlReporter.config().setReportName("XXX Regression Test");
		htmlReporter.config().setTheme(Theme.DARK);
	//	htmlReporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss")
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
	}
	
	
	
	
	@AfterMethod
	public void getResult(ITestResult result,ITestContext context)
	{
		String testre =  (String) context.getAttribute("testpf");
		System.out.println("testre:"+testre);
		if(testre=="FAIL")
		{
			result.setStatus(ITestResult.FAILURE);
		}	
		if(result.getStatus()==ITestResult.FAILURE){
			test.fail(MarkupHelper.createLabel(result.getName() + " Test case Failed", ExtentColor.RED));
		}
		else if (result.getStatus()==ITestResult.SUCCESS){
			test.pass(MarkupHelper.createLabel(result.getName() + " Test case Passed", ExtentColor.GREEN));
		}
		else {
			test.skip(MarkupHelper.createLabel(result.getName() + " Test case Passed", ExtentColor.YELLOW));
		}
	}
/*	public void getResult(ITestResult result)
	{
	
		if(result.getStatus()==ITestResult.FAILURE){
			test.fail(MarkupHelper.createLabel(result.getName() + " Test case Failed", ExtentColor.RED));
		}
		else if (result.getStatus()==ITestResult.SUCCESS){
			test.pass(MarkupHelper.createLabel(result.getName() + " Test case Passed", ExtentColor.GREEN));
		}
		else {
			test.skip(MarkupHelper.createLabel(result.getName() + " Test case Passed", ExtentColor.YELLOW));
		}
	}
	*/

	
	@AfterSuite
	public void tearDown()
	{
		extent.flush();	
	}
	
	

	
}
