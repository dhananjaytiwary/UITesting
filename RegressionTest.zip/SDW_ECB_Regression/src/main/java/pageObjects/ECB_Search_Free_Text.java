package pageObjects;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
//import java.awt.Color;
import java.util.StringTokenizer;

import org.apache.poi.hssf.record.PageBreakRecord.Break;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import managers.FileReaderManager;
import utilities.CommonFunctions;
import utilities.PropertyReader;
import utilities.Screenshots;
public class ECB_Search_Free_Text {
	Screenshots objCreateScreenshot = new Screenshots();
	CommonFunctions com = new CommonFunctions();
	//PropertyReader CenterPage=new PropertyReader("src/main/java/pageObjects/SDW_CenterPage.properties");
	 String fieldvalue1="";
	 String TestStatus="PASS";
	 WebElement TabName =null;
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();

	 public String ECB_HomePage_SerachText(WebDriver driver,String Step2, ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
			//	String TestStatus;
				driver.get(ApplicaitonUrl);
				 
				 test.log(Status.PASS, "Open ECB Portal Home page");
				 Thread.sleep(4000);			 
						//Select radio button All selected data type series in the search box on the top of the page and set text as Orange Purple and Click on search button
				 driver.findElement(By.xpath("//*[@id='selected_series' and @value='3']")).click();
				 test.log(Status.PASS, "Select radio button All selected data type series in the search box on the top of the page");
				 
				 driver.findElement(By.xpath("//*[@id='q']")).sendKeys(Step2);
		
				 driver.findElement(By.xpath("//*[@id='intMainSearch']/div[1]/input[2]")).click();
				 test.log(Status.PASS, "set text as 'Orange Purple' and Click on search button");
				Thread.sleep(4000);
								
				if (driver.findElement(By.xpath("//*[@id='q' and @value='Orange Purple']")).isDisplayed()) {
					test.log(Status.PASS, "SDW Search text box still shows Orange Purple Text");
					
				}else{
					test.log(Status.FAIL, "SDW Search text box NOT shows Orange Purple Text");
					TestStatus= "FAIL";
				}
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "ECB_HomePage_SerachText", test, date1));	
							   
				return TestStatus;
						
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, "verify ECB Portal Home page Test FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}
 	 
	public String Available_Dataset(WebDriver driver, String Step9,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			//String TestStatus;
		//	driver.get(url);
			 
			 
			Thread.sleep(2000);
			
			ArrayList aList= new ArrayList(Arrays.asList(Step9.split(",")));
			
				 
			if (driver.getPageSource().contains("Available Datasets (2)")) {
				test.log(Status.PASS, "Available Datasets (2)  is available");
				
			}else{
				test.log(Status.FAIL, "Available Datasets (2)  is NOT available");
				TestStatus= "FAIL";
			}
			
			//Check if in available datasets in col 2 contains DD_TST and EXR_TST are available

			String str1=driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[2]")).getText();
			String str2=driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[2]/td[2]")).getText();
	
			if(str1.contains((String) aList.get(0)) && str2.contains((String) aList.get(1))){
				test.log(Status.PASS, "In Available Datasets table in col 2 contains DD_TST : Test Derived Data and EXR_TST : Exchange Rates Test are available");
			}else{
				test.log(Status.FAIL, "In Available Datasets table in col 2 contains DD_TST : Test Derived Data and EXR_TST : Exchange Rates Test are NOT available");
				TestStatus= "FAIL";
			}
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Available_Dataset", test, date1));
			return TestStatus;
			
	
			
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "verify Dataset_series:  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	public String SearchReference_series(WebDriver driver, String Step4,String Step5,String Step6,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
		//	String TestStatus="";
		//	driver.get(url);
			
			System.out.println("url=============ECB_Browser_Node===================      ");
			
	
			String str =Step4;
			ArrayList aList= new ArrayList(Arrays.asList(str.split(",")));
			
			Thread.sleep(2000);
			//In the reference series checkbox is not selected in row 2 col 1
			 WebElement webElement=driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input"));
		        if (webElement.isSelected()){
		        	 test.log(Status.FAIL, " Verified reference series checkbox is selected in row 2 column 1 ");
		        }else{
		        	test.log(Status.PASS, " Verified reference series checkbox is not selected in row 2 column 1 ");
		        }	
		  
		  //reference series in row 2 all column should be background color = #99ccff      
		    for(int i=1;i<8;i++){    
		        
		     String color = driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td["+i+"]")).getCssValue("background-color");
			 String bckgclr = com.HexColor(color);
			 String bgcolor=(String) aList.get(0);
		        
		 
			if (bckgclr.equalsIgnoreCase(bgcolor)) {
				test.log(Status.PASS, "reference series table row 2 columns "+ i +" background color:  PASS ");
				
			}else{
				test.log(Status.FAIL, "Expecting BGColor:  '" +bgcolor + "'  However found :  '" + bckgclr +"'");
				TestStatus= "FAIL";
				break;
			}
		   }
		        
		    JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("window.scrollBy(0,700)");
			
	//In the reference series link DD_TST.B.AT.IR_L.AVG.RT is present  in row 2 col 2
		  
		    String row2col2= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[2]/a/span")).getText();
	//	    System.out.println("=========================== " +row2col2);
		    String row2link2=(String) aList.get(1);
		//    System.out.println("=========================== " +row2link2);
		   
		    if (row2col2.equalsIgnoreCase(row2link2)){   //DD_TST.B.AT.IR_L.AVG.RT
		    	test.log(Status.PASS, "reference series Text DD_TST.B.AT.IR_L.AVG.RT is present in row 2 col 2 ");
		    	WebElement linkName=driver.findElement(By.linkText(row2col2));
		    	
		    	if(linkName.isDisplayed())
		    	{
		    		test.log(Status.PASS, "reference series Link DD_TST.B.AT.IR_L.AVG.RT is present ");
		    		
		    	}
		    	else
		    	{
		    		test.log(Status.FAIL, "reference series Link DD_TST.B.AT.IR_L.AVG.RT is not present ");
		    		TestStatus= "FAIL";
		    	}
		    	
		    }else{
		    	test.log(Status.FAIL, "reference series Text DD_TST.B.AT.IR_L.AVG.RT is NOT present  in row 2 col 2 ");
	    		TestStatus= "FAIL";
		    }
		    
		    //In the reference series text DD_TST.B.AT.IR_L.AVG.RT and series on SDW Public link is present  in row 2 col 4
		    WebElement text= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[4]"));
		    String row2col4=text.getText();
		    
	//	    System.out.println("=========================== " +row2col4);
		    String row2link4=(String) aList.get(2);
	//	    System.out.println("=========================== " +row2link4);
		   
		    if (row2col4.contains(row2col4)){   //DD_TST.B.AT.IR_L.AVG.RT
		    	test.log(Status.PASS, "reference series Text DD_TST.B.AT.IR_L.AVG.RT is present  in row 2 col 4 ");
		    	WebElement linkName=driver.findElement(By.linkText(row2link4));
		    	
		    	if(linkName.isDisplayed())
		    	{
		    		test.log(Status.PASS, "series on SDW Public link is present  in row 2 col 4 ");
		    		
		    	}
		    	else
		    	{
		    		test.log(Status.FAIL, "series on SDW Public link is present  in row 2 col 4");
		    		TestStatus= "FAIL";
		    	}
		    	
		    }else{
		    	test.log(Status.FAIL, "reference series Text DD_TST.B.AT.IR_L.AVG.RT is NOT present  in row 2 col 4 ");
	    		TestStatus= "FAIL";
		    }
		    
		    //In the reference series value "02 Jan 1986" is present  in row 2 col 5
		    
		    String row2col5= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[5]")).getText();
		    String row2date5=(String) aList.get(3);
				   
		    if (row2col5.equalsIgnoreCase(row2date5)){  
		    	test.log(Status.PASS, "reference series value 02 Jan 1986 is present  in row 2 col 5 ");
		    				    			    	
		    }else{
		    	test.log(Status.FAIL, "reference series value 02 Jan 1986 is NOT present  in row 2 col 5 ");
	    		TestStatus= "FAIL";
		    }
		    
		    //In the reference series value "06 Dec 2016" is present  in row 2 col 6
		    String row2col6= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[6]")).getText();
		    String row2date6=(String) aList.get(4);
			   
		    if (row2col6.equalsIgnoreCase(row2date6)){   
		    	test.log(Status.PASS, "reference series value 06 Dec 2016 is present  in row 2 col 6 ");
		    				    			    	
		    }else{
		    	test.log(Status.FAIL, "reference series value 06 Dec 2016 is NOT present  in row 2 col 6 ");
	    		TestStatus= "FAIL";
		    }
		    
		 //=======================Test Step 5========Published Series===================
			String str4 =Step5;
			ArrayList aList4= new ArrayList(Arrays.asList(str4.split(",")));
			
			//In the Published series checkbox is not selected in row 3 col 1
			 WebElement webElement1=driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input"));
		        if (webElement1.isSelected()){
		        	 test.log(Status.FAIL, " Verified Published series checkbox is selected in row 3 column 1 ");
		        }else{
		        	test.log(Status.PASS, " Verified Published series checkbox is not selected in row 3 column 1 ");
		        }	
		  
		  //Published series in row 2 all column should be background color = #99ccff      
		    for(int i=1;i<8;i++){    
		        
		     String color = driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td["+i+"]")).getCssValue("background-color");
			 String bckgclr = com.HexColor(color);
			 String bgcolor=(String) aList4.get(0);
		        
		 
			if (bckgclr.equalsIgnoreCase(bgcolor)) {
				test.log(Status.PASS, "Published series table row 3 columns "+ i +" background color:  PASS ");
				
			}else{
				test.log(Status.FAIL, "Expecting BGColor:  '" +bgcolor + "'  However found :  '" + bckgclr +"'");
				TestStatus= "FAIL";
				break;
			}
		   }
		        
		 //In the Published series link DD_TST.B.AT.IR_L.AVG.RT is present  in row 2 col 2
		  
		    String row3col2= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[2]/a/span")).getText();
		  
		    String row3link2=(String) aList4.get(1);
	
		   
		    if (row3col2.equalsIgnoreCase(row3link2)){   //DD_TST.B.AT.IR_L.AVG.RT
		    	test.log(Status.PASS, "Published series Text DD_TST.B.D2.IR_S.AVG.4F5B is present  in row 3 col 2 ");
		    	WebElement linkName=driver.findElement(By.linkText(row3col2));
		    	
		    	if(linkName.isDisplayed())
		    	{
		    		test.log(Status.PASS, "Published series Link DD_TST.B.D2.IR_S.AVG.4F5B is present ");
		    		
		    	}
		    	else
		    	{
		    		test.log(Status.FAIL, "Published series Link DD_TST.B.D2.IR_S.AVG.4F5B is not present ");
		    		TestStatus= "FAIL";
		    	}
		    	
		    }else{
		    	test.log(Status.FAIL, "Published series Text DD_TST.B.D2.IR_S.AVG.4F5B is NOT present  in row 3 col 2 ");
	    		TestStatus= "FAIL";
		    }
		    
		    //row 3 col 4  -  BGColor  #cce6ff - value exists DD_TST.B.D2.IR_S.AVG.4F5B
		    WebElement text4= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[4]"));
		    String row3col4=text4.getText();
		    
		 
		    String row3link4=(String) aList4.get(2);

		   
		    if (row3col4.contains(row3link4)){ 
		    	test.log(Status.PASS, "Published series Text DD_TST.B.D2.IR_S.AVG.4F5B is present  in row 3 col 4 ");
		    				    	
		    }else{
		    	test.log(Status.FAIL, "Published series Text DD_TST.B.D2.IR_S.AVG.4F5B is NOT present  in row 3 col 4 ");
	    		TestStatus= "FAIL";
		    }
		    
		    //row 3 col 5 -  BGColor  #cce6ff - value exists "04 Jan 1989"
		    
		    String row3col5= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[5]")).getText();
		   // System.out.println("=========================== " +row3col5);
		    String row3date5=(String) aList4.get(3);
		   // System.out.println("=========================== " +row3date5);
		   
		    if (row3col5.equalsIgnoreCase(row3date5)){  
		    	test.log(Status.PASS, "Published series value 04 Jan 1989 is present  in row 3 col 5 ");
		    				    			    	
		    }else{
		    	test.log(Status.FAIL, "Published series value 04 Jan 1989 is NOT present  in row 3 col 5 ");
	    		TestStatus= "FAIL";
		    }
		    
		    //In the Published series value "06 Dec 2016" is present  in row 2 col 6
		    String row3col6= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[6]")).getText();
	
		    String row3date6=(String) aList4.get(4);
	
		   
		    if (row3col6.equalsIgnoreCase(row3date6)){   
		    	test.log(Status.PASS, "Published series value 06 Dec 2016 is present  in row 3 col 6 ");
		    				    			    	
		    }else{
		    	test.log(Status.FAIL, "Published series value 06 Dec 2016 is NOT present  in row 3 col 6 ");
	    		TestStatus= "FAIL";
		    }
		    
		    
		    //=======================Test Step 6============Other Series===============    
			String str6 =Step6;
			ArrayList aList6= new ArrayList(Arrays.asList(str6.split(",")));
			
			//In the Other series checkbox is not selected in row 3 col 1
			 WebElement webElement6=driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input"));
		        if (webElement6.isSelected()){
		        	 test.log(Status.FAIL, " Verified Other series checkbox is selected in row 4 column 1 ");
		        }else{
		        	test.log(Status.PASS, " Verified Other series checkbox is not selected in row 4 column 1 ");
		        }	
		  
		  //Other series in row 3 all column should be background color =    
		    for(int i=1;i<8;i++){    
		        
		     String color = driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td["+i+"]")).getCssValue("background-color");
			 String bckgclr = com.HexColor(color);
			 String bgcolor=(String) aList6.get(0);
		        
		 
			if (bckgclr.equalsIgnoreCase(bgcolor)) {
				test.log(Status.PASS, "Other series table row 4 columns "+ i +" background color:  PASS ");
				
			}else{
				test.log(Status.FAIL, "Expecting BGColor:  '" +bgcolor + "'  However found :  '" + bckgclr +"'");
				TestStatus= "FAIL";
				break;
			}
		   }
		        
		 //In the Other series link DD_TST.B.AT.IR_L.AVG.RT is present  in row 2 col 2
		  //*[@id="seriesListTable"]/tbody/tr[3]/td[2]/b
		  //  String row4col2= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td[2]/a/span")).getText();
		    String row4col2= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td[2]/b")).getText();
		    String row4link2=(String) aList6.get(1);
		
		   
		    if (row4col2.contains(row4link2)){   
		    	test.log(Status.PASS, "Other series Text '"+ row4col2 +"' is present  in row 4 col 2 ");
		
		    }else
		    	{
		    		test.log(Status.FAIL, "Other series Text '"+ row4col2 +"' is NOT present  in row 4 col 2 ");
		    		TestStatus= "FAIL";
		    	}
		
		    //row 3 col 4  -  BGColor  #cce6ff - value exists DD_TST.B.D2.IR_S.AVG.4F5B
		    WebElement text6= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td[4]"));
		    String row4col4=text6.getText();
		 
		    String row4link4=(String) aList6.get(2);
		   // System.out.println("=========================== " +row3link4);
		   
		    if (row4col4.contains(row4link4)){ 
		    	test.log(Status.PASS, "Other series Text '"+ row4col4 + "' is present  in row 4 col 4 ");
		    				    	
		    }else{
		    	test.log(Status.FAIL, "Other series Text '"+ row4col4 + "' is NOT present  in row 4 col 4  ");
	    		TestStatus= "FAIL";
		    }
		    
		    //row 3 col 5 -  BGColor  #cce6ff - value exists "04 Jan 1989"
		    
		    String row4col5= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td[5]")).getText();
	
		    String row4date5=(String) aList6.get(3);
				   
		    if (row4col5.equalsIgnoreCase(row4date5)){  
		    	test.log(Status.PASS, "Other series value '"+ row4col5 +"' is present  in row 4 col 5 ");
		    				    			    	
		    }else{
		    	test.log(Status.FAIL, "Other series value '"+ row4col5 +"' is NOT present  in row 4 col 5 ");
	    		TestStatus= "FAIL";
		    }
		    
		    //In the Other series value "06 Dec 2016" is present  in row 2 col 6
		    String row4col6= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td[6]")).getText();
		    String row4date6=(String) aList6.get(4);
	   
		    if (row4col6.equalsIgnoreCase(row4date6)){   
		    	test.log(Status.PASS, "Other series value '"+ row4col6 +"' is present  in row 4 col 6 ");
		    				    			    	
		    }else{
		    	test.log(Status.FAIL, "Other series value '"+ row4col6 +"' is present  in row 4 col 6");
	    		TestStatus= "FAIL";
		    }
		    test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "SearchReference_series", test, date1));
		    //=======================TEST STEP 7
		return TestStatus;	
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "verify reference_series :  FAIL ");
		
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	
	public String SearchfreeText_Data_Table(WebDriver driver,String Step5,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			
			//driver.get(url);
			//test.log(Status.INFO, "Login to ECB portal and goto node=9701956");
		//	String TestStatus="PASS";
			ArrayList aList= new ArrayList(Arrays.asList(Step5.split(",")));
		String Step5_1=(String) aList.get(0);
		String Step5_2=(String) aList.get(1);
		String Step5_3=(String) aList.get(2);
		String Step5_4=(String) aList.get(3);
		String Step5_5=(String) aList.get(4);
		
			
	  //	 test.log(Status.INFO, "select the check boxes for the first 2 series in the series table");
	  	JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,500)");
		
		 		
		 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input")).click();
		 Thread.sleep(1000);
		 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input")).click();
	//	 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		 Thread.sleep(3000); 
		
		 test.log(Status.PASS, "Select check boxes for the first 2 series in the series table");
						
		//---------------------
				WebElement element = driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[3]/a"));
				Actions actions = new Actions(driver);
				actions.moveToElement(element).click().perform();
				 test.log(Status.PASS, "Click the link Data Table on the top links section");
				
				// js.executeScript("window.scrollBy(0,600)");
				 Thread.sleep(3000);  
			 String str1=driver.findElement(By.xpath("//*[@id='dataTableID']/thead/tr/th[2]/span/small")).getText();
			 String str2=driver.findElement(By.xpath("//*[@id='dataTableID']/thead/tr/th[3]/span/small")).getText();
			
			 if(Step5_1.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/thead/tr/th[2]/span/small")).getText())){
				 //DD_TST.B.AT.IR_L.AVG.RT series is shown in row 1 col 2
				 test.log(Status.PASS, Step5_1 + " series is shown in row 1 col 2");
				// 
			 }else{
				 test.log(Status.FAIL, Step5_1 + " series NOt shown in row 1 col 2");
				 TestStatus= "FAIL";
			 } 
	//		 test.log(Status.INFO, "Check in the web table serch in 2 row data should contain"); 
			 if(Step5_2.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/thead/tr/th[3]/span/small")).getText())){
				 //DD_TST.B.AT.IR_L.AVG.RT series is shown in row 1 col 2
				 test.log(Status.PASS, Step5_2 + " series is shown in row 1 col 2");
				 // 
			 }else{
				 test.log(Status.FAIL, Step5_2 + " series NOt shown in row 1 col 3");
				 TestStatus= "FAIL";
			 }
				
			
					 if(Step5_3.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[3]/td[1]")).getText())){
						 test.log(Status.PASS, " 2016-12-05 value fond in series table in row 2 col 1");
						 // 
					 }else{
						 test.log(Status.FAIL, " 2016-12-05 value NOT fond in series table in row 2 col 1");// 
						 TestStatus= "FAIL";
					 }
					 if(Step5_4.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[3]/td[2]")).getText())){
						 test.log(Status.PASS, " 0.580000000000000 value fond in series table in row 2 col 2");
						 //
					 }else{
						 test.log(Status.FAIL, " 0.580000000000000 value NOT fond in series table in row 2 col 2");
						 TestStatus= "FAIL";
					 }
					 if(Step5_5.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[3]/td[3]")).getText())){
						 test.log(Status.PASS, " 1.512210965156555 value fond in series table in row 2 col 3");
						 // 
					 }else{
						 test.log(Status.FAIL, " 1.512210965156555 value NOT fond in series table in row 2 col 3");
						 TestStatus= "FAIL";
					 }
							 
					 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "SearchfreeText_Data_Table", test, date1));
					 
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "verify Backgroup color Not Matched :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	public String SearchfreeText_Range(WebDriver driver, String Step5,String Step7,String Step9,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			
		
			//driver.get(url);
			//test.log(Status.INFO, "Login to ECB portal and goto node=9701956");
		//	String TestStatus="PASS";
	System.out.println("I am in SearchfreeText_Range=======================");
		
		ArrayList aList5= new ArrayList(Arrays.asList(Step5.split(",")));
			
		ArrayList aList7= new ArrayList(Arrays.asList(Step7.split(",")));
		String Step7_1=(String) aList7.get(0);
		String Step7_2=(String) aList7.get(1);
		String Step7_3=(String) aList7.get(2);
	//	System.out.println("111111111111111111");
		ArrayList aList9= new ArrayList(Arrays.asList(Step9.split(",")));
		String Step9_1=(String) aList9.get(0);
		String Step9_2=(String) aList9.get(1);
		String Step9_3=(String) aList9.get(2);
		//System.out.println("2222222222222222222222");	 
				 Thread.sleep(2000); 
					 String fromdate=(String) aList5.get(0);
					 String todate=(String) aList5.get(1);
					 System.out.println("==========================1========================"+ fromdate );
					
					 WebElement webElement=driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/div[2]/a"));
					 webElement.sendKeys(Keys.TAB,Keys.TAB,fromdate,Keys.TAB,todate,Keys.TAB,Keys.TAB);
					 
					 test.log(Status.PASS, "Set the start date to 01-11-2016 and end date 30-11-2016, and Verify data in web table");
					 
				 Thread.sleep(3000);  
			//	 js.executeScript("window.scrollBy(0,300)");
				//*[@id="dataTableID"]/tbody[2]/tr[2]/td[1]  2016-11-30,0.56,1.512322545051575
				 
				 
				 if(Step7_1.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[1]")).getText())){
					 test.log(Status.PASS, Step7_1 + "   value fond in series table in row 1 col 1");
					 
				 }else{
					 test.log(Status.FAIL, Step7_1 + "   value NOT fond in series table in row 1 col 1");
					 TestStatus= "FAIL";
				 }
				 if(Step7_2.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[2]")).getText())){
					 test.log(Status.PASS, Step7_2 + "   value fond in series table in row 1 col 2");
				 }else{
					 test.log(Status.FAIL, Step7_2 + "   value NOT fond in series table in row 1 col 2");
					 TestStatus= "FAIL";
				 }
				 if(Step7_3.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[3]")).getText())){
					 test.log(Status.PASS, Step7_3 + "  value fond in series table in row 1 col 3");
				 }else{
					 test.log(Status.FAIL, Step7_3 + " value NOT fond in series table in row 1 col 3");
					 TestStatus= "FAIL";
				 }
				 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, " SearchfreeText_Range", test, date1)); 
				//=======================================
				 test.log(Status.PASS, "Click on the reset settings image ");
				 
				 ////*[@id="dataTableID"]/tbody[2]/tr[2]/td[1]
					 WebElement webElement2=driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/div[2]/a"));
				 webElement2.sendKeys(Keys.TAB,Keys.ENTER);
				 
				  Thread.sleep(3000);
				  
					 if(Step9_1.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[1]")).getText())){
						 test.log(Status.PASS, Step9_1 + "  value fond in series table in row 1 col 1");
						 
					 }else{
						 test.log(Status.FAIL, Step9_1 + " value NOT fond in series table in row 1 col 1");
						 TestStatus= "FAIL";
					 }
					 if(Step9_2.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[2]")).getText())){
						 test.log(Status.PASS, Step9_2 + "  value fond in series table in row 1 col 2");
					 }else{
						 test.log(Status.FAIL, Step9_2 + "  value NOT fond in series table in row 1 col 2");
						 TestStatus= "FAIL";
					 }
					 if(Step9_3.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[3]")).getText())){
						 test.log(Status.PASS, Step9_3 + "  value fond in series table in row 1 col 3");
					 }else{
						 test.log(Status.FAIL, Step9_3 + "  value NOT fond in series table in row 1 col 3");
						 TestStatus= "FAIL";
					 }
				
					 
					 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "SearchfreeText_Range1", test, date1)); 
										
					 
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Search free Text_Range :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

    public String SearchfreeText_MetaData(WebDriver driver, String Step4,String Step5,String Step6,String Step7,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			TestStatus= "PASS";
			 //Click on the link Metadata on the top of the page
			System.out.println("I am in SearchfreeText_MetaData=======================");
			
			driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[2]/a")).click();
			 Thread.sleep(5000);
			 test.log(Status.PASS, "Click the link MetaData on the top links section");
			
			 
			 driver.findElement(By.xpath("//*[@id='datasetLevelMetadata1']/h2[1]/img")).click();
			 test.log(Status.PASS, "Click on the Header DD_TST - Test Derived Data is available under Dataset Level Metadata table");
			 
					 
			 driver.findElement(By.xpath("//*[@id='datasetLevelMetadata1']/h2[2]/img")).click();
			 test.log(Status.PASS, "Click on the Header EXR_TST - Exchange Rates Test is available under Dataset Level Metadata table");
			 
			
			 String DD_TST_SDWText= driver.findElement(By.xpath("//*[@id='DD_TST - Test Derived Data']/table/tbody/tr[3]/td[2]")).getText();
			 
			String DD_TST_LastUpdate= driver.findElement(By.xpath("//*[@id='DD_TST - Test Derived Data']/table/tbody/tr[3]/td[3]")).getText();
				
			String QSA_TST_SDWText= driver.findElement(By.xpath("//*[@id='EXR_TST - Exchange Rates Test ']/table/tbody/tr[3]/td[2]")).getText();
					
			String QSA_TST_LastUpdate= driver.findElement(By.xpath("//*[@id='EXR_TST - Exchange Rates Test ']/table/tbody/tr[3]/td[3]")).getText();

		if (QSA_TST_LastUpdate.isEmpty() && DD_TST_SDWText.isEmpty() ){
			test.log(Status.PASS, "In QSA_TST_LastUpdate link, Text 'Dataset last update in SDW' is NOT missing ");
			TestStatus= "FAIL";
		}else{
			test.log(Status.PASS, "QSA_TST_LastUpdate and Text 'Dataset last update in SDW' is avilable ");
			
		}
		
		if (DD_TST_LastUpdate.isEmpty() && QSA_TST_SDWText.isEmpty() ){
			test.log(Status.PASS, "In DD_TST_LastUpdate link, Text 'Dataset last update in SDW' is NOT missing ");
			TestStatus= "FAIL";
		}else{
			test.log(Status.PASS, "In DD_TST_LastUpdate link, Text 'Dataset last update in SDW' is avilable ");
			
		}
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "SearchfreeText_MetaData", test, date1));
					
					 
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Search free Text MetaData :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}



}
