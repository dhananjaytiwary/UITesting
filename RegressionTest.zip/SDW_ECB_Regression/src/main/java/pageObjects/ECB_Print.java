package pageObjects;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Properties;
import java.util.Set;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.testautomationguru.utility.PDFUtil;

import managers.FileReaderManager;
import utilities.CommonFunctions;
import utilities.PropertyReader;
import utilities.Screenshots;
public class ECB_Print {
	private static final String Else = null;
	Screenshots objCreateScreenshot = new Screenshots();
	CommonFunctions com = new CommonFunctions();
	String TestStatus="PASS";
	 WebElement TabName =null;
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
	PDFUtil pdfUtil = new PDFUtil();
		
		public String Print_Intermediate_Nodes(WebDriver driver,String node, String Step3, ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
				String url=ApplicaitonUrl+node;
				
				driver.get(url);
				test.log(Status.PASS, "Login to ECB portal and goto node=9701957");
			
				ArrayList aList= new ArrayList(Arrays.asList(Step3.split(",")));
		
				//links available in Available Data Sets table
			 		
			 String Link1= (String) aList.get(0);
			 String Link2= (String) aList.get(1);
			 String Link3= (String) aList.get(2);
					 String text1=driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[1]")).getText();
			 System.out.println(Link1 + "==========================" + text1);
				
			
		if (Link1.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[1]")).getText())&& driver.findElement(By.linkText(Link1)).isDisplayed() ){
			test.log(Status.PASS, Link1+ " links available in Data Set in row 2 col 5");
			
		}else{
			test.log(Status.FAIL, Link1+ " links NOT available in Data Set in row 2 col 5");
			TestStatus= "FAIL";
		}
		
		if (Link2.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[2]")).getText())&& driver.findElement(By.linkText(Link2)).isDisplayed() ){
			test.log(Status.PASS, Link2+ " links available in Data Set in row 2 col 5");
			
		}else{
			test.log(Status.FAIL, Link2+ " links NOT available in Data Set in row 2 col 5");
			TestStatus= "FAIL";
		}
		
		if (Link3.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[3]")).getText())&& driver.findElement(By.linkText(Link3)).isDisplayed() ){
			test.log(Status.PASS, Link3+ " links available in Data Set in row 2 col 5");
			
		}else{
			test.log(Status.FAIL, Link3+ " links NOT available in Data Set in row 2 col 5");
			TestStatus= "FAIL";
		}
		
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
					
					
				return TestStatus;
							
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, "Links are NOT available in Data Set in row 2 col 5 :  FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}

		//---------------------------------------------------------------------
	
		public String Print_Data_Table(WebDriver driver,ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
		  	 test.log(Status.PASS, "Check the check boxes for the first 2 series in the series table");
		  	JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("window.scrollBy(0,500)");
			
			
			 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input")).click();
			// Thread.sleep(1000);
			 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input")).click();
		//	
			 Thread.sleep(3000); 
			
			 test.log(Status.PASS, "Clicked check boxes for the first 2 series in the series table");
			
					WebElement element = driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[3]/a"));
					Actions actions = new Actions(driver);
					actions.moveToElement(element).click().perform();
					 test.log(Status.PASS, "Click the link Data Table on the top links section");
					
					// js.executeScript("window.scrollBy(0,600)");
					 Thread.sleep(2000); 
					 
					element = driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[8]/a[1]"));
						//Actions actions = new Actions(driver);
						actions.moveToElement(element).click().perform();
						
			 String parent_handle= driver.getWindowHandle();
			
				 test.log(Status.PASS, "Click the Print link on the top links section");
				
				 Set<String> handles = driver.getWindowHandles();
			//	 System.out.println(handles);
				 for(String handle1:handles)
				     if(!parent_handle.equals(handle1))
				     {
				         driver.switchTo().window(handle1);
				         driver.manage().window().maximize();
				         Thread.sleep(2000); 
				        driver.findElement(By.xpath("//html/body/form/table/tbody/tr[1]/td/button")).click();
				      //  driver.manage().window().maximize();
				      
				         Thread.sleep(3000); 
				         test.log(Status.PASS, "PDF File downloaded successfully");	
				//      String newPdffile=renameFile(path2);
				String MasterFileName=System.getProperty("user.dir") + "\\src\\test\\java\\TestData\\DataTable.pdf";
				//Now download new PDF file 
				String Filepath=System.getProperty("user.dir") + "\\DownloadFolder\\";
				String newfileName=com.NewPDFileNmae(Filepath);
		
				String PDFFilepath=System.getProperty("user.dir") + "\\DownloadFolder\\"+newfileName;
				test.log(Status.PASS, "Compare newly downloaded Data Table PDF file with existing data table file");
						
				
				Boolean result= pdfUtil.compare(MasterFileName, PDFFilepath);
				if(result){	
					test.log(Status.PASS, "Data Table PDF file is same as masterDataTable pdf file");
				//	System.out.println("Both PDF file is same");
				}else{
					test.log(Status.FAIL, "Data Table PDF file is NOT same as masterDataTable pdf file");
				//	System.out.println("Both PDF file is NOT same");
					TestStatus="FAIL";
					}
				
				com.DeleteFile(Filepath, newfileName);
				 test.log(Status.PASS, "Delete the local pdf file after compare");    
				 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
					        
				   } 				 
									
				return TestStatus;
							
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, "Print_Data_Table :  FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}

		public String Print_Update_DataTable(WebDriver driver,ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
						
							
		  	 test.log(Status.PASS, "Check the check boxes for the first 2 series in the series table");
		  	JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("window.scrollBy(0,500)");
			
			
			 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input")).click();
			// Thread.sleep(1000);
			 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input")).click();
		//	
			 Thread.sleep(3000); 
			
			 test.log(Status.PASS, "Clicked check boxes for the first 2 series in the series table");
			
					WebElement element = driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[3]/a"));
					Actions actions = new Actions(driver);
					actions.moveToElement(element).click().perform();
					 test.log(Status.PASS, "Click the link Data Table on the top links section");
					
					// js.executeScript("window.scrollBy(0,600)");
					 Thread.sleep(2000); 
					 
					element = driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[8]/a[1]"));
						//Actions actions = new Actions(driver);
						actions.moveToElement(element).click().perform();
						
			 String parent_handle= driver.getWindowHandle();
			 test.log(Status.PASS, "Click the Print link on the top links section");
				 
				 Set<String> handles = driver.getWindowHandles();
			
				 for(String handle1:handles)
				     if(!parent_handle.equals(handle1))
				     {
				         driver.switchTo().window(handle1);
				         Thread.sleep(2000); 
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td/textarea")).clear();
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td/textarea")).sendKeys("Title");
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td/textarea")).clear();
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td/textarea")).sendKeys("Footnote");
				         
				         driver.findElement(By.xpath("//*[@id='print_landscape']")).click();
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td/textarea")).clear();
				         
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td/textarea")).sendKeys("Heading 1");
				        
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[6]/td/textarea")).clear();
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[6]/td/textarea")).sendKeys("Heading 2");
				       
				        // driver.manage().window().maximize();
				         Thread.sleep(2000); 
				        driver.findElement(By.xpath("//html/body/form/table/tbody/tr[1]/td/button")).click();
				     
				     }
				         Thread.sleep(3000); 
				         test.log(Status.PASS, "PDF File downloaded successfully");	
				//      String newPdffile=renameFile(path2);
				String MasterFileName=System.getProperty("user.dir") + "\\src\\test\\java\\TestData\\UpdatedDataTable.pdf";
				
				String Filepath=System.getProperty("user.dir") + "\\DownloadFolder\\";
				String newfileName=com.NewPDFileNmae(Filepath);
			//System.out.println("New File Name " + newfileName);
				//----------------
				
				String PDFFilepath=System.getProperty("user.dir") + "\\DownloadFolder\\"+newfileName;
				test.log(Status.PASS, "Compare newly downloaded Data Table PDF file with existing DataTable file");
						
				
				Boolean result= pdfUtil.compare(MasterFileName, PDFFilepath);
				if(result){	
					test.log(Status.PASS, "Updated Data Table PDF file is same as existing Updated DataTable pdf file");
					com.DeleteFile(Filepath, newfileName);
					 test.log(Status.PASS, "Delete the local pdf file after compare");   
				}else{
					test.log(Status.FAIL, "Updated Data Table PDF file is NOT same as existing Updated DataTable pdf file");
				//	System.out.println("Both PDF file is NOT same");
					TestStatus="FAIL";
					}
				
				//After compare updated PDF file , delete it
			//	 
				 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
					 
			 
				return TestStatus;
							
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, "Print_Updated DataTable :  FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}

		//=============================================
		public String Print_Data_Chart(WebDriver driver,ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
		
		  	 test.log(Status.PASS, "Check the check boxes for the first 2 series in the series table");
		  	JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("window.scrollBy(0,500)");
			
			
			 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input")).click();
			
			 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input")).click();
		//	
			 Thread.sleep(3000); 
			
			 test.log(Status.PASS, "Clicked check boxes for the first 2 series in the series table");
			
					WebElement element = driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[4]/a"));
					Actions actions = new Actions(driver);
					actions.moveToElement(element).click().perform();
					 test.log(Status.PASS, "Click the link Data Chart on the top links section");
					
					// js.executeScript("window.scrollBy(0,600)");
					 Thread.sleep(2000); 
					 
					element = driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[8]/a[1]"));
						//Actions actions = new Actions(driver);
						actions.moveToElement(element).click().perform();
						
			 String parent_handle= driver.getWindowHandle();
		
				 test.log(Status.PASS, "Click the Print link on the top links section");
				 
			//	 System.out.println("parent_handle                   " + parent_handle);
				 Set<String> handles = driver.getWindowHandles();
	
				 for(String handle1:handles)
				     if(!parent_handle.equals(handle1))
				     {
				         driver.switchTo().window(handle1);
				           driver.findElement(By.xpath("//html/body/form/table/tbody/tr[1]/td/button")).click();
				
				           Thread.sleep(3000); 
				         test.log(Status.PASS, "PDF File downloaded successfully");	
			
				String MasterFileName=System.getProperty("user.dir") + "\\src\\test\\java\\TestData\\DataChart.pdf";
				//Now download new PDF file 
				String Filepath=System.getProperty("user.dir") + "\\DownloadFolder\\";
				String newfileName=com.NewPDFileNmae(Filepath);
		
				String PDFFilepath=System.getProperty("user.dir") + "\\DownloadFolder\\"+newfileName;
				test.log(Status.PASS, "Compare newly downloaded Data Chart PDF file with existing DataChart file");
						
				
				Boolean result= pdfUtil.compare(MasterFileName, PDFFilepath);
				if(result){	
					test.log(Status.PASS, "New Data  Chart PDF file is same as Existing Data Chart pdf file");
				//	System.out.println("Both PDF file is same");
				}else{
					test.log(Status.FAIL, "New Data  Chart PDF file is NOT same as Existing Data Chart pdf file");
				//	System.out.println("Both PDF file is NOT same");
					TestStatus="FAIL";
					}
				
				com.DeleteFile(Filepath, newfileName);
				 test.log(Status.PASS, "Delete the local pdf file after compare");    
				 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
					        
				   } 				 
									
				return TestStatus;
							
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, "Print_Data_Chart :  FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}

		public String Print_Update_DataChart(WebDriver driver,ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
						
							
		  	 test.log(Status.PASS, "Check the check boxes for the first 2 series in the series table");
		  	JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("window.scrollBy(0,500)");
						
			 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input")).click();
			
			 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input")).click();
		//	
			 Thread.sleep(3000); 
			
			 test.log(Status.PASS, "Clicked check boxes for the first 2 series in the series table");
			
					WebElement element = driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[4]/a"));
					Actions actions = new Actions(driver);
					actions.moveToElement(element).click().perform();
					 test.log(Status.PASS, "Click the link Data Chart on the top links section");
					
					// js.executeScript("window.scrollBy(0,600)");
					 Thread.sleep(2000); 
					 
					element = driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[8]/a[1]"));
						//Actions actions = new Actions(driver);
						actions.moveToElement(element).click().perform();
						
			 String parent_handle= driver.getWindowHandle();
			 test.log(Status.PASS, "Click the Print link on the top links section");
				 
				 Set<String> handles = driver.getWindowHandles();
			
				 for(String handle1:handles)
				     if(!parent_handle.equals(handle1))
				     {
				         driver.switchTo().window(handle1);
				         Thread.sleep(2000); 
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td/textarea")).clear();
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td/textarea")).sendKeys("Title");
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td/textarea")).clear();
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td/textarea")).sendKeys("Footnote");
				         
				         driver.findElement(By.xpath("//*[@id='print_landscape']")).click();
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td/textarea")).clear();
				         
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td/textarea")).sendKeys("Heading 1");
				        
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[6]/td/textarea")).clear();
				         driver.findElement(By.xpath("/html/body/form/table/tbody/tr[6]/td/textarea")).sendKeys("Heading 2");
				       
				        // driver.manage().window().maximize();
				         Thread.sleep(2000); 
				        driver.findElement(By.xpath("//html/body/form/table/tbody/tr[1]/td/button")).click();
				     
				     }
				         Thread.sleep(3000); 
				         test.log(Status.PASS, "PDF File downloaded successfully");	
				//      String newPdffile=renameFile(path2);
				String MasterFileName=System.getProperty("user.dir") + "\\src\\test\\java\\TestData\\UpdatedDataChart.pdf";
				
				String Filepath=System.getProperty("user.dir") + "\\DownloadFolder\\";
				String newfileName=com.NewPDFileNmae(Filepath);
						
				String PDFFilepath=System.getProperty("user.dir") + "\\DownloadFolder\\"+newfileName;
				test.log(Status.PASS, "Compare newly downloaded Data Chart PDF file with existing DataChart file");
						
				
				Boolean result= pdfUtil.compare(MasterFileName, PDFFilepath);
				if(result){	
					test.log(Status.PASS, "Updated New Data Chart PDF file is same as Existing Data Chart pdf file");
				
				}else{
					test.log(Status.FAIL, "Updated New Data Chart PDF file is NOT same as Existing Data Chart pdf file");
					TestStatus="FAIL";
					}
				
				//After compare updated PDF file , delete it
				com.DeleteFile(Filepath, newfileName);
				 test.log(Status.PASS, "Delete the local pdf file after compare");    
				 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
					 
			 
				return TestStatus;
							
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, "Print_Updated Data Chart :  FAIL ");
				test.log(Status.PASS, "Closed the Browser");
				return "FAIL";
			}
			
		}
	
		//============================================
	 public String Data_Static_Chart(WebDriver driver,String node, ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{ 
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Data_Charts===================      "+ url);
			driver.get(url);
			
			test.log(Status.PASS, "Login to ECB portal and goto node=9701957");
		//com.DeleteFile(System.getProperty("user.dir") + "\\DownloadFolder\\", "data.csv");

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");

			driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input")).click();
			driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input")).click();
			
			test.log(Status.PASS, "Select the 1st and 2nd series checkboxes in the table available at the bottom of the page");
		
			//*[@id="toolBar"]/tbody/tr/td[4]/a
			Thread.sleep(3000);
			driver.findElement(By.partialLinkText("Data Chart")).click();
			test.log(Status.PASS, "Click on link Data Chart on the top of the page");
			js.executeScript("window.scrollBy(0,700)");
			driver.findElement(By.partialLinkText("Static Chart")).click();
			test.log(Status.PASS, "Click on link Static Chart link, static chart display on page");
			Thread.sleep(5000);
			
			//below code is to download Img from page	==============================
			
			String path1=System.getProperty("user.dir") + "\\src\\test\\java\\TestData\\testscreen.png"; 
			String path2=System.getProperty("user.dir") + "\\src\\test\\java\\TestData\\MasterBrowseChart.png"; 
			
			if(com.downloadChart(driver, path1)){
				test.log(Status.PASS, "Static chart downloaded successfully");
				test.log(Status.PASS, "Compare downloaded Static chart with master static chart ");
				float per=com.compareImage2(new File(path1),new File(path2));
				System.out.println("percentage : " +per);
				
				if(com.compareImage(new File(path1),new File(path2))){
					System.out.println("Both chart is same");
					test.log(Status.PASS, "Static chart compare with master static chart successfully with :" + per +"%");
				}else{
					test.log(Status.PASS, "Static chart compare with master static chart: Fail with :" + per +"%");
					TestStatus="FAIL";
				}
			}else{
				test.log(Status.FAIL, "Static chart downloaded successfully");
				TestStatus="FAIL";
			}
		
		
		
		
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));	
		
				
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Compare Data Chart:  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}


}
