package pageObjects;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
//import java.awt.Color;
import java.util.StringTokenizer;

import org.apache.poi.hssf.record.PageBreakRecord.Break;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import managers.FileReaderManager;
import utilities.CommonFunctions;
import utilities.PropertyReader;
import utilities.Screenshots;
public class ECB_Manage_DataGroups {
	Screenshots objCreateScreenshot = new Screenshots();
	CommonFunctions com = new CommonFunctions();
//	PropertyReader CenterPage=new PropertyReader("src/main/java/pageObjects/SDW_CenterPage.properties");
	 String fieldvalue1="";
	 String TestStatus="PASS";
	 WebElement TabName =null;
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
	 
	public String Add_New_DataGroup(WebDriver driver, String node, String Step4,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
			
			driver.get(url);
			Thread.sleep(5000);
			test.log(Status.PASS, "Login to ECB portal and goto node = " + node );
			String TestStatus="";

			driver.findElement(By.linkText("Add to My Data")).click();
			Thread.sleep(2000);
			test.log(Status.PASS, "Click Add to My Data link on top of the page");
		
			driver.findElement(By.xpath("//input[@type='text' and @name='newGroup']")).sendKeys(Step4);
	
			driver.findElement(By.id("createNewGroup")).click();
			test.log(Status.PASS, "Enter new Group name and clicked on Create new Group button");
			Thread.sleep(5000);
			
			
			//Your data has been successfully added to new data group "Test Automation100".
			if (driver.getPageSource().contains("Duplicate submission is not allowed") || driver.getPageSource().contains("The group named  is already in use")){
				 test.log(Status.FAIL, "Duplicate submission is not allowed. Please try again to add to a new group.");
				 TestStatus= "FAIL";
			}
			else if(driver.getPageSource().contains("Your data has been successfully added to new data group"))
			{
			test.log(Status.PASS, "Verified new Group name has been successfully added to new data group");
		
			driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[4]/a/span")).click();
			test.log(Status.PASS, "Click on My Data Groups on the left hand side menu");
			
			Thread.sleep(2000);
			//No.of rows 
	        List  rows = driver.findElements(By.xpath(".//*[@id='datagroup']/tbody/tr/td[1]")); 
	        System.out.println("No of rows are : " + rows.size());
	        
	        for (int i =1;i<rows.size()+1;i++)
	        {   
	        	if((Step4.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[1]")).getText())) && (driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[2]")).getText().isEmpty())){
	        		//My Data Groups page is opened and the newly added group is shown
	        		 test.log(Status.PASS, "My Data Groups page is opened and the newly added group is shown :" + Step4);
					 TestStatus= "PASS";
					 break;
	        	}	           
	        }
		}
	       
	        test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Add_New_DataGroup", test, date1));
			
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Add_New_DataGroup :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	 
	public String Not_Allowed_Group_Name(WebDriver driver, String node, String Step4,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
			TestStatus="";
			driver.get(url);
			Thread.sleep(5000);
			test.log(Status.INFO, "Login to ECB portal and goto node = " + node );
			String TestStatus="";
			JavascriptExecutor js = (JavascriptExecutor) driver;
			driver.findElement(By.linkText("Add to My Data")).click();
			Thread.sleep(2000);
			test.log(Status.INFO, "Click Add to My Data link on top of the page");
		
			driver.findElement(By.xpath("//input[@type='text' and @name='newGroup']")).sendKeys(Step4);
	
			driver.findElement(By.id("createNewGroup")).click();
			test.log(Status.INFO, "Given new group name in 'Create and add to a new group' field and clicked on Create new Group button");
			Thread.sleep(5000);
			
			
			//Your data has been successfully added to new data group "Test Automation100".
			if (driver.getPageSource().contains("Only alphanumeric characters, whitespace and restricted special characters")){
				 test.log(Status.PASS, " Only alphanumeric characters, whitespace and restricted special characters - underscore (_) and dash (-) - are allowed in field");
				 TestStatus= "PASS";
			}
			else if(driver.getPageSource().contains("Your data has been successfully added to new data group"))
			{
				test.log(Status.FAIL, "alphanumeric characters, whitespace and restricted special characters - underscore (_) and dash (-) - are allowed in field 'New Group'");
				 TestStatus= "FAIL";
			}
			test.log(Status.INFO, "Verified successfully added new data group ");
			
	        test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Add new_Group_Name", test, date1));
		
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[4]/a/span")).click();
			test.log(Status.INFO, "Click on My Data Groups on the left hand side menu");
			
			//No.of rows 
	        List  rows = driver.findElements(By.xpath(".//*[@id='datagroup']/tbody/tr/td[1]")); 
	        System.out.println("No of rows are : " + rows.size());
	        
	        for (int i =1;i<rows.size()+1;i++)
	        {   
	        	if((Step4.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[1]")).getText()))){
	        		//My Data Groups page is opened and the newly added group is shown
	        		 test.log(Status.PASS, "The newly added group '"+ Step4+"' is shown in Data Groups list " );
					 TestStatus= "PASS";
					 break;
	        	
	        	}
	           
	        }
	        test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Not_in_Data Group", test, date1));
	        
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Add_New_DataGroup :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	
	public String DataGroupList(WebDriver driver, String Step3,ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
				String url=ApplicaitonUrl;
				System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
			//	ArrayList aList3= new ArrayList(Arrays.asList(Step3.split(";")));
				
				driver.get(url);
				test.log(Status.INFO, "Login to ECB portal home page "  );
				Thread.sleep(5000);

				driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[4]/a/span")).click();
				test.log(Status.INFO, "Click on My Data Groups on the left hand side menu");
				Thread.sleep(2000);
				//*[@id="datagroup"]/tbody
				 List  rows = driver.findElements(By.xpath(".//*[@id='datagroup']/tbody/tr/td[1]")); 
			        System.out.println("No of rows are : " + rows.size());
			        String groupName="";
			        String groupComment="";
			        int x=1;
			        for (int i =1;i<=rows.size();i++)
			        {  
			        	groupName=driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[1]")).getText();
			        	groupComment=driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[2]")).getText();
			        	System.out.println(groupName + " --------- " + groupComment);
			        	
			        	System.out.println(" test data  " + Step3);
			        	
			           	if(groupName.equalsIgnoreCase(Step3) && groupComment.isEmpty()){
			        		
			        		 test.log(Status.PASS, "In Data Groups list,newly added group is '"+ Step3+"' and Comment is empty " );
										        	
			        	}
			           
			        }
			  
		        test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "DataGroupList", test, date1));
				
				return TestStatus;
							
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, "Data Group List test :  FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}

	public String SortDataGroups(WebDriver driver, ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			String url=ApplicaitonUrl;
					
			
			driver.get(url);
			test.log(Status.INFO, "Login to ECB portal home page "  );
			Thread.sleep(5000);

			driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[4]/a/span")).click();
			test.log(Status.PASS, "Click on My Data Groups on the left hand side menu");
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//*[@id='datagroup']/thead/tr/th[1]/a")).click();
			test.log(Status.PASS, "Click on Name in the Data Groups table");
			Thread.sleep(2000);
			test.log(Status.INFO, "Data groups are ordered as per Alphabetical order");
			
	        test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "SortDataGroups", test, date1));
			
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Sort Data Groups test :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	
public String Add_Existing_DataGroup_Without_Selecting(WebDriver driver, String node,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
			
			driver.get(url);
			test.log(Status.INFO, "Login to ECB portal and goto node = " + node );
			
			
			Thread.sleep(2000);

			driver.findElement(By.linkText("Add to My Data")).click();
			Thread.sleep(2000);
			test.log(Status.INFO, "Click Add to My Data link on top of the page");
		
	    	
	    	driver.findElement(By.name("addToGroup")).click();
	    	test.log(Status.PASS, "Click on Add button next to - Add to Group" );
	    	Thread.sleep(2000);
	    	Alert confirmation = driver.switchTo().alert();
	    	String alerttext = confirmation.getText();
	    	
    	
			if (alerttext.isEmpty()){
				
				 test.log(Status.FAIL, "NO Messgae is shown as 'Please select a group' " );
				 TestStatus="FAIL";	
			}
			else
				
			{	
				test.log(Status.PASS, "Alert Messgae is shown as 'Please select a group'" );
				confirmation.accept();
			}
			Thread.sleep(2000);	      		
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Add_Existing_DataGroup_Without_Selecting", test, date1));	
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Add_Existing_DataGroup_Without_Selecting :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

public String Add_Existing_DataGroup(WebDriver driver, String node, String Step3,String Step4,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		String url=ApplicaitonUrl+node;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		ArrayList aList4= new ArrayList(Arrays.asList(Step4.split(";")));
		
		driver.get(url);
		test.log(Status.INFO, "Login to ECB portal and goto node = " + node );
		String TestStatus="";
		
		Thread.sleep(2000);

		driver.findElement(By.linkText("Add to My Data")).click();
		Thread.sleep(2000);
		test.log(Status.INFO, "Click Add to My Data link on top of the page");
	

		driver.findElement(By.name("selectedGroup")).click();
		Thread.sleep(2000);
		Select List=new Select(driver.findElement(By.name("selectedGroup")));
		test.log(Status.PASS, "Select the existing Publication report in - Add to a publication" );
      	
    	 List <WebElement> op = List.getOptions();
         int size = op.size();
         for(int i =0; i<size ; i++){
            String options = op.get(i).getText();
            if(options.contains(Step3)){
            	op.get(i).click();
            }
            System.out.println(options);
         }
    	
    	driver.findElement(By.name("addToGroup")).click();
    	test.log(Status.PASS, "Click on Add button next to - Add to Group" );
    //	Thread.sleep(5000);
		
		
		//Your data has been successfully added to new data group "Test Automation100".
		if (driver.getPageSource().contains("Duplicate submission is not allowed") || driver.getPageSource().contains("The group named  is already in use")){
			 test.log(Status.FAIL, "Duplicate submission is not allowed. Please try again to add to a new group.");
			 TestStatus= "FAIL";
		}
		else if(driver.getPageSource().contains("Your data has been successfully added to the existing data group "))
		{///Your data has been successfully added to the existing data group "MyTestingGroup11".
		
		driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[4]/a/span")).click();
		test.log(Status.INFO, "Click on My Data Groups on the left hand side menu");
		
	Thread.sleep(3000);
		//No.of rows 
   
		List  myDataGroup = driver.findElements(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li")); 
		System.out.println("myDataGroup : " + myDataGroup.size());
		
		for(int i=1;i<=myDataGroup.size();i++){
			 if(driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).getText().equalsIgnoreCase(Step3)){
				 driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).click();
				 System.out.println("myPublist : " + driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).getText());
				 test.log(Status.PASS, "Click on existing report link under My Publications " );
			 }
			 
		 }
		Thread.sleep(3000);
		if(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[1]/input")).isSelected() && driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[2]/td[1]/input")).isSelected()){
			 test.log(Status.PASS, "In Available Datasets table row 3 col 1 and row 4 col 1 checkboxes are checked " );
		}else{
			 test.log(Status.FAIL, "In Available Datasets table row 3 col 1 and row 4 col 1 checkboxes are NOT checked " );
			 TestStatus="FAIL";
		}
		int flag=0;
	
		List  row = driver.findElements(By.xpath("//*[@id='datasetTable']/tbody/tr")); 
		int rowsize=row.size();
		for(int i=0;i<=1;i++){
			
			for(int x=1;x<=rowsize;x++){
				
				if(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr["+x+"]/td[2]")).getText().contains((String) aList4.get(i))){
					flag=1;
					 test.log(Status.PASS, "The Datasets "+(String) aList4.get(i)+" is available in Datasets table" );
					 x=rowsize+2;
				}
			}
		}
		
		if(flag==0){
				 test.log(Status.FAIL, "The Datasets QSA_TST or DD_TST  NOT available in Available Datasets table " );
				TestStatus="FAIL";
			}
	
	}
       
   
        test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Add_Exisitng_DataGroup", test, date1));
		
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "Add_Exisitng_DataGroup :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}


public String Replace_Existing_DataGroup(WebDriver driver, String node, String Step3,String Step4,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		String url=ApplicaitonUrl+node;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		ArrayList aList4= new ArrayList(Arrays.asList(Step4.split(";")));
		
		driver.get(url);
		test.log(Status.INFO, "Login to ECB portal and goto node = " + node );
		String TestStatus="";
		
		Thread.sleep(3000);

		driver.findElement(By.linkText("Add to My Data")).click();
		Thread.sleep(3000);
		test.log(Status.INFO, "Click Add to My Data link on top of the page");
	
	//	driver.findElement(By.xpath("//input[@type='text' and @name='newGroup']")).sendKeys(Step4);
		
		driver.findElement(By.name("selectedReplaceGroup")).click();
		Thread.sleep(2000);
		Select List=new Select(driver.findElement(By.name("selectedReplaceGroup")));
		test.log(Status.PASS, "Select the existing Publication report in - Replace Group" );
    //	webList.selectByVisibleText(Step3);
    	
    	
    	 List <WebElement> op = List.getOptions();
         int size = op.size();
         for(int i =0; i<size ; i++){
            String options = op.get(i).getText();
            if(options.contains(Step3)){
            	op.get(i).click();
            }
            System.out.println(options);
         }
    	
    	driver.findElement(By.name("replaceGroup")).click();
    	test.log(Status.PASS, "Click on Add button next to - Replace" );
    //	Thread.sleep(5000);
		
		
		//Your data has been successfully added to new data group "Test Automation100".
		if (driver.getPageSource().contains("Duplicate submission is not allowed") || driver.getPageSource().contains("The group named  is already in use")){
			 test.log(Status.FAIL, "Duplicate submission is not allowed. Please try again to add to a new group.");
			 TestStatus= "FAIL";
		}
		else if(driver.getPageSource().contains("Your data has been successfully replaced in the existing data group "))
		{///Your data has been successfully added to the existing data group "MyTestingGroup11".
		
		driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[4]/a/span")).click();
		test.log(Status.INFO, "Click on My Data Groups on the left hand side menu");
		
	Thread.sleep(3000);
		//No.of rows 
   
		List  myDataGroup = driver.findElements(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li")); 
		System.out.println("myDataGroup : " + myDataGroup.size());
		
		for(int i=1;i<=myDataGroup.size();i++){
			 if(driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).getText().equalsIgnoreCase(Step3)){
				 driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).click();
				 System.out.println("myPublist : " + driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).getText());
				 test.log(Status.PASS, "Click on existing report link under My Publications " );
			 }
			 
		 }
		Thread.sleep(3000);
		
		if(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[1]/input")).isSelected() && driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[2]/td[1]/input")).isSelected()){
			 test.log(Status.PASS, "In Available Datasets table row 3 col 1 and row 4 col 1 checkboxes are checked " );
		}else{
			 test.log(Status.FAIL, "In Available Datasets table row 3 col 1 and row 4 col 1 checkboxes are NOT checked " );
			 TestStatus="FAIL";
		}
		
		//*[@id="datasetTable"]/tbody/tr[1]/td[2]
		System.out.println(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[2]")).getText());
		System.out.println((String) aList4.get(0));
		
		System.out.println(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[2]/td[2]")).getText());
		System.out.println((String) aList4.get(1));
		
		//*[@id="datasetTable"]/tbody/tr[3]/td[2]
		if(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[2]")).getText().contains((String) aList4.get(0))
				&& driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[2]/td[2]")).getText().contains((String) aList4.get(1))){
			 test.log(Status.PASS, "The Datasets QSA_TST and DD_TST are available in Available Datasets table" );
		}else{
			 test.log(Status.FAIL, "The Datasets QSA_TST and DD_TST are NOT available in Available Datasets table " );
			 TestStatus="FAIL";
		}
		
	}
       
        test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Add_Replace_DataGroup", test, date1));
		
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "Replace_Existing_DataGroup :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}

public String Replace_Existing_DataGroup_Without_Selecting(WebDriver driver, String node,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		String url=ApplicaitonUrl+node;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		
		driver.get(url);
		test.log(Status.INFO, "Login to ECB portal and goto node = " + node );
				
		Thread.sleep(2000);

		driver.findElement(By.linkText("Add to My Data")).click();
		Thread.sleep(2000);
		test.log(Status.INFO, "Click Add to My Data link on top of the page");
	
    	
    	driver.findElement(By.name("replaceGroup")).click();
    	test.log(Status.PASS, "Click the button next to Replace Existing data group drop down without selecting a group" );
    	Thread.sleep(2000);
    	Alert confirmation = driver.switchTo().alert();
    	String alerttext = confirmation.getText();
    	
	
		if (alerttext.isEmpty()){			
			 test.log(Status.FAIL, "NO Messgae is shown as 'Please select a group' " );
			 TestStatus="FAIL";	
		}
		else{	
			test.log(Status.PASS, "Alert Messgae is shown as 'Please select a group'" );
			confirmation.accept();
			}
			      		
		Thread.sleep(2000);
	    test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Replace_Existing_DataGroup_Without_Selecting", test, date1));
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "Add_Existing_DataGroup_Without_Selecting :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
}

	
public String BrowseDataGroup(WebDriver driver, String Step3,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			
			String url=ApplicaitonUrl;
			System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
			//ArrayList aList3= new ArrayList(Arrays.asList(Step3.split(";")));
			
			driver.get(url);
			test.log(Status.INFO, "Login to ECB portal home page "  );
			Thread.sleep(5000);

			driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[4]/a/span")).click();
			test.log(Status.INFO, "Click on My Data Groups on the left hand side menu");
			Thread.sleep(2000);
			//*[@id="datagroup"]/tbody
			 List  rows = driver.findElements(By.xpath(".//*[@id='datagroup']/tbody/tr/td[1]")); 
		        System.out.println("No of rows are : " + rows.size());
		        String groupName="";
		        String groupComment="";
		        int x=1;
		        for (int i =1;i<=rows.size();i++)
		        {  
		        	groupName=driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[1]")).getText();
		        	groupComment=driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[2]")).getText();
		        	System.out.println(groupName + " --------- " + groupComment);
		        	
		        	System.out.println(" test data  " + Step3);
		        	
		           	if(groupName.equalsIgnoreCase(Step3) && groupComment.isEmpty()){
		        		test.log(Status.PASS, "In Data Groups list,newly added group is '"+ Step3 +"' and Comment is empty " );
						driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[5]/a")).click();

						Thread.sleep(4000);
						String str1=driver.findElement(By.xpath("//*[@id='bcsdw']/table/tbody/tr/td")).getText();
						
						System.out.println("Text found : " + str1);
						
						test.log(Status.INFO, str1);
		        	//	driver.navigate().back();
						break;
		               	}
		           
		        }		  
	     		
	        test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "BrowseDataGroup", test, date1));
			
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Manage_DataGroups_Browse DataGroup  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

public String DeleteDataGroup(WebDriver driver, String Step3,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		
		String url=ApplicaitonUrl;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		//ArrayList aList3= new ArrayList(Arrays.asList(Step3.split(";")));
		
		driver.get(url);
		test.log(Status.INFO, "Login to ECB portal home page "  );
		Thread.sleep(5000);
		int flag=0;
		driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[4]/a/span")).click();
		test.log(Status.INFO, "Click on My Data Groups on the left hand side menu");
		Thread.sleep(2000);

		 List  rows = driver.findElements(By.xpath(".//*[@id='datagroup']/tbody/tr/td[1]")); 
	        System.out.println("No of rows are : " + rows.size());
	        String groupName="";
	 
	     //   int x=1;
	        for (int i=1;i<=rows.size();i++)
	        {  
	        	groupName=driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[1]")).getText();
	        //	groupComment=driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[2]")).getText();
	        	System.out.println(groupName + " --------- " );
	        	
	        	System.out.println(" test data  " + Step3);
	        	
	           	if(groupName.equalsIgnoreCase(Step3)){
	        		test.log(Status.PASS, "In Data Groups list, found group name to delete : '"+ Step3+"' " );
					driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[7]/a")).click();
					
					test.log(Status.INFO, "Click the delete  link");
					Thread.sleep(2000);
					driver.switchTo().alert().accept();
	        		test.log(Status.PASS, "The Selected data group deleted successfully");
	        		Thread.sleep(5000);
	        		flag=1;	
	        		break;
	        	}
	           
	        }
	 
	    		rows = driver.findElements(By.xpath(".//*[@id='datagroup']/tbody/tr/td[1]")); 
	    		System.out.println(" After deleted, now row count is  " + rows.size());
	            for(int i=1;i<=rows.size();i++){
	            	if(driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[1]")).getText().contains(Step3)){
	            		test.log(Status.FAIL, "The data group could not deleted : " + groupName);
	            		TestStatus="FAIL";
	            		flag=1;
	            		break;
	            	}
	            }
	    
	            if(flag==1){
	         		test.log(Status.PASS, "Deleted data group is NOT available in data group list");
	         		
	         	}
        test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "DeleteDataGroup", test, date1));
		
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "Manage_DataGroups_Delete DataGroup  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}


public String EditDataGroup(WebDriver driver, String Step2,String Step5,String Step6,String Step7,String Step8,String Step9,String Step10,String Step11,String email,String Notificationurl, ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		
		driver.get(ApplicaitonUrl);
		test.log(Status.INFO, "Login to ECB portal Home page");
		String TestStatus="";
		Thread.sleep(5000);
	
		driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[4]/a/span")).click();
		test.log(Status.INFO, "Click on My Data Groups on the left hand side menu");
	

		Thread.sleep(3000);
		//No.of rows 
        List  rows = driver.findElements(By.xpath(".//*[@id='datagroup']/tbody/tr/td[1]")); 
        System.out.println("No of rows are : " + rows.size());
        String groupName="";
    
        int x=1;
        for (int i =1;i<rows.size()+2;i++)
        { 
        
        	groupName=driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[1]")).getText();
        //	Edit=driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td["+x+"]/a")).getText();
        	System.out.println( "---------" + groupName);
        	
        
        	if((Step2.equalsIgnoreCase(groupName))){
        	
        		 test.log(Status.PASS, "My Data Groups page is opened and the group is shown :" + Step2);
				 TestStatus= "PASS";
			//	 break;
        	
   
		driver.findElement(By.xpath("//*[@id='datagroup']/tbody/tr["+i+"]/td[6]/a")).click();
				
        test.log(Status.PASS, "Clicked on Edit link of the group is shown :" + Step2);
        Thread.sleep(3000);
        driver.findElement(By.xpath(" //input[@name='name']")).clear();
        driver.findElement(By.xpath(" //input[@name='name']")).sendKeys(Step8);
        
        test.log(Status.PASS, "Changed the name of the Data Group ");
      
        if(driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/table/tbody/tr[2]/td[2]/textarea")).getText().isEmpty()){
        	test.log(Status.PASS, "Check comment of the group  should be empty for group");
        	driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/table/tbody/tr[2]/td[2]/textarea")).sendKeys(Step9);
        	test.log(Status.PASS, "Add comment to the Data Group information ");
         }else{
         	test.log(Status.FAIL, "Check comment of the group is NOT empty for group");
         	TestStatus="FAIL";
         }
        Thread.sleep(3000);
            
        if(driver.findElement(By.xpath("//*[@id='fred']")).isSelected()){
        	test.log(Status.PASS, "Under E-mail Notification event radio button None is selected");
        	driver.findElement(By.xpath("//*[@id='wilma']")).click();
        	test.log(Status.PASS, "Now option 'Time series in data group updated' is selected as update ");
        	
        }else{
        	test.log(Status.FAIL, "Under E-mail Notification event radio button None is NOT selected");
        	TestStatus="FAIL";
        }
        
        
        if(driver.findElement(By.xpath("//*[@id='barney']")).isSelected()){
        	test.log(Status.PASS, "Under Delta File Options Event event radio button 'With link to SDW to browse the updated data' is selected");
        	driver.findElement(By.id("bamm-bamm")).click();
        	test.log(Status.PASS, "now option 'With link to XML delta file' is selected as update");
        	
        }else{
        	test.log(Status.FAIL, "Under Delta File Options Event event radio button 'With link to SDW to browse the updated data' is NOT selected");
        	TestStatus="FAIL";
        }
        
        
        
        if(driver.findElement(By.id("httpNotificationOn")).isSelected()){
        	test.log(Status.PASS, "Under HTTP Notification Event event radio button None is selected");
        	//driver.findElement(By.id("httpNotificationOff")).click();
        	//test.log(Status.PASS, "Now option 'Time series in data group updated' is slected as update");
        	
        }else{
        	test.log(Status.FAIL, "Under HTTP Notification Event event radio button None is NOT selected");
        	TestStatus="FAIL";
        }
              
       driver.findElement(By.name("doSave")).click();
        test.log(Status.PASS, " Clicked on Save button to save the update");
        Thread.sleep(3000);
        break;
 
       }
            
      }
              
        
        Thread.sleep(3000);
        test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Edit Data Group", test, date1));
		
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "Manage_DataGroups_EditDataGroup:  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}


}
