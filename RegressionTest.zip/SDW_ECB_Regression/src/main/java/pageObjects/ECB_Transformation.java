package pageObjects;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Properties;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import managers.FileReaderManager;
import utilities.CommonFunctions;
import utilities.PropertyReader;
import utilities.Screenshots;
public class ECB_Transformation {
	private static final String Else = null;
	Screenshots objCreateScreenshot = new Screenshots();
	CommonFunctions com = new CommonFunctions();
	String TestStatus="PASS";
	 WebElement TabName =null;
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
	 
	// PropertyReader config=new PropertyReader("./config.properties");
	 
	 public String Transformation_WeeklyFrequency(WebDriver driver,String node,String Step2,String Step3,String Step4, ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{ 

			TestStatus="PASS";
			driver.get(node);
			Thread.sleep(3000);
			ArrayList aList3= new ArrayList(Arrays.asList(Step3.split(";")));
			ArrayList aList4= new ArrayList(Arrays.asList(Step4.split(";")));
			
			test.log(Status.PASS, "Login to ECB portal Transformations page ");
			
			Select dropdown = new Select(driver.findElement(By.name("trans")));
			dropdown.selectByVisibleText(Step2);
		
			test.log(Status.PASS, "In the Transformation drop down select : " + Step2 );
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");
			Thread.sleep(5000);
		//	driver.navigate().refresh();
			for(int i=0;i<=2;i++){
				if(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr["+ aList4.get(i)+"]/td[3]")).getText().contains((String) aList3.get(i))){
					test.log(Status.PASS, "In Data Table, in column : "+ Step2 +", in row : " + aList4.get(i)+ " value is : " + (String) aList3.get(i)+" present");
			}else{
				test.log(Status.FAIL, "In Data Table, in column : "+ Step2 +", in row : " + aList4.get(i)+ " value is : " + (String) aList3.get(i)+" NOT present");
				TestStatus="FAIL";
			}
			}
			
		
		
	//	Thread.sleep(1000);
		
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Transformation_WeeklyFrequency", test, date1));	
		
				
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Compare Data Chart:  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}


}
