package pageObjects;

import java.util.ArrayList;
import java.util.Arrays;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import managers.FileReaderManager;
import utilities.CommonFunctions;
import utilities.Screenshots;
public class ECB_Export_Data {
	private static final String Else = null;
	Screenshots objCreateScreenshot = new Screenshots();
	CommonFunctions com = new CommonFunctions();
	String TestStatus="PASS";
	 WebElement TabName =null;
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
	 
	public String DataSet_Link(WebDriver driver,String node, String Step3, ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			String url=ApplicaitonUrl+node;
			System.out.println("url==============ECB_Export_Data==================      "+ url);
			driver.get(url);
			test.log(Status.PASS, "Login to ECB portal and goto node=9701957");
		
			ArrayList aList= new ArrayList(Arrays.asList(Step3.split(",")));
	
			//links available in Available Data Sets table
		 		
		 String Link1= (String) aList.get(0);
		 String Link2= (String) aList.get(1);
		 String Link3= (String) aList.get(2);
				 String text1=driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[1]")).getText();
		 System.out.println(Link1 + "==========================" + text1);
			
		
	if (Link1.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[1]")).getText())&& driver.findElement(By.linkText(Link1)).isDisplayed() ){
		test.log(Status.PASS, Link1+ " links available in Data Set in row 2 col 5");
		TestStatus= "PASS";
	}else{
		test.log(Status.FAIL, Link1+ " links NOT available in Data Set in row 2 col 5");
		TestStatus= "FAIL";
	}
	
	if (Link2.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[2]")).getText())&& driver.findElement(By.linkText(Link2)).isDisplayed() ){
		test.log(Status.PASS, Link2+ " links available in Data Set in row 2 col 5");
		TestStatus= "PASS";
	}else{
		test.log(Status.FAIL, Link2+ " links NOT available in Data Set in row 2 col 5");
		TestStatus= "FAIL";
	}
	
	if (Link3.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[3]")).getText())&& driver.findElement(By.linkText(Link3)).isDisplayed() ){
		test.log(Status.PASS, Link3+ " links available in Data Set in row 2 col 5");
		TestStatus= "PASS";
	}else{
		test.log(Status.FAIL, Link3+ " links NOT available in Data Set in row 2 col 5");
		TestStatus= "FAIL";
	}
	
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "DataSet_Link", test, date1));
				
				
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Links are NOT available in Data Set in row 2 col 5 :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

    public String Export_Data_DownloadCSV(WebDriver driver,String node, String Step4, ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			String url=ApplicaitonUrl+node;
			System.out.println("url==============ECB_Export_Data==================      "+ url);
			driver.get(url);
			test.log(Status.PASS, "Login to ECB portal and goto node=9701957");
			com.DeleteFile(System.getProperty("user.dir") + "\\DownloadFolder\\", "data.csv");

			//Turn off the check box for ILM in available datasets table

			driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[2]/td[1]/input")).click();
			test.log(Status.PASS, "Turn off the check box for ILM in available datasets table");
			//*[@id="toolBar"]/tbody/tr/td[7]/span  
			
			Thread.sleep(5000);
		//	driver.findElement(By.partialLinkText("Download Data")).click();
			driver.findElement(By.xpath("//div[@id='dataSelectionContentId']/div/table[@id='toolBar']/tbody/tr/td[7]/span")).click();
			Thread.sleep(2000);
			test.log(Status.PASS, "Click on Download Data link on top of the page");
		
			driver.findElement(By.xpath("//*[@id='exportOptions']/a[1]")).click();;
			test.log(Status.PASS, "Click on link CSV-Character Separated");
			
			Thread.sleep(1000);
			test.log(Status.PASS, "Data.csv file download successfully");
			
			String path1=System.getProperty("user.dir") + "\\src\\test\\java\\TestData\\";
			String path2=System.getProperty("user.dir") + "\\DownloadFolder\\";
			
			String str=com.comparing_csv_files("Masterdata.csv",path1,"data.csv",path2);
			System.out.println("===================================="+ str);
		//test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				if(str.contains("PASS")){
					test.log(Status.PASS, "Found NO differences between csv files.");
				}else{
					test.log(Status.FAIL,  str);
					TestStatus="FAIL";
				}
				
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Compare downloaded CSV file:  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}


}
