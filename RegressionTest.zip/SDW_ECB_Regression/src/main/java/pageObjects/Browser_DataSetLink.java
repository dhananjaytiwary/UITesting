package pageObjects;

import java.util.ArrayList;
import java.util.Arrays;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import utilities.Screenshots;
public class Browser_DataSetLink {
	Screenshots objCreateScreenshot = new Screenshots();
	//CommonFunctions com = new CommonFunctions();
	String TestStatus="";
	 WebElement TabName =null;
	 
	public String DataSet_Link(WebDriver driver,String url, String Step3, ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			
			driver.get(url);
			test.log(Status.PASS, "Login to ECB portal and goto node=9701956");
			String TestStatus="";
			ArrayList aList= new ArrayList(Arrays.asList(Step3.split(",")));
	
			//links available in Available Data Sets table
		 		
		 String Link1= (String) aList.get(0);
		 String Link2= (String) aList.get(1);
		 String Link3= (String) aList.get(2);
				 String text1=driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[1]")).getText();
		 System.out.println(Link1 + "==========================" + text1);
			
		
	if (Link1.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[1]")).getText())&& driver.findElement(By.linkText(Link1)).isDisplayed() ){
		test.log(Status.PASS, Link1+ " links available in Data Set in row 2 col 5");
		TestStatus= "PASS";
	}else{
		test.log(Status.FAIL, Link1+ " links NOT available in Data Set in row 2 col 5");
		TestStatus= "FAIL";
	}
	
	if (Link2.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[2]")).getText())&& driver.findElement(By.linkText(Link2)).isDisplayed() ){
		test.log(Status.PASS, Link2+ " links available in Data Set in row 2 col 5");
		TestStatus= "PASS";
	}else{
		test.log(Status.FAIL, Link2+ " links NOT available in Data Set in row 2 col 5");
		TestStatus= "FAIL";
	}
	
	if (Link3.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[3]")).getText())&& driver.findElement(By.linkText(Link3)).isDisplayed() ){
		test.log(Status.PASS, Link3+ " links available in Data Set in row 2 col 5");
		TestStatus= "PASS";
	}else{
		test.log(Status.FAIL, Link3+ " links NOT available in Data Set in row 2 col 5");
		TestStatus= "FAIL";
	}
	
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				
				
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Links are NOT available in Data Set in row 2 col 5 :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	//private String aList(int i) {
		// TODO Auto-generated method stub
	//	return null;
	//}


}
