package pageObjects;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
//import java.awt.Color;
import java.util.StringTokenizer;

import org.apache.poi.hssf.record.PageBreakRecord.Break;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import managers.FileReaderManager;
import utilities.CommonFunctions;
import utilities.PropertyReader;
import utilities.Screenshots;
public class ECB_Browser_Node {
	Screenshots objCreateScreenshot = new Screenshots();
	CommonFunctions com = new CommonFunctions();
	//PropertyReader CenterPage=new PropertyReader("src/main/java/pageObjects/SDW_CenterPage.properties");
	 String fieldvalue1="";
	 String TestStatus="PASS";
	 WebElement TabName =null;
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
	 
//  @FindBy(xpath="") WebElement serchbox;
  
	 public String ECB_HomePage(WebDriver driver,ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
			//	String TestStatus;
				driver.get(ApplicaitonUrl);
				 
				 test.log(Status.PASS, "Open ECB Portal Home page");
								 
				Thread.sleep(2000);
				
				 
				if (driver.findElement(By.xpath("//*[@id='q']")).isDisplayed()) {
					test.log(Status.PASS, "SDW Search text box availabe on page ");
					
				}else{
					test.log(Status.FAIL, "SDW Search text box NOT availabe on page ");
					TestStatus= "FAIL";
				}
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				   
				return TestStatus;
						
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, "verify ECB Portal Home page Test FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}
 	 
	public String Dataset_series(WebDriver driver,String node, String BGColor_Step3,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Browser_Node===================      "+ url);
			driver.get(url);
			 
			 test.log(Status.PASS, "Open ECB Portal and node=9701956");
			 
			 String bgcolor=BGColor_Step3.replaceAll("\\s+","");
			 
			Thread.sleep(2000);
			 String color = driver.findElement(By.xpath("//*[contains(text(),'Dataset contains other series')]")).getCssValue("background-color");
			 test.log(Status.PASS, "Search Text : Dataset contains other series and it expecting BGColor" + BGColor_Step3);
			 		
			 String bckgclr = com.HexColor(color);
		
		//	 Assert.assertEquals(bckgclr,bgcolor);
			 
			if (bckgclr.equalsIgnoreCase(bgcolor)) {
				test.log(Status.PASS, "Text Background color matched with expected Background color:  PASS ");
				
			}else{
				test.log(Status.FAIL, "Expecting BGColor:  '" +BGColor_Step3 + "'  However found :  '" + bckgclr +"'");
				TestStatus= "FAIL";
			}
			return TestStatus;
			
	
			
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "verify Dataset_series:  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}
	 
	public String reference_series(WebDriver driver, String Step4,String Step5,String Step6,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
			try{
		
				
				System.out.println("url=============ECB_Browser_Node===================      ");
				
			
		//======================Test STEP 4=======================
				String str =Step4;
				ArrayList aList= new ArrayList(Arrays.asList(str.split(",")));
				
				Thread.sleep(2000);
				//In the reference series checkbox is not selected in row 2 col 1
				 WebElement webElement=driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input"));
			        if (webElement.isSelected()){
			        	 test.log(Status.FAIL, " Verified reference series checkbox is selected in row 2 column 1 ");
			        }else{
			        	test.log(Status.PASS, " Verified reference series checkbox is not selected in row 2 column 1 ");
			        }	
			  
			  //reference series in row 2 all column should be background color = #99ccff      
			    for(int i=1;i<8;i++){    
			        
			     String color = driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td["+i+"]")).getCssValue("background-color");
				 String bckgclr = com.HexColor(color);
				 String bgcolor=(String) aList.get(0);
			        
			 
				if (bckgclr.equalsIgnoreCase(bgcolor)) {
					test.log(Status.PASS, "reference series table row 2 columns "+ i +" background color:  PASS ");
					
				}else{
					test.log(Status.FAIL, "Expecting BGColor:  '" +bgcolor + "'  However found :  '" + bckgclr +"'");
					TestStatus= "FAIL";
					break;
				}
			   }
			        
			    JavascriptExecutor js = (JavascriptExecutor) driver;
				 js.executeScript("window.scrollBy(0,700)");
				
		//In the reference series link DD_TST.B.AT.IR_L.AVG.RT is present  in row 2 col 2
			  
			    String row2col2= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[2]/a/span")).getText();
		//	    System.out.println("=========================== " +row2col2);
			    String row2link2=(String) aList.get(1);
			//    System.out.println("=========================== " +row2link2);
			   
			    if (row2col2.equalsIgnoreCase(row2link2)){   //DD_TST.B.AT.IR_L.AVG.RT
			    	test.log(Status.PASS, "reference series Text DD_TST.B.AT.IR_L.AVG.RT is present in row 2 col 2 ");
			    	WebElement linkName=driver.findElement(By.linkText(row2col2));
			    	
			    	if(linkName.isDisplayed())
			    	{
			    		test.log(Status.PASS, "reference series Link DD_TST.B.AT.IR_L.AVG.RT is present ");
			    		
			    	}
			    	else
			    	{
			    		test.log(Status.FAIL, "reference series Link DD_TST.B.AT.IR_L.AVG.RT is not present ");
			    		TestStatus= "FAIL";
			    	}
			    	
			    }else{
			    	test.log(Status.FAIL, "reference series Text DD_TST.B.AT.IR_L.AVG.RT is NOT present  in row 2 col 2 ");
		    		TestStatus= "FAIL";
			    }
			    
			    //In the reference series text DD_TST.B.AT.IR_L.AVG.RT and series on SDW Public link is present  in row 2 col 4
			    WebElement text= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[4]"));
			    String row2col4=text.getText();
			    
		//	    System.out.println("=========================== " +row2col4);
			    String row2link4=(String) aList.get(2);
		//	    System.out.println("=========================== " +row2link4);
			   
			    if (row2col4.contains(row2col4)){   //DD_TST.B.AT.IR_L.AVG.RT
			    	test.log(Status.PASS, "reference series Text DD_TST.B.AT.IR_L.AVG.RT is present  in row 2 col 4 ");
			    	WebElement linkName=driver.findElement(By.linkText(row2link4));
			    	
			    	if(linkName.isDisplayed())
			    	{
			    		test.log(Status.PASS, "series on SDW Public link is present  in row 2 col 4 ");
			    		
			    	}
			    	else
			    	{
			    		test.log(Status.FAIL, "series on SDW Public link is present  in row 2 col 4");
			    		TestStatus= "FAIL";
			    	}
			    	
			    }else{
			    	test.log(Status.FAIL, "reference series Text DD_TST.B.AT.IR_L.AVG.RT is NOT present  in row 2 col 4 ");
		    		TestStatus= "FAIL";
			    }
			    
			    //In the reference series value "02 Jan 1986" is present  in row 2 col 5
			    
			    String row2col5= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[5]")).getText();
			    String row2date5=(String) aList.get(3);
					   
			    if (row2col5.equalsIgnoreCase(row2date5)){  
			    	test.log(Status.PASS, "reference series value 02 Jan 1986 is present  in row 2 col 5 ");
			    				    			    	
			    }else{
			    	test.log(Status.FAIL, "reference series value 02 Jan 1986 is NOT present  in row 2 col 5 ");
		    		TestStatus= "FAIL";
			    }
			    
			    //In the reference series value "06 Dec 2016" is present  in row 2 col 6
			    String row2col6= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[6]")).getText();
			    String row2date6=(String) aList.get(4);
				   
			    if (row2col6.equalsIgnoreCase(row2date6)){   
			    	test.log(Status.PASS, "reference series value 06 Dec 2016 is present  in row 2 col 6 ");
			    				    			    	
			    }else{
			    	test.log(Status.FAIL, "reference series value 06 Dec 2016 is NOT present  in row 2 col 6 ");
		    		TestStatus= "FAIL";
			    }
			    
			 //=======================Test Step 5========Published Series===================
				String str4 =Step5;
				ArrayList aList4= new ArrayList(Arrays.asList(str4.split(",")));
				
				//In the Published series checkbox is not selected in row 3 col 1
				 WebElement webElement1=driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input"));
			        if (webElement1.isSelected()){
			        	 test.log(Status.FAIL, " Verified Published series checkbox is selected in row 3 column 1 ");
			        }else{
			        	test.log(Status.PASS, " Verified Published series checkbox is not selected in row 3 column 1 ");
			        }	
			  
			  //Published series in row 2 all column should be background color = #99ccff      
			    for(int i=1;i<8;i++){    
			        
			     String color = driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td["+i+"]")).getCssValue("background-color");
				 String bckgclr = com.HexColor(color);
				 String bgcolor=(String) aList4.get(0);
			        
			 
				if (bckgclr.equalsIgnoreCase(bgcolor)) {
					test.log(Status.PASS, "Published series table row 3 columns "+ i +" background color:  PASS ");
					
				}else{
					test.log(Status.FAIL, "Expecting BGColor:  '" +bgcolor + "'  However found :  '" + bckgclr +"'");
					TestStatus= "FAIL";
					break;
				}
			   }
			        
			 //In the Published series link DD_TST.B.AT.IR_L.AVG.RT is present  in row 2 col 2
			  
			    String row3col2= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[2]/a/span")).getText();
			  
			    String row3link2=(String) aList4.get(1);
		
			   
			    if (row3col2.equalsIgnoreCase(row3link2)){   //DD_TST.B.AT.IR_L.AVG.RT
			    	test.log(Status.PASS, "Published series Text '" +row3col2 + "' is present  in row 3 col 2 ");
			    	WebElement linkName=driver.findElement(By.linkText(row3col2));
			    	
			    	if(linkName.isDisplayed())
			    	{
			    		test.log(Status.PASS, "Published series Link '" +row3col2 + "' is present ");
			    		
			    	}
			    	else
			    	{
			    		test.log(Status.FAIL, "Published series Link '" +row3col2 + "' is not present ");
			    		TestStatus= "FAIL";
			    	}
			    	
			    }else{
			    	test.log(Status.FAIL, "Published series Text '" +row3col2 + "' is NOT present  in row 3 col 2 ");
		    		TestStatus= "FAIL";
			    }
			    
			    //row 3 col 4  -  BGColor  #cce6ff - value exists DD_TST.B.D2.IR_S.AVG.4F5B
			    WebElement text4= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[4]"));
			    String row3col4=text4.getText();
			    
			 
			    String row3link4=(String) aList4.get(2);
	
			   
			    if (row3col4.contains(row3link4)){ 
			    	test.log(Status.PASS, "Published series Text '" +row3col4 + "' is present  in row 3 col 4 ");
			    				    	
			    }else{
			    	test.log(Status.FAIL, "Published series Text '" +row3col4 + "' is NOT present  in row 3 col 4 ");
		    		TestStatus= "FAIL";
			    }
			    
			    //row 3 col 5 -  BGColor  #cce6ff - value exists "04 Jan 1989"
			    
			    String row3col5= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[5]")).getText();
			   // System.out.println("=========================== " +row3col5);
			    String row3date5=(String) aList4.get(3);
			   // System.out.println("=========================== " +row3date5);
			   
			    if (row3col5.equalsIgnoreCase(row3date5)){  
			    	test.log(Status.PASS, "Published series value '" +row3col5 + "' is present  in row 3 col 5 ");
			    				    			    	
			    }else{
			    	test.log(Status.FAIL, "Published series value '" +row3col5 + "' is NOT present  in row 3 col 5 ");
		    		TestStatus= "FAIL";
			    }
			    
			    //In the Published series value "06 Dec 2016" is present  in row 2 col 6
			    String row3col6= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[6]")).getText();
		
			    String row3date6=(String) aList4.get(4);
		
			   
			    if (row3col6.equalsIgnoreCase(row3date6)){   
			    	test.log(Status.PASS, "Published series value '" +row3col6 + "' is present  in row 3 col 6 ");
			    				    			    	
			    }else{
			    	test.log(Status.FAIL, "Published series value '" +row3col6 + "' is NOT present  in row 3 col 6 ");
		    		TestStatus= "FAIL";
			    }
			    
			    
			    //=======================Test Step 6============Other Series===============    
				String str6 =Step6;
				ArrayList aList6= new ArrayList(Arrays.asList(str6.split(",")));
				
				//In the Other series checkbox is not selected in row 3 col 1
				 WebElement webElement6=driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input"));
			        if (webElement6.isSelected()){
			        	 test.log(Status.FAIL, " Verified Other series checkbox is selected in row 4 column 1 ");
			        }else{
			        	test.log(Status.PASS, " Verified Other series checkbox is not selected in row 4 column 1 ");
			        }	
			  
			  //Other series in row 3 all column should be background color =    
			    for(int i=1;i<8;i++){    
			        
			     String color = driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td["+i+"]")).getCssValue("background-color");
				 String bckgclr = com.HexColor(color);
				 String bgcolor=(String) aList6.get(0);
			        
			 
				if (bckgclr.equalsIgnoreCase(bgcolor)) {
					test.log(Status.PASS, "Other series table row 4 columns "+ i +" background color:  PASS ");
					
				}else{
					test.log(Status.FAIL, "Expecting BGColor:  '" +bgcolor + "'  However found :  '" + bckgclr +"'");
					TestStatus= "FAIL";
					break;
				}
			   }
			        
			 //In the Other series link DD_TST.B.AT.IR_L.AVG.RT is present  in row 2 col 2
			  //*[@id="seriesListTable"]/tbody/tr[3]/td[2]/b
			    String row4col2= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td[2]/a/span")).getText();
			 //   String row4col2= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td[2]/b")).getText();
			    String row4link2=(String) aList6.get(1);
			
			   
			    if (row4col2.contains(row4link2)){   
			    	test.log(Status.PASS, "Other series Text '"+ row4col2 +"' is present  in row 4 col 2 ");
			  
			    }else
			    	{
			    		test.log(Status.FAIL, "Other series Text '"+ row4col2 +"' is NOT present  in row 4 col 2 ");
			    		TestStatus= "FAIL";
			    	}
			    	
		
			    //row 3 col 4  -  BGColor  #cce6ff - value exists DD_TST.B.D2.IR_S.AVG.4F5B
			    WebElement text6= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td[4]"));
			    String row4col4=text6.getText();
			 
			    String row4link4=(String) aList6.get(2);
			   // System.out.println("=========================== " +row3link4);
			   
			    if (row4col4.contains(row4link4)){ 
			    	test.log(Status.PASS, "Other series Text '"+ row4col4 + "' is present  in row 4 col 4 ");
			    				    	
			    }else{
			    	test.log(Status.FAIL, "Other series Text '"+ row4col4 + "' is NOT present  in row 4 col 4  ");
		    		TestStatus= "FAIL";
			    }
			    
			    //row 3 col 5 -  BGColor  #cce6ff - value exists "04 Jan 1989"
			    
			    String row4col5= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td[5]")).getText();
		
			    String row4date5=(String) aList6.get(3);
					   
			    if (row4col5.equalsIgnoreCase(row4date5)){  
			    	test.log(Status.PASS, "Other series value '"+ row4col5 +"' is present  in row 4 col 5 ");
			    				    			    	
			    }else{
			    	test.log(Status.FAIL, "Other series value '"+ row4col5 +"' is NOT present  in row 4 col 5 ");
		    		TestStatus= "FAIL";
			    }
			    
			    //In the Other series value "06 Dec 2016" is present  in row 2 col 6
			    String row4col6= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[3]/td[6]")).getText();
			    String row4date6=(String) aList6.get(4);
		   
			    if (row4col6.equalsIgnoreCase(row4date6)){   
			    	test.log(Status.PASS, "Other series value '"+ row4col6 +"' is present  in row 4 col 6 ");
			    				    			    	
			    }else{
			    	test.log(Status.FAIL, "Other series value '"+ row4col6 +"' is present  in row 4 col 6");
		    		TestStatus= "FAIL";
			    }
			    test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "reference_series", test, date1));
			    //=======================TEST STEP 7
			return TestStatus;	
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, "verify reference_series :  FAIL ");
			
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}

	public String DD_TST_Frequency(WebDriver driver,String node, String Step7,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Browser_Node===================      ");
			driver.get(url);
			String Stepstr =Step7;
		//	String TestStatus="";
			ArrayList aList7= new ArrayList(Arrays.asList(Stepstr.split(",")));
			 
	  	 test.log(Status.PASS, "In Dimension Filte section verify Cube DD_TST Table fields values.");
	  	JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,500)");
		 
	
			Thread.sleep(5000);

			driver.findElement(By.xpath("//*[@id='s2id_autogen1']")).click();;
			Thread.sleep(3000);
			 for(int i=1;i<4;i++){
				 WebElement webElement=driver.findElement(By.xpath("//*[@id='select2-drop']/ul/li["+i+"]"));
					
			 	String list=(String) aList7.get(i-1);
				 
			 if (Step7.contains(list)) {
					fieldvalue1=fieldvalue1+","+list;
				 
		 	}else{
		 		test.log(Status.FAIL, list+ " Not Found in Frequency (2) field list  ");
		 		TestStatus= "FAIL";
		 		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "DD_TST_Frequency", test, date1));
		   }
			 } 
			 test.log(Status.PASS, fieldvalue1 + " values found in Frequency (2) field list");
			 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "DD_TST_Frequency", test, date1));
		
			 Thread.sleep(3000);
			 System.out.println("I am in END IN Frequency (2) =====================");
				//	driver.get(url);
				
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "verify DD_TST_Frequency :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	public String DD_TST_transformation(WebDriver driver,String node, String Step7,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	 //Derived data transformation (3) with value All [ANN]           - Annualisation (1) [AVG] Average (30) [LEV] Level (10)
		try{
			System.out.println("url=============ECB_Browser_Node===================");
			System.out.println("I am in Derived data transformation (3) =====================");
			String url=ApplicaitonUrl+node;
			driver.get(url);
			String Stepstr =Step7;
			
			ArrayList aList7= new ArrayList(Arrays.asList(Stepstr.split(",")));
				 
				Thread.sleep(5000);
				 JavascriptExecutor js = (JavascriptExecutor) driver;
				 js.executeScript("window.scrollBy(0,300)");
				 fieldvalue1="";
			//	TabName = driver.findElement(By.xpath("//*[@id='tabs']/li[2]/a"));
				driver.findElement(By.xpath("//*[@id='s2id_autogen4']")).click();;
				
				//TabName.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.ENTER);
				System.out.println("I am in Derived dat.........");
				Thread.sleep(3000);
								
				 for(int i=1;i<5;i++){
					 WebElement webElement=driver.findElement(By.xpath("//*[@id='select2-drop']/ul/li["+i+"]"));
			
				 	String list1=(String) aList7.get(i+2);
					 
				 if (Step7.contains(list1)) {
						fieldvalue1=fieldvalue1+","+list1;
					 
			 	}else{
			 		test.log(Status.FAIL, list1+ " Not Found in Derived data transformation (3) field list  ");
			 		TestStatus= "FAIL";
			 		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "D_TST_transformation", test, date1));
			   }
				 } 
				 test.log(Status.PASS, fieldvalue1 + " values found in Derived data transformation (3)  field list");
					test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "D_TST_transformation", test, date1));
				
				 Thread.sleep(3000);
				 
				 System.out.println("I am END  IN Derived data transformation (3) =====================");
				 
			return TestStatus;
			
	
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "verify DD_TST_transformation value not available: :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}
	
	public String DD_TST_suffix(WebDriver driver,String node, String Step7,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			//Derived data suffix (4) with value All [4F5B] BIS series used in ECB function (12) [4FRT] REUTERS series used in ECB function (10) [5B] BIS (12) [RT] Reuters (7)
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Browser_Node===================      "+ url);
			
			driver.get(url);
			String Stepstr =Step7;
			
			ArrayList aList7= new ArrayList(Arrays.asList(Stepstr.split(",")));
		
			Thread.sleep(5000);
			//TabName = driver.findElement(By.xpath("//*[@id='tabs']/li[2]/a"));
			//TabName.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.ENTER);
			 JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("window.scrollBy(0,600)");
			 
			driver.findElement(By.xpath("//*[@id='s2id_autogen5']")).click();;
				Thread.sleep(3000);
				fieldvalue1="";
						
					 for(int i=1;i<6;i++){
						 WebElement webElement=driver.findElement(By.xpath("//*[@id='select2-drop']/ul/li["+i+"]"));
					 	System.out.println(webElement.getText());
					
					 	String list2=(String) aList7.get(i+6);
						 
					 if (Step7.contains(list2)) {
							fieldvalue1=fieldvalue1+","+list2;
						 
				 	}else{
				 		test.log(Status.FAIL, list2+ " Not Found in Derived data suffix (4) field list  ");
				 		TestStatus= "FAIL";
				 		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Derived data suffix", test, date1));
				   }
					 } 
					 test.log(Status.PASS, fieldvalue1 + " values found in Derived data suffix (4) field list");
				 
					 Thread.sleep(3000);
					 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Derived data suffix", test, date1));
					
			return TestStatus;
			
	
			
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "verify Derived data suffix (4) field value not available:  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	public String QSA_TST_Frequency(WebDriver driver,String node, String Step8,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		String url=ApplicaitonUrl+node;
		System.out.println("url=============ECB_Browser_Node===================      "+ url);
		driver.get(url);
		String Stepstr =Step8;
	//	String TestStatus="PASS";
		ArrayList aList8= new ArrayList(Arrays.asList(Stepstr.split(",")));
		
  	 test.log(Status.PASS, "In Dimension Filte section verify Cube DD_TST Table fields values.");
  	JavascriptExecutor js = (JavascriptExecutor) driver;
	 js.executeScript("window.scrollBy(0,300)");
	 
	//	 Frequency (2) with value All [B] Business (16) [D] Daily (25)  //*[@id="select2-drop"]   //*[@id='tabs']/li[2]/a
	    String list1="";
		
	    Thread.sleep(8000);
		driver.findElement(By.xpath("//*[@id='tabs']/li[2]/a")).click();
		Thread.sleep(5000);
		
		
		String Frequency = driver.findElement(By.xpath("//*[@id='mdAttrib3']/div[1]/div/div/ul/li/div")).getText();
	
		System.out.println("Frequency  " + Frequency);
		String Adjustment = driver.findElement(By.xpath("//*[@id='mdAttrib3']/div[2]/div/div/ul/li/div")).getText();
		System.out.println("Adjustment  " + Adjustment);
		String Counterpart = driver.findElement(By.xpath("//*[@id='mdAttrib3']/div[4]/div/div/ul/li/div")).getText();
		System.out.println("Counterpart  " + Counterpart);
	    
		Thread.sleep(3000);
		System.out.println("===============================");
		
		String list=(String) aList8.get(0);
		
		if (Frequency.contentEquals((String) aList8.get(0))){
			test.log(Status.PASS, "Frequency (1) with value [Q] Quarterly" );
			 
		}else{
			TestStatus= "FAIL";
			test.log(Status.FAIL, "Frequency (1) is Not with value [Q] Quarterly " );}
		
		if (Adjustment.contentEquals((String) aList8.get(1))){
			test.log(Status.PASS, "Adjustment indicator (1) with value [N]" );
			 
		}else{
			TestStatus= "FAIL";
			test.log(Status.FAIL, "Adjustment indicator (1) is not with value [N] " );}
		
		String Counterpart1=(String) aList8.get(2);
		System.out.println("Counterpart1:"+ Counterpart1);
		
		if (Counterpart.contentEquals((String) aList8.get(2))){
			test.log(Status.PASS, "Counterpart area (1) with value [W0] World" );
			 
		}else{
			TestStatus= "FAIL";
			test.log(Status.FAIL, "Counterpart area (1) is not with value [W0] World" );}
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "QSA_TST_Frequency", test, date1));	
		

		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "QSA_TST_Frequency", test, date1));
		test.log(Status.FAIL, "verify QSA_TST_Frequency :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}

	public String Reference_area(WebDriver driver,String node, String Step9,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	 //Derived data transformation (3) with value All [ANN]           - Annualisation (1) [AVG] Average (30) [LEV] Level (10)
		try{
		//	System.out.println("I am in Reference_area========Start=============");
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Browser_Node===================      "+ url);
			driver.get(url);
			String Stepstr =Step9;
			
								
			ArrayList aList9= new ArrayList(Arrays.asList(Stepstr.split(",")));
			String CYText=(String) aList9.get(0);
			String seriestext=(String) aList9.get(1);
			String seriestext2=(String) aList9.get(2);
			
				Thread.sleep(4000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				 js.executeScript("window.scrollBy(0,300)");
		
		//		TabName = driver.findElement(By.xpath("//*[@id='tabs']/li[1]/a"));
		//		TabName.sendKeys(Keys.ENTER,Keys.TAB,Keys.TAB,Keys.TAB,Keys.ENTER);
				//*[@id="s2id_autogen141"]  s2id_autogen1
				 driver.findElement(By.xpath("//*[@id='s2id_autogen2']")).click();;
					Thread.sleep(3000);
		
			
		
				for(int i=1;i<10;i++){
					 
					 WebElement webElement=driver.findElement(By.xpath("//*[@id='select2-drop']/ul/li["+i+"]"));
					 String listname=webElement.getText();
		
					 if (listname.contains(CYText)){
					
					 	 webElement.click();
						 Thread.sleep(2000);
						 test.log(Status.PASS, " [CY] Cyprus (1) selected in Reference area (21) field");

						WebElement element = driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[3]/a"));
						Actions actions = new Actions(driver);
						actions.moveToElement(element).click().perform();
			
						 js.executeScript("window.scrollBy(0,600)");
						 Thread.sleep(8000);  							 
						 String seriestext1= driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[2]/a/span")).getText();
					
				System.out.println("seriestext1......" + seriestext1);
		
						
						if(seriestext.contains(seriestext1)){ // DD_TST.D.CY.CYP_EUR.LEV.5B
							 test.log(Status.PASS, seriestext + " values found in serics table");
							 			 						 
					    }else{
							test.log(Status.FAIL, seriestext + " values NOT found in serics table");
							TestStatus= "FAIL";
							test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Reference_area", test, date1));
							
						}
						if(driver.getPageSource().contains(seriestext2)) // DD_TST.B.AT.IR_L.AVG.RT
						{ 	
							test.log(Status.FAIL, seriestext2 + " values found in serise table");
							TestStatus= "FAIL"; 
						 
						}else{
							test.log(Status.PASS, seriestext2 + " values Not found in serics table");
							 
							 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Reference_area", test, date1));
						}
						
						 break;
						 
					 }
				
				 } 
				
				 test.log(Status.PASS, fieldvalue1 + " values found in Derived data transformation (3)  field list");
				//	test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				
				 Thread.sleep(1000);
				 
				 System.out.println("I am in Reference_area=========END============");
				 
			return TestStatus;
			
	
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "verify filed Reference Area text box:  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	public String MetaData_Table(WebDriver driver,String node, String Step4, String Step5,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Browser_Node===================      "+ url);
			driver.get(url);
			test.log(Status.PASS, "Login to ECB portal and goto node=9701956");
		//	String TestStatus="PASS";
	//  	JavascriptExecutor js = (JavascriptExecutor) driver;
	//	 js.executeScript("window.scrollBy(0,500)");
		
		 		
		 driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[2]/a")).click();
		 Thread.sleep(5000);
		 test.log(Status.PASS, "Click the link MetaData on the top links section");
		
		 
		 driver.findElement(By.xpath("//*[@id='datasetLevelMetadata1']/h2[1]/img")).click();
		 test.log(Status.PASS, "Click on the Header DD_TST - Test Derived Data is available under Dataset Level Metadata table");
		 
		//*[@id="datasetLevelMetadata1"]/h2[2]/img
		 
		 driver.findElement(By.xpath("//*[@id='datasetLevelMetadata1']/h2[2]/img")).click();
		 test.log(Status.PASS, "Click on the Header QSA_TST - Test Quarterly Sector Accounts under Dataset Level Metadata table");
		 
		 
		String DD_TST_LastUpdate= driver.findElement(By.xpath("//*[@id='DD_TST - Test Derived Data']/table/tbody/tr[3]/td[2]")).getText();
		System.out.println("last update date : " + DD_TST_LastUpdate);
		String DD_TST_SDWText= driver.findElement(By.xpath("//*[@id='DD_TST - Test Derived Data']/table/tbody/tr[3]/td[3]")).getText();
		System.out.println("last update date : " + DD_TST_LastUpdate);
		
		String QSA_TST_LastUpdate= driver.findElement(By.xpath("//*[@id='QSA_TST - Test Quarterly Sector Accounts (MUFA and NFA Eurostat ESA2010 TP, table 801)']/table/tbody/tr[3]/td[3]")).getText();
		System.out.println("last update date : " + QSA_TST_LastUpdate);
		String QSA_TST_SDWText= driver.findElement(By.xpath("//*[@id='QSA_TST - Test Quarterly Sector Accounts (MUFA and NFA Eurostat ESA2010 TP, table 801)']/table/tbody/tr[3]/td[2]")).getText();
		System.out.println("last update date : " + QSA_TST_LastUpdate);
		
		
		//*[@id="DD_TST - Test Derived Data"]/table/tbody/tr[3]/td[2]
		
	if (DD_TST_LastUpdate.isEmpty() && DD_TST_SDWText.isEmpty() ){
		test.log(Status.FAIL, "QSA_TST_LastUpdate and Text 'Dataset last update in SDW' is NOT missing ");
		TestStatus= "FAIL";
	}else{
		test.log(Status.PASS, "QSA_TST_LastUpdate and Text 'Dataset last update in SDW' is avilable ");
		
	}
	
	if (QSA_TST_LastUpdate.isEmpty() && QSA_TST_SDWText.isEmpty() ){
		test.log(Status.FAIL, "DD_TST_LastUpdate and Text 'Dataset last update in SDW' is NOT missing ");
		TestStatus= "FAIL";
	}else{
		test.log(Status.PASS, "DD_TST_LastUpdate and Text 'Dataset last update in SDW' is avilable ");
		
	}
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Backgroup colo", test, date1));
				
				 
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "verify Backgroup color Not Matched :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	public String MetaData_NonAccessibleData(WebDriver driver,String node, String Step2,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Browser_Node===================      "+ url);
			driver.get(url);
			test.log(Status.PASS, "Login to ECB portal and goto node=5275746");
		//	String TestStatus="";

		if (driver.getPageSource().contains("No data is available")){
			test.log(Status.PASS, "No data is available in Metadata for non-accessible data");
			
		}else{
			test.log(Status.PASS, "Data available in Metadata for non-accessible data ");
			TestStatus= "FAIL";	
			
		}
		 				
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "non-accessible data", test, date1));
				
				 
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, " Metadata for non-accessible data Test :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}
	 	 
	public String DataSet_Link(WebDriver driver,String node, String Step3, ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Browser_Node===================      "+ url);
			driver.get(url);
			test.log(Status.PASS, "Login to ECB portal and goto node=9701957");
	//		String TestStatus="";
			ArrayList aList= new ArrayList(Arrays.asList(Step3.split(",")));
	
			//links available in Available Data Sets table
		 		
		 String Link1= (String) aList.get(0);
		 String Link2= (String) aList.get(1);
		 String Link3= (String) aList.get(2);
				 String text1=driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[1]")).getText();
		 System.out.println(Link1 + "==========================" + text1);
			
		
	if (Link1.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[1]")).getText())&& driver.findElement(By.linkText(Link1)).isDisplayed() ){
		test.log(Status.PASS, Link1+ " links available in Data Set in row 2 col 5");
		
	}else{
		test.log(Status.FAIL, Link1+ " links NOT available in Data Set in row 2 col 5");
		TestStatus= "FAIL";
	}
	
	if (Link2.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[2]")).getText())&& driver.findElement(By.linkText(Link2)).isDisplayed() ){
		test.log(Status.PASS, Link2+ " links available in Data Set in row 2 col 5");
		
	}else{
		test.log(Status.FAIL, Link2+ " links NOT available in Data Set in row 2 col 5");
		TestStatus= "FAIL";
	}
	
	if (Link3.equalsIgnoreCase(driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr[1]/td[5]/table/tbody/tr/td/a[3]")).getText())&& driver.findElement(By.linkText(Link3)).isDisplayed() ){
		test.log(Status.PASS, Link3+ " links available in Data Set in row 2 col 5");
		
	}else{
		test.log(Status.FAIL, Link3+ " links NOT available in Data Set in row 2 col 5");
		TestStatus= "FAIL";
	}
	
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "non-accessible", test, date1));
				
				
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Links are NOT available in Data Set in row 2 col 5 :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}
	
	public String Data_Table(WebDriver driver,String node, String Step5, String Step6, String Step7, String Step8, String Step9, String Step11,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Browser_Node===================      "+ url);
			driver.get(url);
			test.log(Status.PASS, "Login to ECB portal and goto node=9701956");
			String TestStatus="PASS";
			ArrayList aList8= new ArrayList(Arrays.asList(Step8.split(",")));
		
			
	  	 test.log(Status.PASS, "Check the check boxes for the first 2 series in the series table");
	  	JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,500)");
		
		 		
		 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input")).click();
		 Thread.sleep(1000);
		 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input")).click();
	//	 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		 Thread.sleep(5000); 
		
		 test.log(Status.PASS, "Clicked check boxes for the first 2 series in the series table");
		
		// Thread.sleep(1000);    
			
		//---------------------
				WebElement element = driver.findElement(By.xpath("//*[@id='toolBar']/tbody/tr/td[3]/a"));
				Actions actions = new Actions(driver);
				actions.moveToElement(element).click().perform();
				 test.log(Status.PASS, "Click the link Data Table on the top links section");
				
				// js.executeScript("window.scrollBy(0,600)");
				 Thread.sleep(5000);  
			 String str1=driver.findElement(By.xpath("//*[@id='dataTableID']/thead/tr/th[2]/span/small")).getText();
			 String str2=driver.findElement(By.xpath("//*[@id='dataTableID']/thead/tr/th[3]/span/small")).getText();
			 
			 if(Step5.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/thead/tr/th[2]/span/small")).getText())){
				 //DD_TST.B.AT.IR_L.AVG.RT series is shown in row 1 col 2
				 test.log(Status.PASS, Step5 + " series is shown in row 1 col 2");
				// 
			 }else{
				 test.log(Status.FAIL, Step5 + " series NOt shown in row 1 col 2");
				 TestStatus= "FAIL";
			 } 
	//		 test.log(Status.PASS, "Check in the web table serch in 2 row data should contain"); 
			 if(Step6.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/thead/tr/th[3]/span/small")).getText())){
				 //DD_TST.B.AT.IR_L.AVG.RT series is shown in row 1 col 2
				 test.log(Status.PASS, Step6 + " series is shown in row 1 col 2");
				 // 
			 }else{
				 test.log(Status.FAIL, Step6 + " series NOt shown in row 1 col 3");
				 TestStatus= "FAIL";
			 }
				
			
					 if(Step7.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[3]/td[1]")).getText())){
						 test.log(Status.PASS, " 2016-12-05 value fond in series table in row 2 col 1");
						 // 
					 }else{
						 test.log(Status.FAIL, " 2016-12-05 value NOT fond in series table in row 2 col 1");// 
						 TestStatus= "FAIL";
					 }
					 if(Step7.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[3]/td[2]")).getText())){
						 test.log(Status.PASS, " 0.580000000000000 value fond in series table in row 2 col 2");
						 //
					 }else{
						 test.log(Status.FAIL, " 0.580000000000000 value NOT fond in series table in row 2 col 2");
						 TestStatus= "FAIL";
					 }
					 if(Step7.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[3]/td[3]")).getText())){
						 test.log(Status.PASS, " 1.512210965156555 value fond in series table in row 2 col 3");
						 // 
					 }else{
						 test.log(Status.FAIL, " 1.512210965156555 value NOT fond in series table in row 2 col 3");
						 TestStatus= "FAIL";
					 }
							 
			//		 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		//---------------------
				 
				 Thread.sleep(2000); 
					 String fromdate=(String) aList8.get(0);
					 String todate=(String) aList8.get(1);
					 System.out.println("==========================1========================"+ fromdate );
					
					 WebElement webElement=driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/div[2]/a"));
					 webElement.sendKeys(Keys.TAB,Keys.TAB,fromdate,Keys.TAB,todate,Keys.TAB,Keys.TAB);
					 
					 test.log(Status.PASS, "Set the start date to 01-11-2016 and end date 30-11-2016, and Verify data in web table");
					 
				 Thread.sleep(3000);  
				 js.executeScript("window.scrollBy(0,300)");
				//*[@id="dataTableID"]/tbody[2]/tr[2]/td[1]  2016-11-30,0.56,1.512322545051575
				 
				 
				 if(Step9.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[1]")).getText())){
					 test.log(Status.PASS, " 2016-11-30 value fond in series table in row 1 col 1");
					 
				 }else{
					 test.log(Status.FAIL, " 2016-11-30 value NOT fond in series table in row 1 col 1");
					 TestStatus= "FAIL";
				 }
				 if(Step9.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[2]")).getText())){
					 test.log(Status.PASS, " 0.560000000000000	 value fond in series table in row 1 col 2");
				 }else{
					 test.log(Status.FAIL, " 0.560000000000000	 value NOT fond in series table in row 1 col 2");
					 TestStatus= "FAIL";
				 }
				 if(Step9.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[3]")).getText())){
					 test.log(Status.PASS, " 1.512322545051575 value fond in series table in row 1 col 3");
				 }else{
					 test.log(Status.FAIL, " 1.512322545051575 value NOT fond in series table in row 1 col 3");
					 TestStatus= "FAIL";
				 }
				 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Data_Table1", test, date1)); 
				//=======================================
				 test.log(Status.PASS, "Click on the reset settings image button ");
				 
				 ////*[@id="dataTableID"]/tbody[2]/tr[2]/td[1]
				 WebElement webElement2=driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/div[2]/a"));
				 webElement2.sendKeys(Keys.TAB,Keys.ENTER);
				 
				  Thread.sleep(3000);
				  
					 if(Step11.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[1]")).getText())){
						 test.log(Status.PASS, " 2016-12-06 value fond in series table in row 1 col 1");
						 
					 }else{
						 test.log(Status.FAIL, " 2016-12-06 value NOT fond in series table in row 1 col 1");
						 TestStatus= "FAIL";
					 }
					 if(Step11.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[2]")).getText())){
						 test.log(Status.PASS, " 0.594000000000000	 value fond in series table in row 1 col 2");
					 }else{
						 test.log(Status.FAIL, " 0.594000000000000	 value NOT fond in series table in row 1 col 2");
						 TestStatus= "FAIL";
					 }
					 if(Step11.contains(driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[3]")).getText())){
						 test.log(Status.PASS, " 1.51207160949707 value fond in series table in row 1 col 3");
					 }else{
						 test.log(Status.FAIL, " 1.51207160949707 value NOT fond in series table in row 1 col 3");
						 TestStatus= "FAIL";
					 }
				
				 
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "verify Backgroup color Not Matched :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}



}
