package pageObjects;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Properties;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import managers.FileReaderManager;
import utilities.CommonFunctions;
import utilities.PropertyReader;
import utilities.Screenshots;
public class ECB_Series_Search {
	private static final String Else = null;
	Screenshots objCreateScreenshot = new Screenshots();
	CommonFunctions com = new CommonFunctions();
	String TestStatus="PASS";
	 WebElement TabName =null;
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
	 
	 public String SeriesSearch_NonAccessibleSeries(WebDriver driver, String Step2, String Step4,ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
				
				driver.get(ApplicaitonUrl);
				
				test.log(Status.PASS, "Login to ECB portal home page");
				Thread.sleep(1000);
			
			//	serchbox.sendKeys(Step2);
				driver.findElement(By.xpath("//*[@id='q']")).sendKeys(Step2);
				
				driver.findElement(By.xpath("//*[@id='intMainSearch']/div[1]/input[2]")).click();
				 test.log(Status.PASS, "Search text '"+ Step2 +"' in the series search box");
				Thread.sleep(4000);

			if (driver.getPageSource().contains(Step4)){
				test.log(Status.PASS, "No data is available for Search query:  MPD_TST.A.A1.YER.A.S11.0000");
				
			}else{
				test.log(Status.FAIL, "Data available for Search query:  MPD_TST.A.A1.YER.A.S11.0000 ");
				TestStatus= "FAIL";	
				
			}
			 				
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "SeriesSearch_NonAccessibleSeries", test, date1));
					
					 
				return TestStatus;
							
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, " SeriesSearch_NonAccessibleSeries :  FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}
	
	 
	 public String SeriesSearch_SerchSeries(WebDriver driver, String Step2,String Step5,String Step7,ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
				
				driver.get(ApplicaitonUrl);
				String Stepstr =Step7;
				String fieldvalue="";
				ArrayList aList7= new ArrayList(Arrays.asList(Stepstr.split(",")));
				
				JavascriptExecutor js = (JavascriptExecutor) driver;
				 
					
				test.log(Status.PASS, "Login to ECB portal home page");
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@id='q']")).sendKeys(Step2);
				
				 driver.findElement(By.xpath("//*[@id='intMainSearch']/div[1]/input[2]")).click();
				 test.log(Status.PASS, "Search text '"+ Step2 +"' in the series search box");
				Thread.sleep(6000);
				
				//Check if Frequency (1)  filed exist in Dimension Filters table

				//*[@id="s2id_af3"]/ul/li[1]/div
				String str=driver.findElement(By.xpath("//*[@id='s2id_af3']/ul/li[1]/div")).getText();
				System.out.println("str================== " + str);
				 js.executeScript("window.scrollBy(0,300)");
				if(str.contains(Step5)){
					test.log(Status.PASS, "Value found in Frequency (1) in Dimension Filters table");
				}
				else{
					test.log(Status.FAIL, "No value found in Frequency (1) in Dimension Filters table");
					TestStatus= "FAIL";	
				}
				//Check if Derived data economic concept (2) filed exist in Dimension Filters table

				if (driver.getPageSource().contains("Derived data economic concept")){
				test.log(Status.PASS, "Derived data economic concept (2) filed exist in Dimension Filters table");
				
				}else{
				test.log(Status.FAIL, "Derived data economic concept (2) filed NOT exist in Dimension Filters table");
				TestStatus= "FAIL";	
				}
				//*[@id="s2id_autogen3"]
				driver.findElement(By.xpath("//*[@id='s2id_autogen3']")).click();;
				Thread.sleep(3000);
				 for(int i=1;i<4;i++){
					 WebElement webElement=driver.findElement(By.xpath("//*[@id='select2-drop']/ul/li["+i+"]"));
						
				 	String list=(String) aList7.get(i-1);
					 
				 if (Step7.contains(list)) {
						fieldvalue=fieldvalue+","+list;
					 
			 	}else{
			 		test.log(Status.FAIL, list+ " Not Found in Frequency (2) field list  ");
			 		TestStatus= "FAIL";
			  }
			 } 
			 test.log(Status.PASS, fieldvalue + " values found in Derived data economic concept (2) field list");
			
			 js.executeScript("window.scrollBy(0,500)");
			 
			//In the table at the bottom of the page in row 1 col 1 Dataset name: appears
			 if(driver.findElement(By.xpath("//*[@id='commonDescTable']/tbody/tr/td[1]/small")).getText().contains("Dataset name")){
				 test.log(Status.PASS, " Derived name Found in Common Description table");
			 }else{
				 test.log(Status.FAIL, "  Derived name Found in Common Description table ");
			 		TestStatus= "FAIL";
			 }
			 //In the same table row 1 col 2 Derived Data value appears
			 if(driver.findElement(By.xpath("//*[@id='commonDescTable']/tbody/tr/td[2]/small")).getText().contains("Derived Data")){
				 test.log(Status.PASS, "  Derived Data Found in Common Description table ");
			 }else{
				 test.log(Status.FAIL, "  Derived Date Found in Common Description table ");
			 		TestStatus= "FAIL";
			 }
			
			 //Check if Page shows 1 reference series, 1 published series and 14 others in series listed from the Selected Datasets

			//*[@id="seriesListTable"]/tbody/tr[12]
			 int rowcount=0;
			 for(int i=1;i<17;i++){
				 if(driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr["+i+"]")).isDisplayed()){
					 rowcount=rowcount+1;
					 if(i==16){
						 test.log(Status.PASS, " In Selected Datasets table: 1 reference series, 1 published series and 14 others in series listed ");
					 }
				 }
				 
			 }
			 if(rowcount<16){
				 test.log(Status.FAIL, " In Selected Datasets table: 16 rows series listed not display");
				 TestStatus="FAIL";
			 }
				 
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "SeriesSearch_SerchSeries", test, date1));
			
				
					 
				return TestStatus;
							
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, " SeriesSearch_SerchSeries Test :  FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}
	 
	 
	 public String SeriesSearch_FilterSeriesKeys_byType(WebDriver driver, String Step2,ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
				
				driver.get(ApplicaitonUrl);
				//driver.get(url);		 String url,				
				JavascriptExecutor js = (JavascriptExecutor) driver;
				 
					
				test.log(Status.PASS, "Login to ECB portal home page");
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@id='q']")).sendKeys(Step2);
				
				 driver.findElement(By.xpath("//*[@id='intMainSearch']/div[1]/input[2]")).click();
				 test.log(Status.PASS, "Search text '"+ Step2 +"' in the series search box");
				Thread.sleep(6000);
				
				//Check if Frequency (1)  filed exist in Dimension Filters table

			 js.executeScript("window.scrollBy(0,700)");
	
			
			 //Uncheck Published series checkbox and there should be 1 Reference Series, 0 Published Series and 14 Others

			driver.findElement(By.xpath("//*[@id='colorLegend']/tbody/tr/td[3]/input")).click();
			test.log(Status.PASS, "Uncheck Published series checkbox and there should be 1 Reference Series, 0 Published Series and 14 Others");
			 int rowcount=0;
			 for(int i=1;i<17;i++){
				 if(driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr["+i+"]")).isDisplayed()){
					 rowcount=rowcount+1;
					 if(i==16){
						 test.log(Status.PASS, " In Selected Datasets table: 1 reference series, 0 published series and 14 others in series listed ");
					 }
				 }else{
					 test.log(Status.PASS, " 0 Published Series in series listed ");
				 }
				 
			 }
			 if(rowcount<16){
				 test.log(Status.FAIL, " In Selected Datasets table: 16 rows series listed not display");
					
			 }
				Thread.sleep(2000);	 
		//Uncheck Others series check box and there should be 1 reference series 0 Published Series and 0 Others
				test.log(Status.PASS, "Uncheck Others series check box and there should be 1 reference series 0 Published Series and 0 Others");
				
			 driver.findElement(By.xpath("//*[@id='colorLegend']/tbody/tr/td[4]/input")).click();
			 rowcount=0;
			 for(int i=1;i<17;i++){
				 if(driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr["+i+"]")).isDisplayed()){
					 rowcount=rowcount+1;
					 if(i==16){
						 test.log(Status.PASS, " In Selected Datasets table: 1 reference series, 0 published series and 0 others in series listed ");
					 }
				 }else{
					 test.log(Status.PASS, i + " number row not displayed in series listed ");
				 }				 
			 }
			 if(rowcount<16){
				 test.log(Status.FAIL, " In Selected Datasets table: 16 rows series listed not display");
			 }
				Thread.sleep(2000);
			// Check Published series checkbox and there should be 1 Reference Series, 1 Published Series and 0 Others
			
			test.log(Status.PASS, "Check Published series checkbox and there should be 1 Reference Series, 1 Published Series and 0 Others");
						
				driver.findElement(By.xpath("//*[@id='colorLegend']/tbody/tr/td[3]/input")).click();
			 rowcount=0;
			 for(int i=1;i<17;i++){
				 if(driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr["+i+"]")).isDisplayed()){
					 rowcount=rowcount+1;
					 if(i==16){
						 test.log(Status.PASS, " In Selected Datasets table: 1 reference series, 1 published series and 0 others in series listed ");
					 }
				 }else{
					 test.log(Status.PASS, i + " number row not displayed in series listed ");
				 }				 
			 }
			 if(rowcount<16){
				 test.log(Status.FAIL, " In Selected Datasets table: 16 rows series listed not display");
			 }
				Thread.sleep(2000);
		// Check Others series checkbox and there should be 1 Reference Series, 1 Published Series and 14 Others

				test.log(Status.PASS, "Check Others series checkbox and there should be 1 Reference Series, 1 Published Series and 14 Others");
				
				 driver.findElement(By.xpath("//*[@id='colorLegend']/tbody/tr/td[4]/input")).click();
				 rowcount=0;
				 for(int i=1;i<17;i++){
					 if(driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr["+i+"]")).isDisplayed()){
						 rowcount=rowcount+1;
						 if(i==16){
							 test.log(Status.PASS, " In Selected Datasets table: 1 reference series, 1 published series and 14 others in series listed ");
						 }
					 }else{
						 test.log(Status.PASS, i + " number row not displayed in series listed ");
					 }				 
				 }
				 if(rowcount<16){
					 test.log(Status.FAIL, " In Selected Datasets table: 16 rows series listed not display");
				 }
				 
		//================================	 

		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "SeriesSearch_FilterSeriesKeys_byType", test, date1));
			
				
					 
				return TestStatus;
							
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, " Metadata for non-accessible data Test :  FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}
	
	 public String SeriesSearch_SelectDeselectSeriesKeys(WebDriver driver, ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
				
			//	driver.get(url);
										
			//	JavascriptExecutor js = (JavascriptExecutor) driver;
				 
					
			//	test.log(Status.INFO, "Login to ECB portal home page");
		//In the Series list table select first series checkbox to select all the series and on top of Series table the text Filter: Selected Series (16 out of 16) is displayed
				
				if(driver.getPageSource().contains("16 series listed from the Selected Datasets!")){
					{
						 test.log(Status.PASS, " '16 series listed from the Selected Datasets!' : Text is available on top of the Series list table  ");
					 }
				 }else{
					 test.log(Status.PASS, "'16 series listed from the Selected Datasets!' : Text is NOT available on top of the Series list table   ");
				 }	
				
		//In the Series list table select first series checkbox to select all the series and on top of Series table the text Filter:
				
				driver.findElement(By.xpath("//*[@id='SERIES_KEY_checkall']")).click();
				test.log(Status.PASS, "In the Series list table select first series checkbox to select all the series ");
				int rowcount=0;
				for(int i=1;i<17;i++){
					 if(driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input")).isSelected()){
						 rowcount=rowcount+1;
						 if(i==16){
							 test.log(Status.PASS, " All serise are selected in series listed  ");
						 }
					 }else{
						 test.log(Status.PASS, i + " checkbox are not selected in series listed ");
					 }			
				}
			
			//Uncheck the first series checkbox and on top of series table , text 16 series listed from the Selected Datasets! Text is displayed
				
				driver.findElement(By.xpath("//*[@id='SERIES_KEY_checkall']")).click();
				test.log(Status.PASS, "In the Series list table select first series checkbox to Deselect all the series ");
				 rowcount=0;
				for(int i=1;i<17;i++){
					 if(driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input")).isSelected()==false){
						 rowcount=rowcount+1;
						 if(i==16){
							 test.log(Status.PASS, " All serise are Deselected in series listed  ");
						 }
					 }else{
						 test.log(Status.PASS, i + " checkbox are  Selected in series listed ");
					 }			
				}
				
		//================================	 

		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "SeriesSearch_SelectDeselectSeriesKeys", test, date1));
			
				
					 
				return TestStatus;
							
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, " SeriesSearch_SelectDeselectSeriesKeys :  FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}
	 

}
