package pageObjects;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import managers.FileReaderManager;
import utilities.Screenshots;
public class ECB_History_Snapshot {
	Screenshots objCreateScreenshot = new Screenshots();
	//CommonFunctions com = new CommonFunctions();
	String TestStatus="PASS";
	 WebElement TabName =null;
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
	 
	public String History_Snapshort_SearchText(WebDriver driver, String Step2,String Step6,String Step7,String Step9, ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			
		//	String url=ApplicaitonUrl+node;
			System.out.println("=========ECB_History_Snapshot===================      ");
			
			test.log(Status.PASS, "Login to ECB portal home page");
			//String TestStatus="PASS";
			//int status=0;
			ArrayList aList7= new ArrayList(Arrays.asList(Step7.split(",")));
			ArrayList aList9= new ArrayList(Arrays.asList(Step9.split(",")));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			//links available in Available Data Sets table
		 		
		 String text71= (String) aList7.get(0);
		 String text72= (String) aList7.get(1);
		 
		 String text91= (String) aList9.get(0);
		 String text92= (String) aList9.get(1);
		
		 
		
		 driver.findElement(By.xpath("//*[@id='q']")).sendKeys(Step2);
		 driver.findElement(By.xpath("//*[@id='intMainSearch']/div[1]/input[2]")).click();
		 
	
		 test.log(Status.PASS, "Serch text 'EXR_TST.M.E5.EUR.ERC0.A' and clicked on serch button");
		 
		 //EXR_TST : Exchange Rates Test  
		 
		 String str1=driver.findElement(By.xpath("//*[@id='datasetTable']/tbody/tr/td[2]")).getText();
		 System.out.println("Available Datasets : " + str1);
		 test.log(Status.PASS, "Available Datasets Text : " + str1);
	
		 driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr/td[1]/input")).click();
		 test.log(Status.PASS, "Select the check box in 2 row 1 col in the list of series below");
		 
		 Thread.sleep(1000);
		 driver.findElement(By.linkText("Data Table")).click();
		 test.log(Status.PASS, "Clicked on Data Table link");
		 Thread.sleep(2000);
		 WebElement webElement=driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/div[2]/a"));
		 webElement.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Step6,Keys.TAB);
		 test.log(Status.PASS, "Enter 01-12-2016 in History Snapshot text box");
		 Thread.sleep(4000);
		 
//		 Check for values 2016-10;90.8176 in the table after filter is applied
		//*[@id="dataTableID"]/tbody[2]/tr[2]/td[1]
		 String value1=driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[1]")).getText();
		 String value2=driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[2]")).getText();
		 
		 js.executeScript("window.scrollBy(0,200)");
		 //Assert.assertEquals(value1,text1); 
		// Assert.assertEquals(value2,text2); 
		 if (value1.contains(text71)){
				test.log(Status.PASS, text71+ " in the table after filter is applied");
			
			}else{
				test.log(Status.FAIL, text71+ " NOT in the table after filter is applied");
				TestStatus= "FAIL";
			
			}
		 if (value2.contains(text72)){
				test.log(Status.PASS, text72+ " in the table after filter is applied");
			
			}else{
				test.log(Status.FAIL, text72+ " NOT in the table after filter is applied");
				TestStatus= "FAIL";
			}
		 
		 Thread.sleep(1000);
		 driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/div[2]/input")).click();
		
		 Thread.sleep(4000);
		 value1=driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[1]")).getText();
		 value2=driver.findElement(By.xpath("//*[@id='dataTableID']/tbody[2]/tr[2]/td[2]")).getText();
		 js.executeScript("window.scrollBy(0,200)");
		
		 if (value1.contains(text91)){
				test.log(Status.PASS, text91+ " in the table after reset setting");
			
			}else{
				test.log(Status.FAIL, text91+ " NOT in the table after reset setting");
				TestStatus= "FAIL";
			}
		 if (value2.contains(text92)){
				test.log(Status.PASS, text92+ " in the table after reset setting");
			//	TestStatus= "PASS";
			}else{
				test.log(Status.FAIL, text92+ " NOT in the table after reset setting");
				TestStatus= "FAIL";
			}
		 
		 Thread.sleep(4000);
		 
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "History_Snapshort_SearchText", test, date1));
		
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, " History Snapshot, Series Search Text Box search :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}



}
