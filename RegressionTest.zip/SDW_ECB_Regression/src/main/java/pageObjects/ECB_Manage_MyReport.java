package pageObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
//import java.awt.Color;
import java.util.StringTokenizer;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.poi.hssf.record.PageBreakRecord.Break;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import managers.FileReaderManager;
import utilities.CommonFunctions;
import utilities.PropertyReader;
import utilities.Screenshots;
public class ECB_Manage_MyReport {
	Screenshots objCreateScreenshot = new Screenshots();
	CommonFunctions com = new CommonFunctions();
	 String fieldvalue1="";
	 String TestStatus="PASS";
	 WebElement TabName =null;
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
	 
	 
	public String Add_New_Publication(WebDriver driver, String node, String Step3,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			
			String url = ApplicaitonUrl.substring( 0, ApplicaitonUrl.indexOf("browse"))+"reports.do"+node;
						
			System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
			
			driver.get(url);
			test.log(Status.PASS, "Login to ECB portal and go to report node = " + node );
				
			driver.findElement(By.xpath("//*[@id='contentlimiter']/span/a")).click();
			
			test.log(Status.PASS, "Click link Add to my Publication" );
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@name='newGroup']")).sendKeys(Step3);
			
			//*[@id="contentlimiter"]/div/div[2]/form/table/tbody/tr/td/div/input[1]
			
			test.log(Status.PASS, "Enter new Publication" );
			driver.findElement(By.xpath("//input[@name='createNewGroup']")).click();
			test.log(Status.PASS, "Clicked on Create and Add button" );
			Thread.sleep(3000);

			if(driver.getPageSource().contains("This publication has been successfully")){
				test.log(Status.PASS, "New publication has been successfully added" );
			}else{
				test.log(Status.FAIL, "The publication named is already in use." );
				TestStatus="FAIL";
			}
			
			 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Add_New_MyReport", test, date1));
				
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Manage_Add_MyReports Test :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}

	public String PublicationList(WebDriver driver, String node, String Step3,ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			
			String url = ApplicaitonUrl.substring( 0, ApplicaitonUrl.indexOf("browse"))+"reports.do"+node;
			
			int flag=0;
			System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
			
			driver.get(url);
			test.log(Status.PASS, "Login to ECB portal and go to report node = " + node );
			
			
			driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[20]/a/span")).click();
			test.log(Status.PASS, "Click on My Publications in the left hand side menu" );
			
			List  rows = driver.findElements(By.xpath("//*[@id='reportGroup']/tbody/tr/td[1]")); 
	        System.out.println("No of rows are : " + rows.size());
	       
	        for(int i=1;i<=rows.size();i++){
	        	if(driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[1]")).getText().contains(Step3)){
	        		String cdate=driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[3]")).getText();
	        		SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd");
	        		Date date = new Date(System.currentTimeMillis());
	        		test.log(Status.PASS, "the newly created report exists : " + Step3);
	        		if(cdate.contains(formatter.format(date))){
	        			 test.log(Status.PASS, "Date of newly created report : " + cdate);
	        			 flag=1;						 
	        		}
	        		 break;	
	        	}
	        }
	         if(flag==0){
        		test.log(Status.FAIL, "Date of newly created report is NOT Todays date ");
        		return TestStatus="FAIL";	
        	}
			
			Thread.sleep(2000);
			
			 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "ReportsList", test, date1));
				
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Manage_MyReports ReportsList Test :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}
	
public String SortPublication(WebDriver driver, String node, ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{
			
			String url = ApplicaitonUrl.substring( 0, ApplicaitonUrl.indexOf("browse"))+"reports.do"+node;
			
			int flag=0;
		//	System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
			
			driver.get(url);
			test.log(Status.PASS, "Login to ECB portal and go to report node = " + node );
			
			
			driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[20]/a/span")).click();
			test.log(Status.PASS, "Click on My Publications in the left hand side menu" );
			
			driver.findElement(By.linkText("Name")).click();
			test.log(Status.PASS, "Click on the Name Header of the table to SortReports" );
			Thread.sleep(2000);
			
			 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "SortReports", test, date1));
				
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Manage_MyReports SortReports Test :  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}
		

public String BrowsePublication(WebDriver driver, String node, String Step3,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		
		String url = ApplicaitonUrl.substring( 0, ApplicaitonUrl.indexOf("browse"))+"reports.do"+node;
		
		int flag=0;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		
		driver.get(url);
		test.log(Status.INFO, "Login to ECB portal and go to report node = " + node );
		
		
		driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[20]/a/span")).click();
		test.log(Status.INFO, "Click on My Publications in the left hand side menu" );
		
		List  rows = driver.findElements(By.xpath("//*[@id='reportGroup']/tbody/tr/td[1]")); 
        System.out.println("No of rows are : " + rows.size());
       
        for(int i=1;i<=rows.size();i++){
        	if(driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[1]")).getText().contains(Step3)){
        		
        		test.log(Status.PASS, "the newly created report exists : " + Step3);
        		driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[4]/a")).click();
        	       	
        		
        		test.log(Status.PASS, "Click the link Browse against the newly created report");
        		Thread.sleep(2000);
        		
        		if(driver.findElement(By.xpath("//*[@id='bcsdw']/table/tbody/tr/td/b")).getText().contains(Step3)){
        			 test.log(Status.PASS, "the breadcrumb path is shown as Home   >   My Publications   > "+ Step3  );
        			 Thread.sleep(2000);
        			 flag=1;						 
        		}
        		 break;	
        	}
        }
     
         if(flag==0){
    		test.log(Status.FAIL, "Newly craeted publication NOT in breadcrumb path ");
    		return TestStatus="FAIL";	
    	}
		
		 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Browse Report", test, date1));
			
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "Manage_MyReports BrowseReport Test :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}
	

public String DeletePublication(WebDriver driver, String node, String Step4,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		
		String url = ApplicaitonUrl.substring( 0, ApplicaitonUrl.indexOf("browse"))+"reports.do"+node;
		
		int flag=0;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		
		driver.get(url);
		test.log(Status.INFO, "Login to ECB portal and go to report node = " + node );
		
		
		driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[20]/a/span")).click();
		test.log(Status.INFO, "Click on My Publications in the left hand side menu" );
		
		List  rows = driver.findElements(By.xpath("//*[@id='reportGroup']/tbody/tr/td[1]")); 
        System.out.println("No of rows are : " + rows.size());
       
        for(int i=1;i<=rows.size();i++){
        	if(driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[1]")).getText().equalsIgnoreCase(Step4)){
        		
        		test.log(Status.PASS, "Publication '"+ Step4 + "' exists in list");
        		driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[6]/a")).click();
        	       	
        		
        		test.log(Status.PASS, "Click the link Delete link against the publication");
        		Thread.sleep(2000);
        		
        		driver.switchTo().alert().accept();
        		test.log(Status.PASS, "Selected publication deleted successfully");
        		Thread.sleep(5000);
        		flag=1;	
        		        		
        		 break;	
        	}
        }
     
        
         if(flag==0){
    		test.log(Status.FAIL, "Publication NOT available in list to Delete ");
    		TestStatus="FAIL";	
    	}else{
    		rows = driver.findElements(By.xpath("//*[@id='reportGroup']/tbody/tr/td[1]")); 
            for(int i=1;i<=rows.size();i++){
            	if(driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[1]")).getText().contains(Step4)){
            		test.log(Status.FAIL, "Publication could not deleted");
            		TestStatus="FAIL";
            		flag=2;
            		break;
            	}
            }
            
    	}
		
         if(flag==1){
     		test.log(Status.PASS, "Newly created publication NOT available in list to after Delete ");
     		//TestStatus="FAIL";	
     	}
         
		 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Browse Report", test, date1));
			
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "Manage_MyReports BrowseReport Test :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}
	


public String NotAllowedPublication(WebDriver driver, String node,String NotAllow,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		
		String url = ApplicaitonUrl.substring( 0, ApplicaitonUrl.indexOf("browse"))+"reports.do"+node;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		int flag=0;
		driver.get(url);
		test.log(Status.PASS, "Login to ECB portal and go to report node = " + node );
			
		driver.findElement(By.xpath("//*[@id='contentlimiter']/span/a")).click();
		
		test.log(Status.PASS, "Click link Add to my Publication" );
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='contentlimiter']/div/div[2]/form/table/tbody/tr[3]/td/div/input[1]")).sendKeys(NotAllow);
		test.log(Status.PASS, "Enter new Publication" );
		driver.findElement(By.xpath("//*[@id='contentlimiter']/div/div[2]/form/table/tbody/tr[3]/td/div/input[2]")).click();
		test.log(Status.PASS, "Clicked on Create and Add button" );
		
		if(driver.getPageSource().contains("Only alphanumeric characters, are not allowed.")){
			test.log(Status.PASS, "Error message :" + driver.findElement(By.xpath("//*[@id='contentlimiter']/div[1]/ul/li")).getText());
			
		}
		
	
		 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NotAllowedReport", test, date1));
		
		 
		 driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[20]/a/span")).click();
			test.log(Status.PASS, "Click on My Publications in left hand side menu " );
			 Thread.sleep(5000);
			List  myPublist = driver.findElements(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li")); 
			System.out.println("myPublist : " + myPublist.size());
			
			 js.executeScript("window.scrollBy(0,500)");
			
					 
			 for(int i=1;i<=myPublist.size();i++){
				 if(driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).getText().contains(NotAllow)){
					 driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).click();
					 System.out.println("myPublist : " + driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).getText());
					 test.log(Status.PASS, "Click on existing report link under My Publications " );
					 flag=1;
					 test.log(Status.FAIL, "Newly craeted publication NOT found in publication list ");
			    		return TestStatus="FAIL";	
				 }
				 
			 }
			 js.executeScript("window.scrollBy(0,500)");
			  if(flag==0){
		    		test.log(Status.PASS, "Newly craeted publication NOT found in publication list ");
		    		
		    	}
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "Manage_MyReports NotAllowedReport Test :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}
	


public String EditPublication(WebDriver driver, String node,String Step2,String Step3,String Step4,String Step5,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		
		String url = ApplicaitonUrl.substring( 0, ApplicaitonUrl.indexOf("browse"))+"reports.do"+node;
		
		int flag=0;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		
		driver.get(url);
		test.log(Status.INFO, "Login to ECB portal and go to report node = " + node );
		
		ArrayList aList3= new ArrayList(Arrays.asList(Step3.split(";")));
		driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[20]/a/span")).click();
		test.log(Status.INFO, "Click on My Publications in the left hand side menu" );
		
		List  rows = driver.findElements(By.xpath("//*[@id='reportGroup']/tbody/tr/td[1]")); 
        System.out.println("No of rows are : " + rows.size());
       
        for(int i=1;i<=rows.size();i++){
        	
        	if(driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[1]")).getText().equalsIgnoreCase(Step2)){
        		
        		test.log(Status.PASS, "the report exists : " + Step2);
        		driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[5]/a")).click();
        	       	       		
        		test.log(Status.PASS, "Click on Edit link against the newly created group");
        		Thread.sleep(2000);
        		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "EditReport", test, date1));      			
        		driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/table/tbody/tr[1]/td[2]/input")).clear();
                  		
           	     	driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/table/tbody/tr[1]/td[2]/input")).sendKeys(Step4);
        	       	test.log(Status.PASS, "Change the Existing Publicaiton Name");
        	               	
        	        Thread.sleep(1000);
        	        
        	        if(driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/table/tbody/tr[2]/td[2]/textarea")).getText().isEmpty()){
        	        	test.log(Status.PASS, "Publication comment is enpty ");
        	       	
        	        	driver.findElement(By.xpath("//*[@id='contentlimiter']/div/form/table/tbody/tr[2]/td[2]/textarea")).sendKeys(Step5);
        	        	test.log(Status.PASS, "Added comment in existing publication");
        	         }else{
        	         	test.log(Status.FAIL, "Publication comment is NOT enpty ");
        	         	TestStatus="FAIL";
        	         }
        	        Thread.sleep(3000);
        	        
        	    
        	       Select webList=new Select(driver.findElement(By.name("selectedItems"))); //By.xpath("//*[@id='contentlimite']/div/form/table/tbody/tr[3]/td[2]/select")));
        	
        	     List<WebElement> list = webList.getOptions();
        	            	     
        	     String pageWeblist="";
        	     System.out.println("List size: " + list.size());
        	        for(int x=0;x<list.size();x++){
        	        	if(list.get(x).getText().contains(((String)aList3.get(x)))){
        	        		
        	        		pageWeblist=pageWeblist+" ; "+ (String)aList3.get(x);
        	        	}        	        	
        	        }
        	        test.log(Status.PASS, "All WebList : " + pageWeblist);
        	        
        	        webList.selectByIndex(1);
        	       driver.findElement(By.name("doMoveUp")).click();
        	       test.log(Status.PASS, "Select option 'Reports / TST_Economic Bulletin / TST_2 Financial developments' , and Clicked on MoveUo button");
        	      
        	       Thread.sleep(3000);
        	       webList=new Select(driver.findElement(By.name("selectedItems")));
        	       webList.deselectAll();
        	       webList.selectByIndex(3);
        	       driver.findElement(By.name("doMoveDown")).click();
        	       test.log(Status.PASS, "Select option ' Reports / TST_Dashboard embedding / TST_4 Prices and costs' , and Clicked on MoveDown button");
           	    
        	       Thread.sleep(3000);
        	       webList=new Select(driver.findElement(By.name("selectedItems")));
        	       webList.deselectAll();
        	       webList.selectByIndex(5);
        	       driver.findElement(By.name("doDelete")).click();
        	       test.log(Status.PASS, "Select option 'Reports / TST_Dashboard embedding / TST_6 Fiscal developments' , and Clicked on Delete button");
           	    
        	    //   test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "EditReport", test, date1));
        	       Thread.sleep(3000);
        	       driver.findElement(By.name("doSave")).click();
        	       flag=1;
        		 break;	
        	}        	
         }
     
            if(flag==0){
    		test.log(Status.FAIL, "Newly craeted publication NOT found in list to Edit ");
    		return TestStatus="FAIL";	
    	}
		Thread.sleep(2000);
		flag=0;
		  for(int i=1;i<=rows.size();i++){
	        	
	        	if(driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[1]")).getText().equalsIgnoreCase(Step4) && 
	        			driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[2]")).getText().equalsIgnoreCase(Step5)){
	        		
	        		test.log(Status.PASS, " Name change is shown in the reports table with new comment" );
	        		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Updated_Report", test, date1));
	        		
	        		driver.findElement(By.xpath("//*[@id='reportGroup']/tbody/tr["+i+"]/td[5]/a")).click();
       	       		
	        		test.log(Status.PASS, "Clicked agin on Edit link against the newly edited group");
	        		Thread.sleep(2000);
	        		test.log(Status.PASS, "Values in the weblist in the same order as changed");
	        		 flag=1;
	        		break;	
	        	}
		  }
		
		     if(flag==0){
		    		test.log(Status.FAIL, "Newly edited publication NOT found in list to verify ");
		    		return TestStatus="FAIL";	
		    	}
		 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Updated_Report1", test, date1));
			
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "Manage_MyReports EditReport Test :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}
	

public String AddExistingReport(WebDriver driver, String node, String Step3, String Step4,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		
		String url = ApplicaitonUrl.substring( 0, ApplicaitonUrl.indexOf("browse"))+"reports.do"+node;
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		int flag=0;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		
		driver.get(url);
		test.log(Status.INFO, "Login to ECB portal and go to report node = " + node );		
		
		driver.findElement(By.xpath("//*[@id='contentlimiter']/span[1]/a")).click();
		test.log(Status.PASS, "Click on Add to my Publication  link" );
		Thread.sleep(2000);
		
		Select webList=new Select(driver.findElement(By.name("selectedGroup")));
		test.log(Status.PASS, "Select the existing Publication report in - Add to a publication" );
    	webList.selectByVisibleText(Step3);
    	driver.findElement(By.name("addToGroup")).click();
    	test.log(Status.PASS, "Click on Add to Group button" );
    	Thread.sleep(2000);
   
		driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[20]/a/span")).click();
		test.log(Status.PASS, "Click on My Publications in left hand side menu " );
		 Thread.sleep(5000);
		List  myPublist = driver.findElements(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li")); 
		System.out.println("myPublist : " + myPublist.size());
		
		 js.executeScript("window.scrollBy(0,500)");
		
				 
		 for(int i=1;i<=myPublist.size();i++){
			 if(driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).getText().contains(Step3)){
				 driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).click();
				 System.out.println("myPublist : " + driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).getText());
				 test.log(Status.PASS, "Click on existing report link under My Publications " );
			 }
			 
		 }
		 js.executeScript("window.scrollBy(0,500)");
		 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "AddExistingReport", test, date1));
		
			myPublist = driver.findElements(By.xpath("//*[@id='currentMaximizeNode1']/li/ul/li")); 
		 for(int i=1;i<=myPublist.size();i++){
			 if(Step4.contains(driver.findElement(By.xpath("//*[@id='currentMaximizeNode1']/li/ul/li["+i+"]/a/span")).getText())){
				// driver.findElement(By.xpath("//*[@id='currentMaximizeNode1']/li/ul/li["+i+"]/a/span")).click();
				 test.log(Status.PASS, "Found Sublinks : "+ driver.findElement(By.xpath("//*[@id='currentMaximizeNode1']/li/ul/li["+i+"]/a/span")).getText());
				 flag=1;
			 }
			 
		 }
		 if(flag==0){
			 test.log(Status.FAIL, " Could not find sublinks : " + Step4);
			 TestStatus="FAIL";
				 
		 }
		 
		 Thread.sleep(10000);
		 
		 
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "Add Existing Report Test :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}
	
public String AddExistingPublication_without_selecting(WebDriver driver, String node,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		
		String url = ApplicaitonUrl.substring( 0, ApplicaitonUrl.indexOf("browse"))+"reports.do"+node;
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		int flag=0;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		
		driver.get(url);
		test.log(Status.INFO, "Login to ECB portal and go to report node = " + node );		
		
		driver.findElement(By.xpath("//*[@id='contentlimiter']/span[1]/a")).click();
		test.log(Status.PASS, "Click on Add to my Publication  link" );
		Thread.sleep(2000);
		
	
    	driver.findElement(By.name("addToGroup")).click();
    	test.log(Status.PASS, "Click on Add button next to Add to a publication selection field" );
    	Thread.sleep(2000);
   	//.
    	if(driver.getPageSource().contains("Please select an existing publication group")){
    		test.log(Status.PASS, "Message 'Please select an existing publication group.' Is shown " );
    	}else{
    		test.log(Status.FAIL, "Not error message shown" );
    		TestStatus="FAIL";
    	}
		 
		 Thread.sleep(3000);
		 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "AddExistingReport_without_selecting", test, date1));
	
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "AddExistingPublication_without_selecting Test :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}
	
public String Replace_existing_without_selecting(WebDriver driver, String node,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		
		String url = ApplicaitonUrl.substring( 0, ApplicaitonUrl.indexOf("browse"))+"reports.do"+node;
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		int flag=0;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		
		driver.get(url);
		test.log(Status.INFO, "Login to ECB portal and go to report node = " + node );		
		
		driver.findElement(By.xpath("//*[@id='contentlimiter']/span[1]/a")).click();
		test.log(Status.PASS, "Click on Add to my Publication  link" );
		Thread.sleep(2000);
		
	
    	driver.findElement(By.name("replaceGroup")).click();
    	test.log(Status.PASS, "Click on Replace button next to Replace publication selection field" );
    	Thread.sleep(2000);
   	//.
    	if(driver.getPageSource().contains("Please select an existing publication group")){
    		test.log(Status.PASS, "Message 'Please select an existing publication group.' Is shown " );
    	}else{
    		test.log(Status.FAIL, "Not error message shown" );
    		TestStatus="FAIL";
    	}
		 
		 Thread.sleep(3000);
		 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "AddExistingReport_without_selecting", test, date1));
	
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "AddExistingPublication_without_selecting Test :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}
	
public String ReplaceExistingPublication(WebDriver driver, String node, String Step3, String Step4,ExtentTest test, String date1, ExtentReports extent) throws Exception{
	
	try{
		
		String url = ApplicaitonUrl.substring( 0, ApplicaitonUrl.indexOf("browse"))+"reports.do"+node;
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		int flag=0;
		System.out.println("url=============ECB_Manage_Add DataGroups=========  " + url);
		
		driver.get(url);
		test.log(Status.INFO, "Login to ECB portal and go to report node = " + node );		
		
		driver.findElement(By.xpath("//*[@id='contentlimiter']/span[1]/a")).click();
		test.log(Status.PASS, "Click on Add to my Publication  link" );
		Thread.sleep(2000);
		
		Select webList=new Select(driver.findElement(By.name("selectedReplaceGroup")));
		test.log(Status.PASS, "Select the existing Publication report in  Replace publication" );
    	webList.selectByVisibleText(Step3);
    	driver.findElement(By.name("replaceGroup")).click();
    	test.log(Status.PASS, "Click on Replace button next to Replace publication selection field" );
    	Thread.sleep(2000);
   
		driver.findElement(By.xpath("//*[@id='sectionmenu']/ul/li[20]/a/span")).click();
		test.log(Status.PASS, "Click on My Publications in left hand side menu " );
		 Thread.sleep(5000);
		List  myPublist = driver.findElements(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li")); 
		System.out.println("myPublist : " + myPublist.size());
		
		 js.executeScript("window.scrollBy(0,500)");
		
				 
		 for(int i=1;i<=myPublist.size();i++){
			 if(driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).getText().contains(Step3)){
				 driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).click();
				 System.out.println("myPublist : " + driver.findElement(By.xpath("//*[@id='currentMaximizeNode0']/li/ul/li["+i+"]/a/span")).getText());
				 test.log(Status.PASS, "Click on existing report link under My Publications " );
			 }
			 
		 }
		 js.executeScript("window.scrollBy(0,500)");
		 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "AddExistingReport", test, date1));
		
			myPublist = driver.findElements(By.xpath("//*[@id='currentMaximizeNode1']/li/ul/li")); 
		 for(int i=1;i<=myPublist.size();i++){
			 if(Step4.contains(driver.findElement(By.xpath("//*[@id='currentMaximizeNode1']/li/ul/li["+i+"]/a/span")).getText())){
				// driver.findElement(By.xpath("//*[@id='currentMaximizeNode1']/li/ul/li["+i+"]/a/span")).click();
				 test.log(Status.PASS, "Found Sublinks : "+ driver.findElement(By.xpath("//*[@id='currentMaximizeNode1']/li/ul/li["+i+"]/a/span")).getText());
				 flag=1;
			 }
			 
		 }
		 if(flag==0){
			 test.log(Status.FAIL, " Could not find sublinks : " + Step4);
			 TestStatus="FAIL";
				 
		 }
		 
		 Thread.sleep(10000);
		 
		 
		return TestStatus;
					
		
	}catch(Exception e){
		
	//  Block of code to handle errors
		test.fail("NoSuchElementException : " + e.getMessage());
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
		test.log(Status.FAIL, "ReplaceExistingPublication Test :  FAIL ");
		test.log(Status.INFO, "Closed the Browser");
		return "FAIL";
	}
	
}



}
