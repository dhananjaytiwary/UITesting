package pageObjects;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Properties;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import managers.FileReaderManager;
import utilities.CommonFunctions;
import utilities.PropertyReader;
import utilities.Screenshots;
public class ECB_Data_Charts {
	private static final String Else = null;
	Screenshots objCreateScreenshot = new Screenshots();
	CommonFunctions com = new CommonFunctions();
	String TestStatus="PASS";
	 WebElement TabName =null;
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
	 
	// PropertyReader config=new PropertyReader("./config.properties");
	 
	 public String Data_Static_Chart(WebDriver driver,String node, ExtentTest test, String date1, ExtentReports extent) throws Exception{
		
		try{ 
			String url=ApplicaitonUrl+node;
			System.out.println("url=============ECB_Data_Charts===================      "+ url);
			driver.get(url);
			
			test.log(Status.PASS, "Login to ECB portal and goto node=9701957");
		//com.DeleteFile(System.getProperty("user.dir") + "\\DownloadFolder\\", "data.csv");

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");

			driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[1]/td[1]/input")).click();
			driver.findElement(By.xpath("//*[@id='seriesListTable']/tbody/tr[2]/td[1]/input")).click();
			
			test.log(Status.PASS, "Select the 1st and 2nd series checkboxes in the table available at the bottom of the page");
		
			//*[@id="toolBar"]/tbody/tr/td[4]/a
			Thread.sleep(3000);
			driver.findElement(By.partialLinkText("Data Chart")).click();
			test.log(Status.PASS, "Click on link Data Chart on the top of the page");
			js.executeScript("window.scrollBy(0,700)");
			driver.findElement(By.partialLinkText("Static Chart")).click();
			test.log(Status.PASS, "Click on link Static Chart link, static chart display on page");
			Thread.sleep(5000);
			
			//below code is to download Img from page	==============================
			
			String path1=System.getProperty("user.dir") + "\\src\\test\\java\\TestData\\testscreen.png"; 
			String path2=System.getProperty("user.dir") + "\\src\\test\\java\\TestData\\MasterBrowseChart.png"; 
			
			if(com.downloadChart(driver, path1)){
				test.log(Status.PASS, "Static chart downloaded successfully");
				test.log(Status.PASS, "Compare downloaded Static chart with master static chart ");
				float per=com.compareImage2(new File(path1),new File(path2));
				System.out.println("percentage : " +per);
				
				if(com.compareImage(new File(path1),new File(path2))){
					System.out.println("Both chart is same");
					test.log(Status.PASS, "Static chart compare with master static chart successfully with :" + per +"%");
				}else{
					test.log(Status.FAIL, "Static chart compare with master static chart: Fail with :" + per +"%");
					TestStatus="FAIL";
				}
			}else{
				test.log(Status.FAIL, "Static chart downloaded successfully");
				TestStatus="FAIL";
			}
		
		
		
		
		test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Data_Chart", test, date1));	
		
				
			return TestStatus;
						
			
		}catch(Exception e){
			
		//  Block of code to handle errors
			test.fail("NoSuchElementException : " + e.getMessage());
			test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			test.log(Status.FAIL, "Compare Data Chart:  FAIL ");
			test.log(Status.INFO, "Closed the Browser");
			return "FAIL";
		}
		
	}


}
