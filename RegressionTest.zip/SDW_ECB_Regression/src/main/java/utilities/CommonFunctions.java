package utilities;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Base64;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.imageio.ImageIO;

import java.io.*;

import org.aeonbits.owner.ConfigFactory;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;


import junit.framework.TestCase;
import utilities.PropertyReader;
import utilities.Screenshots;
import managers.FileReaderManager;
import providers.Environment;



public class CommonFunctions extends TestCase{
	
	private static void  setClipboardData(String str){		
		StringSelection ss = new StringSelection(str);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	}
	
	public void HomePageLogin(WebDriver driver,String url) throws AWTException {
		 Robot robot = new Robot();
		 driver.get(url);
					
		 //System.out.println("username............................." + username);
		
		
	}
	
	
	public void ChromLogin(String username, String password) throws AWTException {
		 Robot robot = new Robot();
		 
					
		 System.out.println("username............................." + username);
		 setClipboardData(username);		
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.delay(1000);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);

			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);

			 System.out.println("password............................." + password);
			setClipboardData(password);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.delay(1000);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
		
	}
	
	
	public String getFileNamesFromZippedFile(String filePath, String fileName) throws IOException {
		
		String res = ""; 
		ZipInputStream zip = new ZipInputStream(Files.newInputStream(
	            Paths.get(filePath + fileName),
	            StandardOpenOption.READ));
	    ZipEntry entry = null;

	    while((entry = zip.getNextEntry()) != null){
	        res = res + entry.getName() + ";" ;
	    }
	    zip.close();
		return res;
	  
	  
	}
//====================================================================
	public void DeleteFile(String filePath, String fileName){
		 try
	        { 
	            Files.deleteIfExists(Paths.get(filePath + fileName)); 
	        } 
	        catch(NoSuchFileException e) 
	        { 
	            System.out.println("No such file/directory exists"); 
	        } 
	        catch(DirectoryNotEmptyException e) 
	        { 
	            System.out.println("Directory is not empty."); 
	        } 
	        catch(IOException e) 
	        { 
	            System.out.println("Invalid permissions."); 
	        } 
	          
	        System.out.println("Deletion successful."); 
	}
//==================================================================
	public String NewPDFileNmae(String FilePath) {

	//    public static void main(String[] args) {
	        // Creates an array in which we will store the names of files and directories
		String FileName="";
	        String[] pathnames;
        // Creates a new File instance by converting the given pathname string
	        // into an abstract pathname
	        File f = new File(FilePath);
	        
	        // Populates the array with names of files and directories
	        pathnames = f.list();

	        // For each pathname in the pathnames array
	        for (String pathname : pathnames) {
	            // Print the names of files and directories
	        	if(pathname.startsWith("data") && pathname.endsWith(".pdf")){
	            System.out.println("new File================="+ pathname);
	            FileName=pathname;
	        	} 
	        	
	        }
			return FileName;
	}
	
	//=============================================================================
	public void DeleteAllFilesFromDirectory(String path) {
		File dir = new File(path);
		
		if(dir.isDirectory() == false) {
			System.out.println("Not a directory. Do nothing");
			return;
		}
		File[] listFiles = dir.listFiles();
		for(File file : listFiles){
			System.out.println("Deleting "+file.getName());
			file.delete();
		}
		
		dir = null;
		
	}
	
//=============================
	public String comparing_csv_files(String filename1, String FilePath1,String filename2, String FilePath2) throws FileNotFoundException, IOException {
		
		System.out.println("FilePath1+filename1 : " + FilePath1+filename1);
		System.out.println("FilePath1+filename1 : " + FilePath2+filename2);
	String teststatus="PASS";
	//	    BufferedReader CSVFile1 = new BufferedReader(new FileReader(FilePath1+filename1));
	//    BufferedReader CSVFile2 = new BufferedReader(new FileReader(FilePath2+filename2));
	    
	    BufferedReader baseline = new BufferedReader(new FileReader(FilePath1+filename1));
        BufferedReader tested = new BufferedReader(new FileReader(FilePath2+filename2));
        String lineBaseline = null;
        String lineTested = null;
        boolean linesExist = true;
        boolean foundDiff = false;
        int lineNumber = 0;
        int errorNumber = 0;
        int errorThreshold = 2;
        String message = "";
        while (linesExist) {
            try {
                lineBaseline = baseline.readLine();
                lineTested = tested.readLine();
              //  System.out.println(" &&& lineBaseline " + lineBaseline );
                
              //  System.out.println(" *** lineTested  " + lineTested);
                
                lineNumber++;
             //   System.out.println(" *** lineNumber  " + lineNumber);
                
                if ((lineBaseline != null) && (lineTested != null)) {
                    if (!lineTested.equals(lineBaseline) && lineNumber!=1) {
                        foundDiff = true;
                        errorNumber++;
                   //     System.out.println(" #### lineNumber  " + lineNumber);
                        if (errorNumber > errorThreshold) {
                        //	teststatus="FAIL";
                            message = message + "\r\n" + "Found more than " + errorThreshold + " lines that were different. Will exit check.";
                            break;
                        }
                        message = message + "\r\n" + "\r\n#Found differences for line number " + lineNumber + "\r\nLine baseline: " + lineBaseline + "\r\nLine tested: " + lineTested;
                    }
                } else {
                    linesExist = false;
                }
            } catch (IOException e) {
                throw new Error("Problems with reading csv files");
            }
        }
        if (foundDiff) {
        
        	teststatus="Found differences between csv files. " + message;
      
        }
    
	    		
		return teststatus;
	}

//===========================
	public static boolean downloadChart(WebDriver driver,String NewFilepath) {
		// retun % of matching chart
	    
	    try {
	    	JavascriptExecutor js = (JavascriptExecutor) driver;
	    	String base64string = (String) js.executeScript("var c = document.createElement('canvas');"
                    + " var ctx = c.getContext('2d');"
                    + "var img = document.querySelector('#tabs-2 > p:nth-child(3) > img');"
                    + "c.height=img.naturalHeight;"
                    + "c.width=img.naturalWidth;"
                    + "ctx.drawImage(img, 0, 0,img.naturalWidth, img.naturalHeight);"
                    + "var base64String = c.toDataURL();"
                    + "return base64String;");
	    		String[] base64Array = base64string.split(",");
	    		String base64 = base64Array[base64Array.length - 1];
	    		byte[] decodedBytes = Base64.getDecoder().decode(base64);
	    		String decodedString = new String(decodedBytes);

	    		ByteArrayInputStream memstream = new ByteArrayInputStream(decodedBytes);
	    			BufferedImage saveImage = ImageIO.read(memstream);

	    			ImageIO.write(saveImage, "png", new File(NewFilepath));
	    			return true;
	    			
	    } catch (Exception e) {
	        System.out.println("Failed to compare image files ...");
	        return false;
	    }
	   // return percentage;
	}
//=========================
	public String HexColor(String color){
		
		 String[] numbers = color.replace("rgba(", "").replace(")", "").split(",");
		 int r = Integer.parseInt(numbers[0].trim());
		 int g = Integer.parseInt(numbers[1].trim());
		 int b = Integer.parseInt(numbers[2].trim());
		// System.out.println("r: " + r + "g: " + g + "b: " + b);
		 String hex = "#" + Integer.toHexString(r) + Integer.toHexString(g) + Integer.toHexString(b);
	//	 System.out.println("text hex.................. :" + hex);
		 
		
			return hex;
		
		
	}
//============================================

	public static boolean compareImage(File fileA, File fileB) {        
	    try {
	    	
	    	System.out.println("I am in compareImage============");
	    	
	    	
	        // take buffer data from botm image files //
	        BufferedImage biA = ImageIO.read(fileA);
	        DataBuffer dbA = biA.getData().getDataBuffer();
	        int sizeA = dbA.getSize();                      
	        BufferedImage biB = ImageIO.read(fileB);
	        DataBuffer dbB = biB.getData().getDataBuffer();
	        int sizeB = dbB.getSize();
	   
	        // compare data-buffer objects //
	        if(sizeA == sizeB) {
	            for(int i=0; i<sizeA; i++) { 
	                if(dbA.getElem(i) != dbB.getElem(i)) {
	                	 
	                    return false;
	                }
	            }
	            
	            System.out.println("I am out compareImage============");
	            return true;
	        }
	        else {
	            return false;
	        } 
	    } 
	    catch (Exception e) { 
	        System.out.println("Failed to compare image files ...error: " + e);
	        return  false;
	    }
	    
	}
//===============================================
	public float compareImage2(File fileA, File fileB) {
		// retun % of matching chart
	    float percentage = 0;
	    try {
	        // take buffer data from both image files //
	        BufferedImage biA = ImageIO.read(fileA);
	        DataBuffer dbA = biA.getData().getDataBuffer();
	        int sizeA = dbA.getSize();
	        BufferedImage biB = ImageIO.read(fileB);
	        DataBuffer dbB = biB.getData().getDataBuffer();
	        int sizeB = dbB.getSize();
	        int count = 0;
	        // compare data-buffer objects //
	        if (sizeA == sizeB) {

	            for (int i = 0; i < sizeA; i++) {

	                if (dbA.getElem(i) == dbB.getElem(i)) {
	                    count = count + 1;
	                }

	            }
	            percentage = (count * 100) / sizeA;
	        } else {
	            System.out.println("Both the images are not of same size");
	        }

	    } catch (Exception e) {
	        System.out.println("Failed to compare image files ...");
	    }
	    return percentage;
	}


//=====================================================
	public int getNumberOfLines(String file1, String FilePath) {
		
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(FilePath+file1));
			int lines = 0;
			while (reader.readLine() != null){
				lines=lines+1;
			}
			reader.close();
			return lines;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -100;
		}

	}

	
		
}