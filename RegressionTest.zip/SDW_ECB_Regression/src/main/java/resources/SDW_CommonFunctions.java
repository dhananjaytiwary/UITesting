package resources;



import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.Keys;

	import org.openqa.selenium.NoSuchElementException;

	import org.openqa.selenium.WebDriver;

import org.openqa.selenium.interactions.Actions;


	import com.aventstack.extentreports.ExtentReports;
	import com.aventstack.extentreports.ExtentTest;
	import com.aventstack.extentreports.Status;

	import junit.framework.TestCase;
import utilities.CommonFunctions;
import utilities.PropertyReader;
import utilities.Screenshots;



public class SDW_CommonFunctions extends TestCase {
	
	
		Screenshots objCreateScreenshot = new Screenshots();
		CommonFunctions com = new CommonFunctions();
		PropertyReader LeftMenuPage = new PropertyReader("src/main/java/pageObjects/SDW_LeftMenuPage.properties");
		PropertyReader CenterPage=new PropertyReader("src/main/java/pageObjects/SDW_CenterPage.properties");
		

		public void loginApp(WebDriver driver, String username, String password, String url,ExtentTest test, String date1, ExtentReports extent) throws Exception
		{
			
			try {
				
				driver.get(url);
				
			//	com.ChromLogin(username,password);
							
				}
				catch(NoSuchElementException e) {
				  //  Block of code to handle errors
					test.fail("NoSuchElementException : " + e.getMessage());
					test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));

					// Close the Browser
				//	driver.quit();
					test.log(Status.INFO, "Closed the Browser");

				}		
		}
		
		public void QuickViewSeriesTable(WebDriver driver, String Filters_code, ExtentTest test, String date1, ExtentReports extent) throws Exception
		{
			
			try {
				
				 driver.findElement(LeftMenuPage.getLocator("Macroeconomic")).click();
				 test.log(Status.INFO, "click on Macroeconomic and sectoral statistics link");
				 
				 driver.findElement(LeftMenuPage.getLocator("Labourmarket")).click();
				 test.log(Status.INFO, "click on Labour market link");
				 
				 
				 driver.findElement(LeftMenuPage.getLocator("Unemployment")).click();
				 test.log(Status.INFO, "click on Unemployment link");
				 
				 driver.findElement(LeftMenuPage.getLocator("Byagegroup")).click();
				 test.log(Status.INFO, "click on By age group link");
				 
				 TimeUnit.SECONDS.sleep(1);
				 
				 driver.findElement(CenterPage.getLocator("Classificationcontext")).sendKeys(Filters_code);
				// test.log(Status.INFO, "enter in Classification - STS context filed");
			//	 TimeUnit.SECONDS.sleep(1);
				 
			//	 driver.findElement(CenterPage.getLocator("Classification")).click();
				 test.log(Status.INFO, "enter in Classification - STS context filed");
				 TimeUnit.SECONDS.sleep(1);		
				 
				   Actions act = new Actions(driver);
				   
				   act.sendKeys(Keys.TAB).build().perform();
			
				   String parentWinHandle = driver.getWindowHandle();
				   driver.findElement(CenterPage.getLocator("BlueTitleSeries")).click();
				   test.log(Status.INFO, "Clicked on Blue Title Series link");
				   test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));

				   test.log(Status.INFO, "new window opened");
				   Set<String> winHandles = driver.getWindowHandles();
			        // Loop through all handles
			        for(String handle: winHandles){
			            if(!handle.equals(parentWinHandle)){
			            driver.switchTo().window(handle);
			            Thread.sleep(1000);
			          //  System.out.println("Title of the new window: " + driver.getTitle());
			            test.log(Status.INFO, "Title of the new window: " + driver.getTitle());
			           // System.out.println("Closing the new window...");
			            test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
			            driver.close();
			            test.log(Status.INFO, "Closing the new window...");
			            }
			        }
			        driver.switchTo().window(parentWinHandle);
			        
			        driver.findElement(CenterPage.getLocator("Linkstopublications")).click();
					   test.log(Status.INFO, "Clicked on Links to publications link");
					   
					   driver.findElement(CenterPage.getLocator("StatisticsBulletin")).click();
					   test.log(Status.INFO, "Clicked on Statistics Bulletin link");
					   
					   
					   Set<String> winHandles2 = driver.getWindowHandles();
				        // Loop through all handles
				        for(String handle: winHandles2){
				            if(!handle.equals(parentWinHandle)){
				            driver.switchTo().window(handle);
				            Thread.sleep(1000);
				          //  System.out.println("Title of the new window: " + driver.getTitle());
				            test.log(Status.INFO, "Title of the new window: " + driver.getTitle());
				           // System.out.println("Closing the new window...");
				            test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				            driver.close();
				            test.log(Status.INFO, "Closing the new window...");
				            }
				        }   
				        driver.switchTo().window(parentWinHandle);
				       
				        test.log(Status.INFO, "Closing mail window... Quick View test close");
				}
				catch(NoSuchElementException e) {
				  //  Block of code to handle errors  
					test.fail("NoSuchElementException : " + e.getMessage());
					test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));

					// Close the Browser
				//	driver.quit();
					test.log(Status.INFO, "Closed the Browser");

					// Calling flush writes everything to the Extent Report
					//extent.flush();
					//fail("NoSuchElementException");
				}		
		}
		
			public void DataExportInternalPrtal(WebDriver driver,  ExtentTest test, String date1, ExtentReports extent) throws Exception
		{
			
			try {
				
				com.DeleteAllFilesFromDirectory(System.getProperty("user.dir") + "\\DownloadFolder\\");
				
				TimeUnit.SECONDS.sleep(3);	
				
						 
				 driver.findElement(CenterPage.getLocator("DownloadData")).click();
				// test.log(Status.INFO, "enter in Classification - STS context filed");
			//	 TimeUnit.SECONDS.sleep(1);
				 
			//	 driver.findElement(CenterPage.getLocator("Classification")).click();
				 test.log(Status.INFO, "Clicked on Download Data");
				 	
				 
				 driver.findElement(CenterPage.getLocator("CSVFile")).click();
				 test.log(Status.INFO, "clicked on CSV - Character Separated  to download");
				 test.log(Status.INFO, "CSV - Character Separated File downloaded sucessfully");
				 
				 driver.findElement(CenterPage.getLocator("ExcelCSVFile")).click();
				 test.log(Status.INFO, "clicked on File Excel (csv)  to download");
				 test.log(Status.INFO, "ExcelCSVFile File downloaded sucessfully");
				 
				 driver.findElement(CenterPage.getLocator("XMLFile")).click();
				 test.log(Status.INFO, "clicked on XML File  to download");
				 test.log(Status.INFO, "XLM File downloaded sucessfully");
				 
				 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));

				 
				}
				catch(NoSuchElementException e) {
				  //  Block of code to handle errors  
					test.fail("NoSuchElementException : " + e.getMessage());
					test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));

					// Close the Browser
				driver.quit();
					test.log(Status.INFO, "Closed the Browser");

				}		
		}
		
		public void DataTable(WebDriver driver,String datefrom,String dateto,  ExtentTest test, String date1, ExtentReports extent) throws Exception
		{
			
			try {
				
										 
				 driver.findElement(LeftMenuPage.getLocator("Moneycreditbanking")).click();
				// test.log(Status.INFO, "enter in Classification - STS context filed");
			//	 TimeUnit.SECONDS.sleep(1);
				 
			//	 driver.findElement(CenterPage.getLocator("Classification")).click();
				 test.log(Status.INFO, "Clicked on Money credit banking");
				 	
				 
				 driver.findElement(LeftMenuPage.getLocator("Monetaryaggregates")).click();
				 test.log(Status.INFO, "clicked on Monetary aggregates");
				
				 
				 driver.findElement(LeftMenuPage.getLocator("CounterpartsM3")).click();
				 test.log(Status.INFO, "clicked on Counter parts M3");
				
				 
				 driver.findElement(LeftMenuPage.getLocator("MFIassets")).click();
				 test.log(Status.INFO, "clicked on MFI assets");
				 
				 
			//	 List<WebElement> list =driver.findElements(CenterPage.getLocator("seriesTableCheckbox"));
			//	 Boolean is_selected = list.get(0).isSelected();
				
				 driver.findElement(CenterPage.getLocator("seriesTableCheckbox")).click();
				 test.log(Status.INFO, "clicked on series Table Checkbox");
				
				 driver.findElement(CenterPage.getLocator("dataTable")).click();
				 test.log(Status.INFO, "clicked on Data Table link   ");
				 
				 driver.findElement(CenterPage.getLocator("fromDate")).click();
				 TimeUnit.SECONDS.sleep(1);	
				 driver.findElement(CenterPage.getLocator("fromDate")).sendKeys(datefrom);
				 test.log(Status.INFO, "Enter from date in date range");
				
				 TimeUnit.SECONDS.sleep(1);	
				 driver.findElement(CenterPage.getLocator("toDate")).click();
				 driver.findElement(CenterPage.getLocator("toDate")).sendKeys(dateto);
				 test.log(Status.INFO, "Enter To date in date range");
				 
				 TimeUnit.SECONDS.sleep(1);	
				 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Data Table", test, date1));
				
				 Actions act = new Actions(driver);
				 act.sendKeys(Keys.TAB).build().perform();
			
				 TimeUnit.SECONDS.sleep(2);	
				 
				 
				  JavascriptExecutor js = (JavascriptExecutor) driver;
		          js.executeScript("window.scrollBy(0,600)", "");
		            
				 
				 String datevalue=driver.findElement(CenterPage.getLocator("datevalue")).getText();
				 System.out.println("datevalue    " + datevalue);
				
				 if(datevalue!="") {
					 test.log(Status.INFO, " Data Table is having value");
					 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "Data Table found data", test, date1));

				 }
				 
			//	 JavascriptExecutor js1 = (JavascriptExecutor) driver;
		     //    js1.executeScript("window.scrollBy(0,-600)", "");
				 
				 driver.findElement(CenterPage.getLocator("resetSettings")).click();
				 test.log(Status.INFO, "clicked on reset Settings link   ");
				 TimeUnit.SECONDS.sleep(2);	
				 
				 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "reset Settings", test, date1));

				JavascriptExecutor js2 = (JavascriptExecutor) driver;
		          js2.executeScript("window.scrollBy(0,600)", "");
		         test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "previous data is back", test, date1));
				 
		          
		         
			//	 driver.findElement(CenterPage.getLocator("Print")).click();
		          
					 test.log(Status.INFO, "clicked on Print link to downlaod in PDF  ");
		          
			
			}
			catch(NoSuchElementException e) {
				  //  Block of code to handle errors  
					test.fail("NoSuchElementException : " + e.getMessage());
					test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));

					// Close the Browser
				driver.quit();
					test.log(Status.INFO, "Closed the Browser");

				}		
		}
		
		public void AddToMyPublication(WebDriver driver, String username,String password, String NewPublicationName,ExtentTest test, String date1, ExtentReports extent) throws Exception
		{
			
			try {
				System.out.println("dddddddddddddddddddddd" + NewPublicationName);
														 
				driver.findElement(LeftMenuPage.getLocator("Publications")).click();
				 test.log(Status.INFO, "click on Publications link");
				 
				 driver.findElement(LeftMenuPage.getLocator("EconomicBulletin")).click();
				 test.log(Status.INFO, "click on Economic Bulletin link");
				 
				 driver.findElement(CenterPage.getLocator("AddPublication")).click();
				 test.log(Status.INFO, "clicked on Add to my Publication link ");
				
				 
				/* driver.findElement(CenterPage.getLocator("username")).sendKeys(username);
				 driver.findElement(CenterPage.getLocator("password")).sendKeys(password);
				 driver.findElement(CenterPage.getLocator("login")).click();
				 
				 test.log(Status.INFO, "SDW Sign in");*/
				 driver.findElement(CenterPage.getLocator("publicationName")).sendKeys(NewPublicationName);
				 test.log(Status.INFO, "Enter New Publication Name");
				
				 driver.findElement(CenterPage.getLocator("createAddBt")).click();
				 test.log(Status.INFO, "Clicked on Create Add Button");
				 
				 
				 driver.findElement(LeftMenuPage.getLocator("MyPublications")).click();
				 test.log(Status.INFO, "click on My Publications link in left menu");
				 
			
				 
				 driver.findElement(By.linkText(NewPublicationName)).click();
				 			 
				 test.log(Status.INFO, "new Publication added");
				 
			//	 JavascriptExecutor js = (JavascriptExecutor) driver;
			//	 js.executeScript("window.scrollBy(0,1000)");
				 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));

				 
				}
				catch(NoSuchElementException e) {
				  //  Block of code to handle errors  
					test.fail("NoSuchElementException : " + e.getMessage());
					test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));

					// Close the Browser
					driver.quit();
					test.log(Status.INFO, "Closed the Browser");

				}		
		}
		
		
		public void CreateNewDataGroup(WebDriver driver, String url, String username,String password,String NewGruopName,ExtentTest test, String date1, ExtentReports extent) throws Exception
		{
			
			try {
				driver.get(url);									 
				 test.log(Status.INFO, "User navigated to the new Data Group page");
				
				
				 
				 driver.findElement(CenterPage.getLocator("Frequency")).sendKeys("Daily");
				 test.log(Status.INFO, "Daily series is selected in the Frequency filter");
				
				 TimeUnit.SECONDS.sleep(1);		
				 
				   Actions act = new Actions(driver);
				   
				   act.sendKeys(Keys.TAB).build().perform();
				   
				   driver.findElement(CenterPage.getLocator("AddMyData")).click();
				   test.log(Status.INFO, "  Click on Add to My Data option in the top menu. ");
				   
				   
				 driver.findElement(CenterPage.getLocator("username")).sendKeys(username);
				 driver.findElement(CenterPage.getLocator("password")).sendKeys(password);
				 driver.findElement(CenterPage.getLocator("login")).click();
				 
				 test.log(Status.INFO, "Login using the username and password credentials");
				 
				 driver.findElement(CenterPage.getLocator("publicationName")).sendKeys(NewGruopName);
				 test.log(Status.INFO, "Enter New Publication Name");
				
				 driver.findElement(CenterPage.getLocator("createAddBt")).click();
				 test.log(Status.INFO, "Clicked on Create Add Button");
				 
				 
				 driver.findElement(LeftMenuPage.getLocator("MyDataGroups")).click();
				 test.log(Status.INFO, "click on My Publications link in left menu");
				 
			
				 
			//	 driver.findElement(By.linkText(My Data Groups)).click();
				 			 
				 test.log(Status.INFO, "A new group with the group name provided by the user is created under My Data Groups in the left side menu");
				 
				 JavascriptExecutor js = (JavascriptExecutor) driver;
				 js.executeScript("window.scrollBy(0,1000)");
				 test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));

				 
				}
				catch(NoSuchElementException e) {
				  //  Block of code to handle errors  
					test.fail("NoSuchElementException : " + e.getMessage());
					test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));

					// Close the Browser
					driver.quit();
					test.log(Status.INFO, "Closed the Browser");

				}		
		}
}
