package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;
import pageObjects.Browser_DataSetLink;
import pageObjects.ECB_Browser_Node;
import pageObjects.ECB_Print;
import providers.Environment;
import resources.SDW_CommonFunctions;
import utilities.CommonFunctions;
import utilities.ExcelUtils;



public class ECB_RTC018_Print_intermediate_nodes extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 ECB_Print ecbPrint=new ECB_Print();
	 

	 @BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
			
			//Print_intermediate_nodes is same as RTC010 hence calling same test data
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC010");
		}
		
//Verify links available in Data Sets table : node 9701957
		@Test(priority=0,dataProvider ="getData")
		public void RTC018_Print_Intermediate_Nodes(ITestContext context,String node,String Step3) throws Exception{
			test = extent.createTest(" ECB_RTC018_Print_intermediate_nodes");
			System.out.println("I am in RTC018");
			context.removeAttribute("testpf");
			
			ExtentTest childTest1 = test.createNode("Verify links available in Available Data Sets table");
			String Intermediate_Nodes=ecbPrint.Print_Intermediate_Nodes(driver, node,Step3,childTest1, dateFormat.format(new Date()), extent);		
					
			//System.out.println( "=========DataSet_Link=================" + DataSet_Link);
			
			if (Intermediate_Nodes!="PASS"){
				context.setAttribute("testpf", "FAIL");
			}
		

		}
		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}