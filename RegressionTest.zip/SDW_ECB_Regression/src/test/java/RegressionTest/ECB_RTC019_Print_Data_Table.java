package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;
import pageObjects.Browser_DataSetLink;
import pageObjects.ECB_Browser_Node;
import pageObjects.ECB_Print;
import providers.Environment;
import resources.SDW_CommonFunctions;
import utilities.CommonFunctions;
import utilities.ExcelUtils;



public class ECB_RTC019_Print_Data_Table extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 ECB_Print ecbPrint=new ECB_Print();
	 

	 @BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
			
			//Print_intermediate_nodes is same as RTC010 hence calling same test data
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC010");
		}
		
//Verify links available in Data Sets table : node 9701957
		@Test(priority=0,dataProvider ="getData")
		public void RTC019_Print_Data_Table(ITestContext context,String node,String Step3) throws Exception{
			test = extent.createTest(" ECB_RTC019_Print_Data_Table");
			System.out.println("I am in RTC019");
			context.removeAttribute("testpf");
			
			ExtentTest childTest1 = test.createNode("Verify links available in Available Data Sets table");
			String Print_Intermediate=ecbPrint.Print_Intermediate_Nodes(driver, node,Step3,childTest1, dateFormat.format(new Date()), extent);		
				
			
			ExtentTest childTest2 = test.createNode("Print Data table, save it as PDF and Compare with existing master data table pdf");
			String Data_Table=ecbPrint.Print_Data_Table(driver,childTest2, dateFormat.format(new Date()), extent);		
					
					
			if (Print_Intermediate!="PASS" && Data_Table!="PASS"){
					context.setAttribute("testpf", "FAIL");
			}
		

		}
		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}