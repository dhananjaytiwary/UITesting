package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;

import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;

import pageObjects.ECB_Browser_Node;
import pageObjects.ECB_Series_Quickview;
import pageObjects.ECB_Series_Search;
import providers.Environment;
import utilities.CommonFunctions;
import utilities.ExcelUtils;



public class ECB_RTC036_Series_Search_Quickview extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 CommonFunctions com = new CommonFunctions();
	 ECB_Series_Quickview seriesQV=new ECB_Series_Quickview();
	 

	 @BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
	
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC036");
		}
		

		@Test(priority=0,dataProvider ="getData")
		public void RTC036_Search_Series_Quickview (ITestContext context,String Step2,String Step3,String Step4,String Step5,String Step6) throws Exception{
			test = extent.createTest("ECB_RTC036_Search_Series_Quickview ");
			context.removeAttribute("testpf");
			System.out.println("I am in RTC036");
		
			ExtentTest childTest1 = test.createNode("Search_Series_Quickview");
			String SerchQuickView=seriesQV.SeriesSearch_QuickView(driver,Step2, childTest1, dateFormat.format(new Date()), extent);		
			
			ExtentTest childTest2 = test.createNode("Verify Data Table in Quickview");
			String VerifyDataTable=seriesQV.QuickView_VerifyDataTable(driver,Step2,Step3,Step4,Step5,Step6,childTest2, dateFormat.format(new Date()), extent);		
			
			
			
			if (VerifyDataTable!="PASS" && SerchQuickView!="PASS"){
					context.setAttribute("testpf", "FAIL");
			}

		}		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}