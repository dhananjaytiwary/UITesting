package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;

import pageObjects.ECB_Browser_Node;
import pageObjects.ECB_Search_Free_Text;
import providers.Environment;

import utilities.ExcelUtils;



public class ECB_RTC014_SearchFreeText_MetaData extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 ECB_Browser_Node Browsenode=new ECB_Browser_Node();
	 ECB_Search_Free_Text searchText=new ECB_Search_Free_Text();
	 
	// SDW_CommonFunctions SDW = new SDW_CommonFunctions();
	// CommonFunctions com = new CommonFunctions();
	 

		@BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
			    	return  ExcelUtils.getTableArray(testData_path,"ECB_RTC014");
		
		}
		

		@Test(priority=0,dataProvider ="getData")
		public void RTC014_Search_Text_DataTable(ITestContext context,String node,String Step4,String Step5,String Step6,String Step7) throws Exception{
			test = extent.createTest("ECB_RTC014_SearchFreeText_MetaData");
			System.out.println("I am in RTC014");
			context.removeAttribute("testpf");
			
			ExtentTest childTest = test.createNode("Login to Home page and Search Free Text ");
			String SerachText=searchText.ECB_HomePage_SerachText(driver, node, childTest, dateFormat.format(new Date()), extent);		
				
			
			ExtentTest childTest3 = test.createNode("Verify data in Serach Free Text Metadata");
			String SerachText_MetaData=searchText.SearchfreeText_MetaData(driver,Step4,Step5,Step6,Step7,childTest3, dateFormat.format(new Date()), extent);		
					
		
			if (SerachText!="PASS" && SerachText_MetaData!="PASS"){
				context.setAttribute("testpf", "FAIL");
			}
		
		}
		

		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}