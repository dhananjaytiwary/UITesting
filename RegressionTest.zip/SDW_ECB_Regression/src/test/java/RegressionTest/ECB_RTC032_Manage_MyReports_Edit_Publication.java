package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;
import pageObjects.ECB_Export_Data;
import pageObjects.ECB_Manage_DataGroups;
import pageObjects.ECB_Manage_MyReport;
import providers.Environment;
import utilities.ExcelUtils;



public class ECB_RTC032_Manage_MyReports_Edit_Publication extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 ECB_Manage_MyReport myReport=new ECB_Manage_MyReport();
	 

	 @BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC032");
		}
		
		@Test(priority=0,dataProvider ="getData")
		public void RTC032_Manage_EditMyReports(ITestContext context,String nodes,String Step2,String Step3,String Step4,String Step5) throws Exception{
			//String node = nodes.substring(Math.max(0, nodes.length() - 7));
			
			test = extent.createTest(" ECB_RTC032_Manage_MyReports_Edit_Publication ");
			System.out.println("I am in RTC032");
			context.removeAttribute("testpf");

			ExtentTest childTest4 = test.createNode(" Manage Reports - Edit Publication" );
			String EditReport=myReport.EditPublication(driver,nodes ,Step2,Step3,Step4,Step5,childTest4, dateFormat.format(new Date()), extent);		
			
									
			if ( EditReport!="PASS"){
					context.setAttribute("testpf", "FAIL");
			}
		

		}
		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		

		


}