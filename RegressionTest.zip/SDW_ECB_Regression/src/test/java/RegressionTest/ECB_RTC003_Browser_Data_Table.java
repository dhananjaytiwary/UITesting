package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;
import pageObjects.ECB_Browser_Node;
import providers.Environment;

import utilities.ExcelUtils;



public class ECB_RTC003_Browser_Data_Table extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 ECB_Browser_Node Browsenode=new ECB_Browser_Node();
	 
//	 SDW_CommonFunctions SDW = new SDW_CommonFunctions();
//	 CommonFunctions com = new CommonFunctions();
	 

		@BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
	
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC003");
		}
		

		@Test(priority=0,dataProvider ="getData")
		public void RTC003_Browse_Data_Table(ITestContext context,String node,String Step5,String Step6,String Step7,String Step8,String Step9,String Step11) throws Exception{
			test = extent.createTest("ECB_RTC003_Browser_Data_Table : node 9701956");
	
			System.out.println("I am in RTC003");
			//DimensionFilters - DD_TST
			ExtentTest childTest3 = test.createNode("Verify data in Browse Data Table");
			String Data_Table=Browsenode.Data_Table(driver, node,Step5,Step6,Step7,Step8,Step9,Step11, childTest3, dateFormat.format(new Date()), extent);		
					
			if (Data_Table!="PASS"){
					context.setAttribute("testpf", "FAIL");
			}
		

		}
		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}