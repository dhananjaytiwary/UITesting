package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;

import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;

import pageObjects.ECB_Browser_Node;
import pageObjects.ECB_Series_Search;
import providers.Environment;
import utilities.CommonFunctions;
import utilities.ExcelUtils;



public class ECB_RTC017_Search_Filter_SeriesKeys_ByType extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 CommonFunctions com = new CommonFunctions();
	 ECB_Series_Search seriesSearch=new ECB_Series_Search();
	 

	 @BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
	
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC016");
		}
		

		@Test(priority=0,dataProvider ="getData")
		public void RTC017_Search_Filter_SeriesKeys_ByType(ITestContext context,String Step2,String Step5,String Step7) throws Exception{
			test = extent.createTest(" ECB_RTC017_Search_Filter_SeriesKeys_ByType");
	
			System.out.println("I am in RTC017");
			
				
			ExtentTest childTest = test.createNode("Verify Filter Series Keys By Type");
			String FilterSeriesKeys=seriesSearch.SeriesSearch_FilterSeriesKeys_byType(driver,Step2,childTest, dateFormat.format(new Date()), extent);		
			
			ExtentTest childTest1 = test.createNode("Verify Select and Deselect all series keys");
			String SelectSeriesKeys=seriesSearch.SeriesSearch_SelectDeselectSeriesKeys(driver, childTest1, dateFormat.format(new Date()), extent);		
			
			
			if (FilterSeriesKeys!="PASS" && SelectSeriesKeys!="PASS"){
						context.setAttribute("testpf", "FAIL");
			}

		}		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}