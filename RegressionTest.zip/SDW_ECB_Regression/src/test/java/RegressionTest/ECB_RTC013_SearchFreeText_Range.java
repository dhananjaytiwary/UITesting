package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;

import pageObjects.ECB_Browser_Node;
import pageObjects.ECB_Search_Free_Text;
import providers.Environment;

import utilities.ExcelUtils;



public class ECB_RTC013_SearchFreeText_Range extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 ECB_Browser_Node Browsenode=new ECB_Browser_Node();
	 ECB_Search_Free_Text searchText=new ECB_Search_Free_Text();
	 
	// SDW_CommonFunctions SDW = new SDW_CommonFunctions();
	// CommonFunctions com = new CommonFunctions();
	 

		@BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
	
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC013");
		}
			
		@Test(priority=1,dataProvider ="getData")
		public void RTC013_Search_Text_Range(ITestContext context,String Step2,String RTC12Step5,String Step5,String Step7,String Step9) throws Exception{
			test = extent.createTest("ECB_RTC013_SearchFreeText_Range");
			
			context.removeAttribute("testpf");
			
			ExtentTest childTest = test.createNode("Login to Home page and Search Free Text ");
			String SerachText=searchText.ECB_HomePage_SerachText(driver, Step2, childTest, dateFormat.format(new Date()), extent);		
			
			
			ExtentTest childTest1 = test.createNode("Verify Data Table page values  ");
			String SerachText_dataTable=searchText.SearchfreeText_Data_Table(driver, RTC12Step5, childTest1, dateFormat.format(new Date()), extent);		
			
			
			ExtentTest childTest2 = test.createNode("Verify Serch Fre Taxt Range  ");
			String SerachText_Range=searchText.SearchfreeText_Range(driver,Step5,Step7,Step9,childTest2, dateFormat.format(new Date()), extent);		
			
			if (SerachText_Range!="PASS" && SerachText_dataTable!="PASS" && SerachText!="PASS"){
				context.setAttribute("testpf", "FAIL");
			}
		
		}
		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}