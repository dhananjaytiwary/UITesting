package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;

import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;

import pageObjects.ECB_Browser_Node;
import pageObjects.ECB_History_Snapshot;
import providers.Environment;
import utilities.ExcelUtils;



public class ECB_RTC007_History_Snapshort_SearchText extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 ECB_History_Snapshot HistorySnapshot=new ECB_History_Snapshot();
	 

	 @BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
	
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC007");
		}
		

		@Test(priority=0,dataProvider ="getData")
		public void RTC007_History_Snapshort_SearchText(ITestContext context,String url,String Step2,String Step6,String Step7,String Step9) throws Exception{
			test = extent.createTest("ECB_RTC007_History_Snapshort_SearchText");
			context.removeAttribute("testpf");
			System.out.println("I am in RTC007");
			//DimensionFilters - DD_TST
			ExtentTest childTest1 = test.createNode("Verify data in History Snapshort SearchText");
			String Snapshort_SearchText=HistorySnapshot.History_Snapshort_SearchText(driver, Step2,Step6,Step7,Step9,childTest1, dateFormat.format(new Date()), extent);		
					
			if (Snapshort_SearchText!="PASS"){
					context.setAttribute("testpf", "FAIL");
			}

		}		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}