package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;
import pageObjects.ECB_Export_Data;
import pageObjects.ECB_Manage_DataGroups;
import pageObjects.ECB_Manage_MyReport;
import providers.Environment;
import utilities.ExcelUtils;



public class ECB_RTC035_Manage_ReplaceExistingPublication extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 ECB_Manage_MyReport myReport=new ECB_Manage_MyReport();
	 

	 @BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC035");
		}
		
		@Test(priority=0,dataProvider ="getData")
		public void RTC035_Manage_ReplaceExistingPublication(ITestContext context,String nodes,String Step3, String Step4) throws Exception{
			//String node = nodes.substring(Math.max(0, nodes.length() - 7));
			
			test = extent.createTest(" ECB_RTC035_Manage_ReplaceExistingPublication ");
			System.out.println("I am in RTC035");
			context.removeAttribute("testpf");

			ExtentTest childTest1 = test.createNode(" Manage Reports - Replace Existing Publication" );
			String ReplaceExistingPub=myReport.ReplaceExistingPublication(driver,nodes,Step3,Step4,childTest1, dateFormat.format(new Date()), extent);		
			
						
		if ( ReplaceExistingPub!="PASS"){
					context.setAttribute("testpf", "FAIL");
			}
		

		}
		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}