package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;

import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;

import pageObjects.ECB_Browser_Node;
import providers.Environment;
import utilities.ExcelUtils;



public class ECB_RTC001_Browser_AccessHomepage extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 ECB_Browser_Node Browsenode=new ECB_Browser_Node();
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();

	 @BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		/*@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
	
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC001");
		}
		*/

	//	@Test(priority=0,dataProvider ="getData")
		@Test(priority=0)
		public void RTC001_Browse_Access_HomePage(ITestContext context) throws Exception{
			test = extent.createTest("ECB_RTC001_Browser_AccessHomepage");
	System.out.println("I am in RTC001");
	
			//DimensionFilters - DD_TST
			ExtentTest childTest3 = test.createNode("Verify  ECB portal Home Page");
			String ECB_HomePage=Browsenode.ECB_HomePage(driver,childTest3, dateFormat.format(new Date()), extent);		
					
			if (ECB_HomePage=="PASS"){
				context.setAttribute("testpf", "PASS");
			}else{
				context.setAttribute("testpf", "FAIL");
			}

		}		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}