package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.apache.commons.codec.binary.StringUtils;
import org.openqa.selenium.WebDriver;

import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;

import pageObjects.ECB_Browser_Node;
import pageObjects.ECB_Series_Quickview;
import pageObjects.ECB_Series_Search;
import pageObjects.ECB_Transformation;
import providers.Environment;
import utilities.CommonFunctions;
import utilities.ExcelUtils;



public class ECB_RTC039_Transformation extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 CommonFunctions com = new CommonFunctions();
	 ECB_Transformation Transformation=new ECB_Transformation();
	 

	 @BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
	
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC039");
		}
		

		@Test(priority=0,dataProvider ="getData")
		public void RTC039_Transformation(ITestContext context,String node,String Step2,String Step3,String Step4) throws Exception{
			test = extent.createTest("ECB_RTC039_Transformation : " +Step2 ); //+ node.substring(node.lastIndexOf("=") + 1));
			System.out.println("I am in RTC039");
			context.removeAttribute("testpf");
			
			ExtentTest childTest3 = test.createNode("Verify Statistical Data Warehouse - Quick View : "  + node.substring(node.lastIndexOf("=") + 1));
			String NonAccessibleSeries=Transformation.Transformation_WeeklyFrequency(driver,node,Step2,Step3,Step4,childTest3, dateFormat.format(new Date()), extent);		
					
			if (NonAccessibleSeries!="PASS"){
				context.setAttribute("testpf", "FAIL");
			}

		}		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}