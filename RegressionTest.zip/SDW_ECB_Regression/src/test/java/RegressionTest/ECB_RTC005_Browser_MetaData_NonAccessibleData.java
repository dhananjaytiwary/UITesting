package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;

import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;

import pageObjects.ECB_Browser_Node;
import providers.Environment;
import utilities.ExcelUtils;



public class ECB_RTC005_Browser_MetaData_NonAccessibleData extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 ECB_Browser_Node Browsenode=new ECB_Browser_Node();
	 

	 @BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
	
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC005");
		}
		

		@Test(priority=0,dataProvider ="getData")
		public void RTC005_Browse_MetaData_NonAccessibleData(ITestContext context,String node,String Step2) throws Exception{
			test = extent.createTest(" ECB_RTC005_Browser_MetaData_NonAccessibleData= : 5275746");
			System.out.println("I am in RTC005");
	
			//DimensionFilters - DD_TST
			ExtentTest childTest3 = test.createNode("Verify  Metadata for non-accessible data");
			String MetaData_Table=Browsenode.MetaData_NonAccessibleData(driver, node,Step2,childTest3, dateFormat.format(new Date()), extent);		
					
			if (MetaData_Table!="PASS"){
					context.setAttribute("testpf", "FAIL");
			}

		}		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}