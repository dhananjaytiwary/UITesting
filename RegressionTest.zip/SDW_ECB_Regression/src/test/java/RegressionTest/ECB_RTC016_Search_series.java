package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;

import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;

import pageObjects.ECB_Browser_Node;
import pageObjects.ECB_Series_Search;
import providers.Environment;
import utilities.CommonFunctions;
import utilities.ExcelUtils;



public class ECB_RTC016_Search_series extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 CommonFunctions com = new CommonFunctions();
	 ECB_Series_Search seriesSearch=new ECB_Series_Search();
	 

	 @BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
	
			return  ExcelUtils.getTableArray(testData_path,"ECB_RTC016");
		}
		

		@Test(priority=0,dataProvider ="getData")
		public void RTC016_Serch_series(ITestContext context,String Step2,String Step5,String Step7) throws Exception{
			test = extent.createTest("ECB_RTC016_Search_series ");
	
			System.out.println("I am in RTC016");
			
			
			ExtentTest childTest3 = test.createNode("Verify Series Search");
			String SerchSeries=seriesSearch.SeriesSearch_SerchSeries(driver,Step2,Step5,Step7,childTest3, dateFormat.format(new Date()), extent);		
					
			if (SerchSeries!="PASS"){
					context.setAttribute("testpf", "FAIL");
			}

		}		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}