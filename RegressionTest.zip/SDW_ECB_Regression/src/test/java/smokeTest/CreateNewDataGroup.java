package smokeTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;
import providers.Environment;
import resources.SDW_CommonFunctions;
import utilities.CommonFunctions;
import utilities.ExcelUtils;



public class CreateNewDataGroup extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 SDW_CommonFunctions SDW = new SDW_CommonFunctions();
	 CommonFunctions com = new CommonFunctions();
	 

		@BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathSmoke();
	
			return  ExcelUtils.getTableArray(testData_path,"TC5_Create_Data_Group");
		}
		

		@Test(priority=0,dataProvider ="getData")
		public void AddNewDataGroup(ITestContext context, String url,String username,String password,String GruopName) throws Exception{
			test = extent.createTest("TC-5 Create a new Data Group");
			
		//	ExtentTest childTest = test.createNode("login to SDW");  String 
		//	SDW.loginApp(driver, testEnvironment.url(), childTest, dateFormat.format(new Date()), extent);		
		//	SDW.loginApp(driver, testEnvironment.url(),testEnvironment.user(),testEnvironment.password(), childTest, dateFormat.format(new Date()), extent);
		
			
			ExtentTest childTest2 = test.createNode("Create a new Data Group");
			SDW.CreateNewDataGroup(driver, url,username,password,GruopName, childTest2, dateFormat.format(new Date()), extent);		
			
					
		}
		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}