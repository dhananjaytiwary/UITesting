package smokeTest;

import java.io.IOException;

import com.testautomationguru.utility.CompareMode;
import com.testautomationguru.utility.PDFUtil;

public class CompareTwoPDFFile {

	//https://www.vinsguru.com/introducing-pdfutil-to-compare-pdf-files-extract-resources/
	//help page on pdfutil
	
	public static void main(String[] args) throws IOException {
		PDFUtil pdfUtil = new PDFUtil();
	//	pdfUtil.getPageCount("C://Users//tiwaryd//Desktop//File1.pdf"); 
	//	System.out.print(pdfUtil.getText("C://Users//tiwaryd//Desktop//File1.pdf"));//returns the page count
		
		
		String file1="C://Users//tiwaryd//Desktop//amCharts23.pdf";
		String file2="C://Users//tiwaryd//Desktop//amCharts22.pdf";
		
	//	String file1="C://Users//tiwaryd//Desktop//File1.pdf";
		//String file2="C://Users//tiwaryd//Desktop//File11.pdf";

		// compares the pdf documents and returns a boolean
		// true if both files have same content. false otherwise.
	Boolean result= pdfUtil.compare(file1, file2);
		if(result){		
			System.out.println("Both PDF file is same");
		}else{
			System.out.println("Both PDF file is NOT same");
			}
	
	try{
		// Default is CompareMode.TEXT_MODE
		pdfUtil.setCompareMode(CompareMode.VISUAL_MODE);
		pdfUtil.compare(file1, file2);
		//if you need to store the result
		pdfUtil.highlightPdfDifference(false);
		pdfUtil.setImageDestinationPath("C://Users//tiwaryd//Desktop//imgpath.pdf");
		//pdfUtil.compare(file1, file2);
		System.out.println("---------------end-------------");
	}catch (Exception e)
	{
		System.out.println(e);
	}
	}
};

