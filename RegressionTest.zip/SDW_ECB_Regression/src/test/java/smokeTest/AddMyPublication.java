package smokeTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;
import providers.Environment;
import resources.SDW_CommonFunctions;
import utilities.CommonFunctions;
import utilities.ExcelUtils;



public class AddMyPublication extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 SDW_CommonFunctions SDW = new SDW_CommonFunctions();
	 CommonFunctions com = new CommonFunctions();
	 

		@BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");     
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathSmoke();
	
			return  ExcelUtils.getTableArray(testData_path,"TC1_Add_My_Publication");
		}
		

		@Test(priority=0,dataProvider ="getData")
		public void AddPublication(ITestContext context, String username,String password, String NewPublication) throws Exception{
			test = extent.createTest("TC-1 Create a personal My Publication");
			
			ExtentTest childTest = test.createNode("login to SDW ECB Portal");
			SDW.loginApp(driver, testEnvironment.url(),testEnvironment.user(),testEnvironment.password(), childTest, dateFormat.format(new Date()), extent);		
			
			ExtentTest childTest2 = test.createNode("Add New Publication");
			SDW.AddToMyPublication(driver, username,password,NewPublication, childTest2, dateFormat.format(new Date()), extent);		
			
					
		}
		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}