package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.selenium.Eyes;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import managers.FileReaderManager;
import utilities.CommonFunctions;
import utilities.Screenshots;
public class LoginPage {
	Screenshots objCreateScreenshot = new Screenshots();
	CommonFunctions com = new CommonFunctions();
	//PropertyReader CenterPage=new PropertyReader("src/main/java/pageObjects/SDW_CenterPage.properties");
	 String fieldvalue1="";
	 String TestStatus="PASS";
	 WebElement TabName =null;
	 String ApplicaitonUrl = FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
	 
//  @FindBy(xpath="") WebElement serchbox;
  
	 public String HomePage(WebDriver driver,Eyes eyes,ExtentTest test, String date1, ExtentReports extent) throws Exception{
			
			try{
			//	String TestStatus;
				System.out.println("ApplicaitonUrl================" + ApplicaitonUrl);
				
				 
				 test.log(Status.PASS, "Open ECB Home page");
						 
			
				// Eyes eyes=new Eyes();
				 System.out.println("ApplicaitonUrl===1==");
				 //U7Eq0bm2O8rLVvrFb2zJGGxYYWbSepIXhe92xkHpLHI110
				 eyes.setApiKey("U7Eq0bm2O8rLVvrFb2zJGGxYYWbSepIXhe92xkHpLHI110");
		
				eyes.open(driver, "ECBPage", "LoginHome",new RectangleSize(1519,750));
				 driver.get(ApplicaitonUrl);
				
			//	 driver.get("https://applitools.com/helloworld2");
			//	 driver.findElement(By.xpath("//*[@id='login-page']/div[1]/div/form/div/div[4]/button")).click();
				 System.out.println("ApplicaitonUrl====4=");
			//	 eyes.checkWindow("click");
				 Thread.sleep(2000);
				
				 eyes.checkWindow();
				 System.out.println("ApplicaitonUrl====44=");
				 eyes.checkWindow("Afterlick");
				 eyes.close();
				 System.out.println("ApplicaitonUrl====5=");
				return TestStatus;
						
				
			}catch(Exception e){
				
			//  Block of code to handle errors
				test.fail("NoSuchElementException : " + e.getMessage());
				test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));
				test.log(Status.FAIL, "verify ECB Portal Home page Test FAIL ");
				test.log(Status.INFO, "Closed the Browser");
				return "FAIL";
			}
			
		}
  


}
