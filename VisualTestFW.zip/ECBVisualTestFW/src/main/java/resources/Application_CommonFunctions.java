package resources;



import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.Keys;

	import org.openqa.selenium.NoSuchElementException;

	import org.openqa.selenium.WebDriver;

import org.openqa.selenium.interactions.Actions;


	import com.aventstack.extentreports.ExtentReports;
	import com.aventstack.extentreports.ExtentTest;
	import com.aventstack.extentreports.Status;

	import junit.framework.TestCase;
import utilities.CommonFunctions;
import utilities.PropertyReader;
import utilities.Screenshots;



public class Application_CommonFunctions extends TestCase {
	
	
		Screenshots objCreateScreenshot = new Screenshots();
		CommonFunctions com = new CommonFunctions();
		PropertyReader LeftMenuPage = new PropertyReader("src/main/java/pageObjects/SDW_LeftMenuPage.properties");
		PropertyReader CenterPage=new PropertyReader("src/main/java/pageObjects/SDW_CenterPage.properties");
		

		public void loginApp(WebDriver driver, String username, String password, String url,ExtentTest test, String date1, ExtentReports extent) throws Exception
		{
			
			try {
				
				driver.get(url);
				
			//	com.ChromLogin(username,password);
							
				}
				catch(NoSuchElementException e) {
				  //  Block of code to handle errors
					test.fail("NoSuchElementException : " + e.getMessage());
					test.addScreenCaptureFromPath(objCreateScreenshot.createScreenshot(driver, "NoSuchElementException", test, date1));

					// Close the Browser
				//	driver.quit();
					test.log(Status.INFO, "Closed the Browser");

				}		
		}
	
}
