package providers;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Config.Sources;

@Sources({
    "classpath:${env}.properties"
})

public interface Environment extends Config{

	 String url();
	 String user();
	 String password();
	 String url_bo();
	 String browser_run();
	 String browser();
	 
	 //   @Key("db.hostname")
	//    String getDBHostname();
	    
}
