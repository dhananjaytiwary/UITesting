package RegressionTest;

//TC-1 Create a personal My Publication

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.selenium.Eyes;
import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;

import context.BaseTest;
import context.TestContext;
import managers.FileReaderManager;

import pageObjects.LoginPage;
import providers.Environment;

import utilities.ExcelUtils;



public class SampleTest extends BaseTest {
	 Environment testEnvironment;
	 private TestContext testContext;
	 WebDriver driver;
	 DateFormat dateFormat;
	 LoginPage Browsenode=new LoginPage();
	 Eyes eyes;
	// SDW_CommonFunctions SDW = new SDW_CommonFunctions();
	// CommonFunctions com = new CommonFunctions();
	 

		@BeforeTest
	    @Parameters({"environment"})
	    public void beforeTest(String environemnt) {
	        ConfigFactory.setProperty("env", environemnt);
	        testContext = new TestContext();
	        testEnvironment = ConfigFactory.create(Environment.class);
	        driver = testContext.getWebDriverManager().getDriver();
	        dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");  
	        eyes=new Eyes();
	        eyes.setApiKey("U7Eq0bm2O8rLVvrFb2zJGGxYYWbSepIXhe92xkHpLHI110");
	   	   // eyes.open(driver, "ECB Page", "Login Home", new RectangleSize(750,1519));
	    }
		
		@DataProvider
		public Object[][] getData(Method m) throws Exception{
			String testData_path = FileReaderManager.getInstance().getConfigReader().getTestDataPathRegression();
	
			return  ExcelUtils.getTableArray(testData_path,"HomePage");
		}
		

		@Test(priority=0,dataProvider ="getData")
	
		public void loginHomePage(ITestContext context,String NewPublication) throws Exception{
			test = extent.createTest("HomePage");
			System.out.println("I am in HomePage");
			context.removeAttribute("testpf");
		
		//	String node=node1.toString();
			ExtentTest childTest1 = test.createNode("Login to Home Page");
			String homePage=Browsenode.HomePage(driver, eyes,childTest1, dateFormat.format(new Date()), extent);		
			// eyes.checkWindow("click on about");
			//eyes.close();
		
			if (homePage!="PASS"){
				context.setAttribute("testpf", "FAIL");
			}
		

		}
		
		
		@AfterClass
		public void QuiteDriver() throws InterruptedException{
			System.out.println("..............quit browser - after class");	
			driver.quit();	
		} 

		


		


}